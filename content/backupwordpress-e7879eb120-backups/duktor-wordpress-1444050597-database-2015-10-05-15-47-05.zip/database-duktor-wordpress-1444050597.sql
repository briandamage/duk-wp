# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_commentmeta (0 records)
#

#
# End of data contents of table wp_commentmeta
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------


#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_comments (1 records)
#
 
INSERT INTO `wp_comments` VALUES (1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2015-10-05 14:08:37', '2015-10-05 12:08:37', 'Hi, this is a comment.
To delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;
#
# End of data contents of table wp_comments
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------


#
# Delete any existing table `wp_layerslider`
#

DROP TABLE IF EXISTS `wp_layerslider`;


#
# Table structure of table `wp_layerslider`
#

CREATE TABLE `wp_layerslider` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `author` int(10) NOT NULL DEFAULT '0',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_c` int(10) NOT NULL,
  `date_m` int(11) NOT NULL,
  `flag_hidden` tinyint(1) NOT NULL DEFAULT '0',
  `flag_deleted` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_layerslider (0 records)
#

#
# End of data contents of table wp_layerslider
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------


#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_links (0 records)
#

#
# End of data contents of table wp_links
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------


#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=191 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_options (165 records)
#
 
INSERT INTO `wp_options` VALUES (1, 'siteurl', 'http://duktor-wordpress/wordpress', 'yes') ; 
INSERT INTO `wp_options` VALUES (2, 'home', 'http://duktor-wordpress/wordpress', 'yes') ; 
INSERT INTO `wp_options` VALUES (3, 'blogname', 'Duktor Spezialdruck', 'yes') ; 
INSERT INTO `wp_options` VALUES (4, 'blogdescription', 'Eine weitere WordPress-Seite', 'yes') ; 
INSERT INTO `wp_options` VALUES (5, 'users_can_register', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (6, 'admin_email', 'briandamage@web.de', 'yes') ; 
INSERT INTO `wp_options` VALUES (7, 'start_of_week', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (8, 'use_balanceTags', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (9, 'use_smilies', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (10, 'require_name_email', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (11, 'comments_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (12, 'posts_per_rss', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (13, 'rss_use_excerpt', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (14, 'mailserver_url', 'mail.example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (15, 'mailserver_login', 'login@example.com', 'yes') ; 
INSERT INTO `wp_options` VALUES (16, 'mailserver_pass', 'password', 'yes') ; 
INSERT INTO `wp_options` VALUES (17, 'mailserver_port', '110', 'yes') ; 
INSERT INTO `wp_options` VALUES (18, 'default_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (19, 'default_comment_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (20, 'default_ping_status', 'open', 'yes') ; 
INSERT INTO `wp_options` VALUES (21, 'default_pingback_flag', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (22, 'posts_per_page', '10', 'yes') ; 
INSERT INTO `wp_options` VALUES (23, 'date_format', 'j. F Y', 'yes') ; 
INSERT INTO `wp_options` VALUES (24, 'time_format', 'G:i', 'yes') ; 
INSERT INTO `wp_options` VALUES (25, 'links_updated_date_format', 'j. F Y G:i', 'yes') ; 
INSERT INTO `wp_options` VALUES (26, 'comment_moderation', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (27, 'moderation_notify', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (28, 'permalink_structure', '/%year%/%monthnum%/%day%/%postname%/', 'yes') ; 
INSERT INTO `wp_options` VALUES (29, 'gzipcompression', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (30, 'hack_file', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (31, 'blog_charset', 'UTF-8', 'yes') ; 
INSERT INTO `wp_options` VALUES (32, 'moderation_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (33, 'active_plugins', 'a:5:{i:0;s:27:"LayerSlider/layerslider.php";i:1;s:35:"backupwordpress/backupwordpress.php";i:2;s:23:"debug-bar/debug-bar.php";i:3;s:27:"fusion-core/fusion-core.php";i:4;s:23:"revslider/revslider.php";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (34, 'category_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes') ; 
INSERT INTO `wp_options` VALUES (36, 'advanced_edit', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (37, 'comment_max_links', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (38, 'gmt_offset', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (39, 'default_email_category', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (40, 'recently_edited', '', 'no') ; 
INSERT INTO `wp_options` VALUES (41, 'template', 'Avada', 'yes') ; 
INSERT INTO `wp_options` VALUES (42, 'stylesheet', 'Avada', 'yes') ; 
INSERT INTO `wp_options` VALUES (43, 'comment_whitelist', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (44, 'blacklist_keys', '', 'no') ; 
INSERT INTO `wp_options` VALUES (45, 'comment_registration', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (46, 'html_type', 'text/html', 'yes') ; 
INSERT INTO `wp_options` VALUES (47, 'use_trackback', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (48, 'default_role', 'subscriber', 'yes') ; 
INSERT INTO `wp_options` VALUES (49, 'db_version', '33056', 'yes') ; 
INSERT INTO `wp_options` VALUES (50, 'uploads_use_yearmonth_folders', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (51, 'upload_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (52, 'blog_public', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (53, 'default_link_category', '2', 'yes') ; 
INSERT INTO `wp_options` VALUES (54, 'show_on_front', 'posts', 'yes') ; 
INSERT INTO `wp_options` VALUES (55, 'tag_base', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (56, 'show_avatars', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (57, 'avatar_rating', 'G', 'yes') ; 
INSERT INTO `wp_options` VALUES (58, 'upload_url_path', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (59, 'thumbnail_size_w', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (60, 'thumbnail_size_h', '150', 'yes') ; 
INSERT INTO `wp_options` VALUES (61, 'thumbnail_crop', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (62, 'medium_size_w', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (63, 'medium_size_h', '300', 'yes') ; 
INSERT INTO `wp_options` VALUES (64, 'avatar_default', 'mystery', 'yes') ; 
INSERT INTO `wp_options` VALUES (65, 'large_size_w', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (66, 'large_size_h', '1024', 'yes') ; 
INSERT INTO `wp_options` VALUES (67, 'image_default_link_type', 'file', 'yes') ; 
INSERT INTO `wp_options` VALUES (68, 'image_default_size', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (69, 'image_default_align', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (70, 'close_comments_for_old_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (71, 'close_comments_days_old', '14', 'yes') ; 
INSERT INTO `wp_options` VALUES (72, 'thread_comments', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (73, 'thread_comments_depth', '5', 'yes') ; 
INSERT INTO `wp_options` VALUES (74, 'page_comments', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (75, 'comments_per_page', '50', 'yes') ; 
INSERT INTO `wp_options` VALUES (76, 'default_comments_page', 'newest', 'yes') ; 
INSERT INTO `wp_options` VALUES (77, 'comment_order', 'asc', 'yes') ; 
INSERT INTO `wp_options` VALUES (78, 'sticky_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (79, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (80, 'widget_text', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (81, 'widget_rss', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (82, 'uninstall_plugins', 'a:1:{s:27:"LayerSlider/layerslider.php";s:29:"layerslider_uninstall_scripts";}', 'no') ; 
INSERT INTO `wp_options` VALUES (83, 'timezone_string', 'Europe/Berlin', 'yes') ; 
INSERT INTO `wp_options` VALUES (84, 'page_for_posts', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (85, 'page_on_front', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (86, 'default_post_format', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (87, 'link_manager_enabled', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (88, 'finished_splitting_shared_terms', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (89, 'initial_db_version', '33056', 'yes') ; 
INSERT INTO `wp_options` VALUES (90, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:34:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (91, 'WPLANG', 'de_DE', 'yes') ; 
INSERT INTO `wp_options` VALUES (92, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (93, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (94, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (95, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (96, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (97, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:18:"avada-blog-sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (99, 'cron', 'a:6:{i:1444066140;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1444078800;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"45422af8ff07df539650b2a7244207cb";a:3:{s:8:"schedule";s:11:"hmbkp_daily";s:4:"args";a:1:{s:2:"id";s:10:"1444050597";}s:8:"interval";i:86400;}}}i:1444090120;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1444133413;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1444525200;a:1:{s:19:"hmbkp_schedule_hook";a:1:{s:32:"c596203ac6e9ec930f855f3e24021d47";a:3:{s:8:"schedule";s:12:"hmbkp_weekly";s:4:"args";a:1:{s:2:"id";s:10:"1444050598";}s:8:"interval";i:604800;}}}s:7:"version";i:2;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (101, 'rewrite_rules', 'a:59:{s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:58:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:68:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:88:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:83:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/trackback/?$";s:85:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&tb=1";s:77:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&feed=$matches[5]";s:65:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&paged=$matches[5]";s:72:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:98:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&cpage=$matches[5]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$";s:97:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&name=$matches[4]&page=$matches[5]";s:47:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&cpage=$matches[4]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (112, '_transient_random_seed', '2e4a512211ac8a93301f50175c78e190', 'yes') ; 
INSERT INTO `wp_options` VALUES (113, '_site_transient_timeout_browser_7cb8af67a5ab95d6012670b5fa7f4b91', '1444651814', 'yes') ; 
INSERT INTO `wp_options` VALUES (114, '_site_transient_browser_7cb8af67a5ab95d6012670b5fa7f4b91', 'a:9:{s:8:"platform";s:7:"Windows";s:4:"name";s:6:"Chrome";s:7:"version";s:13:"45.0.2454.101";s:10:"update_url";s:28:"http://www.google.com/chrome";s:7:"img_src";s:49:"http://s.wordpress.org/images/browsers/chrome.png";s:11:"img_src_ssl";s:48:"https://wordpress.org/images/browsers/chrome.png";s:15:"current_version";s:2:"18";s:7:"upgrade";b:0;s:8:"insecure";b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (116, '_transient_timeout_feed_e5132d2944a7be60661ee809629a6d9c', '1444090221', 'no') ; 
INSERT INTO `wp_options` VALUES (117, '_transient_feed_e5132d2944a7be60661ee809629a6d9c', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"


";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:49:"
	
	
	
	
	
	
	
	
	
	
		
		
		
		
		
		
		
		
		
	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:3:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress | Deutsch » Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:24:"https://de.wordpress.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:21:"WordPress auf Deutsch";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 25 Sep 2015 11:53:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"de-DE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:40:"https://wordpress.org/?v=4.4-alpha-34812";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress 4.3.1 Sicherheits- und Wartungs-Release veröffentlicht";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"https://de.wordpress.org/2015/09/15/wordpress-4-3-1-sicherheits-und-wartungs-release-veroeffentlicht/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:110:"https://de.wordpress.org/2015/09/15/wordpress-4-3-1-sicherheits-und-wartungs-release-veroeffentlicht/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 15 Sep 2015 16:08:29 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"Sicherheit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1299";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:403:"Seit Kurzem ist WordPress 4.3.1 verfügbar. Dabei handelt es sich um einen Sicherheits-Release und ein Update auf die neue Version sollte dringend vorgenommen werden. Die neue Version schließt drei Sicherheitslücken. So sind WordPress 4.3 und frühere Versionen anfällig durch eine XSS-Lücke bei der Verarbeitung von Shortcode-Tags. Gemeldet wurde diese Lücke durch Shahar Tal und Netanel [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:4282:"<p>Seit Kurzem ist WordPress 4.3.1 verfügbar. Dabei handelt es sich um einen Sicherheits-Release und ein Update auf die neue Version sollte dringend vorgenommen werden.</p>
<p><span id="more-1299"></span></p>
<p>Die neue Version schließt drei Sicherheitslücken. So sind WordPress 4.3 und frühere Versionen anfällig durch eine XSS-Lücke bei der Verarbeitung von Shortcode-Tags. Gemeldet wurde diese Lücke durch Shahar Tal und Netanel Rubin von <a href="http://checkpoint.com/">Check Point</a>. Eine weitere Cross-Site-Scripting-Lücke wurde von Ben Bidner aus dem WordPress-Security-Team gefunden. Sie betrifft die Benutzerliste im Backend.</p>
<p>Die dritte Sicherheitslücke, die geschlossen wurde, kann es Benutzern ohne notwendige Berechtigung ermöglichen, private Beiträge zu veröffentlichen und sie auf den Status „Sticky“ zu setzen. Auch diese Lücke wurde von Shahar Tal und Netanel Rubin gefunden und gemeldet.</p>
<p>Vielen Dank an die Finder der Sicherheitslücken, dass sie <a href="https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities//">verantwortungsvoll damit umgegangen sind</a>. Neben diesen Sicherheitslücken behebt WordPress 4.3.1 noch 26 Bugs. Genauere Informationen dazu findet ihr in der <a href="https://core.trac.wordpress.org/log/branches/4.3/?rev=34199&amp;stop_rev=33647">Liste der Änderungen</a> oder in den <a href="https://codex.wordpress.org/Version_4.3.1">Release-Notes</a>.</p>
<p>Wenn ihr automatische Updates deaktiviert habt, müsst ihr wie gewohnt das Update über euer WordPress-Dashboard vornehmen. Wenn automatische Updates aktiv sind, dann braucht ihr nichts weiter zu unternehmen, siehe dazu auch „<a href="https://de.wordpress.org/2015/04/27/die-hintergrund-updates-von-wordpress-was-genau-passiert-da-eigentlich/">diesen Artikel</a>“. </p>
<p>Ebenfalls veröffentlicht wurden die Sicherheits-Updates: 4.2.5, 4.1.8, 4.0.8, 3.9.9, 3.8.11 und 3.7.11.</p>
<p>Danke an alle, die an WordPress 4.3.1 mitgewirkt haben:</p>
<p><a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/chriscct7">chriscct7</a>, <a href="https://profiles.wordpress.org/extendwings">Daisuke Takahashi</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/DrewAPicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/dustinbolton">dustinbolton</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/hauvong">hauvong</a>, <a href="https://profiles.wordpress.org/macmanx">James Huff</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jobst">jobst</a>, <a href="https://profiles.wordpress.org/tyxla">Marin Atanasov</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nikeo">nikeo</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="https://profiles.wordpress.org/figureone">Paul Ryan</a>, <a href="https://profiles.wordpress.org/peterwilsoncc">Peter Wilson</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/otto42">Samuel Wood</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/tmatsuur">tmatsuur</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/umeshnevase">Umesh Nevase</a>, <a href="https://profiles.wordpress.org/vortfu">vortfu</a>, <a href="https://profiles.wordpress.org/welcher">welcher</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:106:"https://de.wordpress.org/2015/09/15/wordpress-4-3-1-sicherheits-und-wartungs-release-veroeffentlicht/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:42:"
		
		
		
		
		
				

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:78:"WordPress 4.3 „Billie“: Bessere Passwörter, Menüs im Customizer und mehr";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:107:"https://de.wordpress.org/2015/08/18/wordpress-4-3-billie-bessere-passwoerter-menues-im-customizer-und-mehr/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:116:"https://de.wordpress.org/2015/08/18/wordpress-4-3-billie-bessere-passwoerter-menues-im-customizer-und-mehr/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 18 Aug 2015 19:14:43 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:1:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1221";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:425:"Heute wurde WordPress 4.3 „Billie“ veröffentlicht. Die neue Version bringt einige Neuerungen mit, unter anderem kann jetzt ein Website-Icon festgelegt sowie Markdown-ähnliche Syntax im Editor verwendet werden. Benannt ist die neue Version nach der Jazz-Sängerin Billie Holiday. Sicherere Seiten durch bessere Passwörter Ab WordPress 4.3 hilft euch WordPress beim Festlegen eines sicheren Passworts. Wenn ihr [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:26905:"<p>Heute wurde WordPress 4.3 „Billie“ veröffentlicht. Die neue Version bringt einige Neuerungen mit, unter anderem kann jetzt ein Website-Icon festgelegt sowie Markdown-ähnliche Syntax im Editor verwendet werden. Benannt ist die neue Version nach der Jazz-Sängerin Billie Holiday.</p>
<p><span id="more-1221"></span></p>
<p><iframe width=\'692\' height=\'389\' src=\'https://videopress.com/embed/T54Iy7Tw?hd=1\' frameborder=\'0\' allowfullscreen></iframe><script src=\'https://v0.wordpress.com/js/next/videopress-iframe.js?m=1435166243\'></script></p>
<h2>Sicherere Seiten durch bessere Passwörter</h2>
<p>Ab WordPress 4.3 hilft euch WordPress beim Festlegen eines sicheren Passworts. Wenn ihr bei der Installation zu der Wahl des Passworts kommt, findet ihr eine Schaltfläche zur Generierung eines Passworts vor. Danach könnt ihr das gegebenenfalls noch weiter anpassen aber so wird die Hürde für ein unsicheres Passwort jedenfalls erst mal höher.</p>
<p>Diese Funktion beschränkt sich aber nicht auf die Installation sondern findet sich auch bei der Bearbeitung von Benutzern. Des Weiteren werden Passwörter nicht mehr per E-Mail verschickt und der Link zum Zurücksetzen eines Passworts hat nur noch eine begrenzte Haltbarkeit.</p>
<figure id="attachment_1222" style="width: 632px" class="wp-caption alignnone"><img class="wp-image-1222" src="https://de.wordpress.org/files/2015/08/better-passwords.png" alt="Bessere Passwörter sind ab WordPress 4.3 Standard. (Screenshot: About-Seite von WordPress 4.3)" width="632" height="355" /><figcaption class="wp-caption-text">Bessere Passwörter sind ab WordPress 4.3 Standard. (Screenshot: About-Seite von WordPress 4.3)</figcaption></figure>
<h2>Der Customizer wird mächtiger: Menü-Verwaltung und Website-Icon</h2>
<p>Der Customizer nimmt eine immer wichtigere Rolle ein – ab sofort könnt ihr auch die komplette Verwaltung eurer Menüs darüber erledigen (den Customizer findet ihr unter „Design“ &gt; „Anpassen“). Dabei bekommt ihr – wie von den übrigen Funktionen des Customizers gewohnt – eine Vorschau eurer Änderungen angezeigt.</p>
<figure id="attachment_1223" style="width: 632px" class="wp-caption alignnone"><img class="wp-image-1223" src="https://de.wordpress.org/files/2015/08/menu-customizer.png" alt="Menüs mit Live-Vorschau bearbeiten ist jetzt auch möglich. (Screenshot: About-Seite von WordPress 4.3)" width="632" height="355" /><figcaption class="wp-caption-text">Menüs mit Live-Vorschau bearbeiten ist jetzt auch möglich. (Screenshot: About-Seite von WordPress 4.3)</figcaption></figure>
<p>Als komplett neue Funktion könnt ihr nun ein Website-Icon festlegen. Das wird anschließend als Favicon sowie App-Icon genutzt. Auch diese Funktion findet ihr im Customizer.</p>
<h2>Schnellere Formatierungen im Editor und kleinere Neuerungen</h2>
<p>WordPress 4.3 führt für den visuellen Editor Formatierungs-Kürzel ein. Damit könnt ihr beispielsweise einfacher ungeordnete Listen erstellen, indem ihr einfach einen <code>*</code> für einen Listenpunkt eingebt. Überschriften könnt ihr mit Rauten erstellen: <code>##</code> ergibt eine Überschrift zweiter Ordnung.</p>
<div style="width: 640px; " class="wp-video"><!--[if lt IE 9]><script>document.createElement(\'video\');</script><![endif]-->
<video class="wp-video-shortcode" id="video-1221-1" width="640" height="360" loop="1" autoplay="1" preload="metadata" controls="controls"><source type="video/mp4" src="//s.w.org/images/core/4.3/formatting.mp4?_=1" /><source type="video/webm" src="//s.w.org/images/core/4.3/formatting.webm?_=1" /><source type="video/ogg" src="//s.w.org/images/core/4.3/formatting.ogv?_=1" /><a href="//s.w.org/images/core/4.3/formatting.mp4">//s.w.org/images/core/4.3/formatting.mp4</a></video></div>
<p>Daneben wurden die Listen-Ansichten verbessert, sodass ihr jetzt auch in kleineren Viewports alle wichtigen Informationen erreichen könnt, ohne einen Eintrag öffnen zu müssen. Außerdem sind Kommentare auf neu angelegten Seiten nun standardmäßig deaktiviert und in der Admin-Toolbar findet sich jetzt ein Link direkt zum Customizer.</p>
<p>Ein kleines Detail, das viele aber schon länger herbeigesehnt haben: Mit der neuen Version kann die formale Sprachdatei für die deutsche Sprache direkt im Backend installiert und ausgewählt werden.</p>
<h2>Änderungen unter der Haube</h2>
<p>Gleichnamige Terme unterschiedlicher Taxonomien haben bisher ein und dieselbe Zeile in der <code>wp_terms</code>-Spalte genutzt. Bei der Aktualisierung kam es bis WordPress 4.2 in diesen Fällen zu Problemen. Mit dem Update auf WordPress 4.3 wurden diese Terme geteilt.</p>
<p>Es gibt eine neue Theme-Datei: Die <code>singular.php</code>. Diese greift als Fallback für die <code>single.php</code>&#8211; und <code>page.php</code>-Datei. Sie ist damit das Äquivalent zu der <code>archive.php</code>, die als Fallback für <code>category.php</code>, <code>author.php</code> et cetera fungiert.</p>
<p>Des Weiteren kann und sollte für Listen-Tabellen (gemeint ist beispielsweise die Übersichtsseite der Beiträge) nun eine primäre Spalte festgelegt werden. Das ist die Spalte, die in kleineren Viewports direkt angezeigt wird. Genauere Informationen über alle Änderungen findet ihr im <a href="https://codex.wordpress.org/Version_4.3">WordPress-Codex</a>.</p>
<h2>Danke!</h2>
<p>Danke an alle, die bei der neuen Version mitgewirkt haben – sei es direkt am Code oder an der Übersetzung.</p>
<h3>Projektleiter</h3>
<p><a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a> (Mitgründer, Projektleitung), <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a> (Leitender Entwickler), <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a> (Leitende Entwicklerin), <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a> (Leitender Entwickler), <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a> (Leitender Entwickler) und <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a> (Leitender Entwickler).</p>
<h3>Mitwirkende Entwickler</h3>
<p><a href="https://profiles.wordpress.org/obenland">Konstantin Obenland</a> (Release-Leitung), <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a> (Entwickler), <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a> (Entwickler), <a href="https://profiles.wordpress.org/SergeyBiryukov">Sergey Biryukov</a> (Entwickler), <a href="https://profiles.wordpress.org/boonebgorges">Boone B. Gorges</a> (Entwickler), <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a> (Entwickler), <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a> (Entwickler), <a href="https://profiles.wordpress.org/DrewAPicture">Drew Jaynes</a> (Docs Committer), <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/valendesigns">Derek Herman</a>, <a href="https://profiles.wordpress.org/designsimply">Sheri Bigelow</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/rianrietveld">Rian Rietveld</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a> und <a href="https://profiles.wordpress.org/voldemortensen">Garth Mortensen</a>.</p>
<h3>Mitwirkende am Code von WordPress 4.3</h3>
<p><a href="https://profiles.wordpress.org/mercime">@mercime</a>, <a href="https://profiles.wordpress.org/aaroncampbell">Aaron D. Campbell</a>, <a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/adamkheckler">Adam Heckler</a>, <a href="https://profiles.wordpress.org/adamsilverstein">Adam Silverstein</a>, <a href="https://profiles.wordpress.org/akibjorklund">Aki Bjorklund</a>, <a href="https://profiles.wordpress.org/akirk">Alex Kirk</a>, <a href="https://profiles.wordpress.org/viper007bond">Alex Mills (Viper007Bond)</a>, <a href="https://profiles.wordpress.org/tellyworth">Alex Shiels</a>, <a href="https://profiles.wordpress.org/deconf">Alin Marcu</a>, <a href="https://profiles.wordpress.org/andfinally">andfinally</a>, <a href="https://profiles.wordpress.org/afercia">Andrea Fercia</a>, <a href="https://profiles.wordpress.org/andg">Andrea Gandino</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/afragen">Andy Fragen</a>, <a href="https://profiles.wordpress.org/ankit-k-gupta">Ankit K Gupta</a>, <a href="https://profiles.wordpress.org/antpb">Anthony Burchell</a>, <a href="https://profiles.wordpress.org/anubisthejackle">anubisthejackle</a>, <a href="https://profiles.wordpress.org/aramzs">Aram Zucker-Scharff</a>, <a href="https://profiles.wordpress.org/arjunskumar">Arjun S Kumar</a>, <a href="https://profiles.wordpress.org/avnarun">avnarun</a>, <a href="https://profiles.wordpress.org/brad2dabone">Bad Feather</a>, <a href="https://profiles.wordpress.org/bcole808">Ben Cole</a>, <a href="https://profiles.wordpress.org/empireoflight">Ben Dunkle</a>, <a href="https://profiles.wordpress.org/binarykitten">BinaryKitten</a>, <a href="https://profiles.wordpress.org/birgire">Birgir Erlendsson (birgire)</a>, <a href="https://profiles.wordpress.org/bjornjohansen">Bjorn Johansen</a>, <a href="https://profiles.wordpress.org/bolo1988">bolo1988</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone B. Gorges</a>, <a href="https://profiles.wordpress.org/bradt">Brad Touesnard</a>, <a href="https://profiles.wordpress.org/bramd">Bram Duvigneau</a>, <a href="https://profiles.wordpress.org/kraftbj">Brandon Kraft</a>, <a href="https://profiles.wordpress.org/krogsgard">Brian Krogsgard</a>, <a href="https://profiles.wordpress.org/brianlayman">Brian Layman</a>, <a href="https://profiles.wordpress.org/icaleb">Caleb Burks</a>, <a href="https://profiles.wordpress.org/calevans">CalEvans</a>, <a href="https://profiles.wordpress.org/chasewiseman">Chase Wiseman</a>, <a href="https://profiles.wordpress.org/chipbennett">Chip Bennett</a>, <a href="https://profiles.wordpress.org/chouby">Chouby</a>, <a href="https://profiles.wordpress.org/c3mdigital">Chris Olbekson</a>, <a href="https://profiles.wordpress.org/chriscct7">chriscct7</a>, <a href="https://profiles.wordpress.org/posykrat">Clement Biron</a>, <a href="https://profiles.wordpress.org/craig-ralston">Craig Ralston</a>, <a href="https://profiles.wordpress.org/danielbachhuber">Daniel Bachhuber</a>, <a href="https://profiles.wordpress.org/redsweater">Daniel Jalkut (Red Sweater)</a>, <a href="https://profiles.wordpress.org/mte90">Daniele Mte90 Scasciafratte</a>, <a href="https://profiles.wordpress.org/daniluk4000">daniluk4000</a>, <a href="https://profiles.wordpress.org/dmchale">Dave McHale</a>, <a href="https://profiles.wordpress.org/daveal">DaveAl</a>, <a href="https://profiles.wordpress.org/davidakennedy">David A. Kennedy</a>, <a href="https://profiles.wordpress.org/dlh">David Herrera</a>, <a href="https://profiles.wordpress.org/daxelrod">daxelrod</a>, <a href="https://profiles.wordpress.org/denis-de-bernardy">Denis de Bernardy</a>, <a href="https://profiles.wordpress.org/realloc">Dennis Ploetner</a>, <a href="https://profiles.wordpress.org/valendesigns">Derek Herman</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/dipeshkakadiya">dipesh.kakadiya</a>, <a href="https://profiles.wordpress.org/dmsnell">dmsnell</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/drewapicture">Drew Jaynes</a>, <a href="https://profiles.wordpress.org/kucrut">Dzikri Aziz</a>, <a href="https://profiles.wordpress.org/eclev91">eclev91</a>, <a href="https://profiles.wordpress.org/eligijus">eligijus</a>, <a href="https://profiles.wordpress.org/eliorivero">Elio Rivero</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/ericlewis">Eric Andrew Lewis</a>, <a href="https://profiles.wordpress.org/ebinnion">Eric Binnion</a>, <a href="https://profiles.wordpress.org/ericmann">Eric Mann</a>, <a href="https://profiles.wordpress.org/fab1en">Fabien Quatravaux</a>, <a href="https://profiles.wordpress.org/flixos90">Felix Arntz</a>, <a href="https://profiles.wordpress.org/francoeurdavid">francoeurdavid</a>, <a href="https://profiles.wordpress.org/frank-klein">Frank Klein</a>, <a href="https://profiles.wordpress.org/gabrielperezs">gabrielperezs</a>, <a href="https://profiles.wordpress.org/voldemortensen">Garth Mortensen</a>, <a href="https://profiles.wordpress.org/garyj">Gary Jones</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/georgestephanis">George Stephanis</a>, <a href="https://profiles.wordpress.org/glennm">glennm</a>, <a href="https://profiles.wordpress.org/gtuk">gtuk</a>, <a href="https://profiles.wordpress.org/hailin">hailin</a>, <a href="https://profiles.wordpress.org/hauvong">hauvong</a>, <a href="https://profiles.wordpress.org/helen">Helen Hou-Sandí</a>, <a href="https://profiles.wordpress.org/henrikakselsen">henrikakselsen</a>, <a href="https://profiles.wordpress.org/hnle">Hinaloe</a>, <a href="https://profiles.wordpress.org/hrishiv90">Hrishikesh Vaipurkar</a>, <a href="https://profiles.wordpress.org/hugobaeta">Hugo Baeta</a>, <a href="https://profiles.wordpress.org/imath">imath</a>, <a href="https://profiles.wordpress.org/ipstenu">Ipstenu (Mika Epstein)</a>, <a href="https://profiles.wordpress.org/isaacchapman">isaacchapman</a>, <a href="https://profiles.wordpress.org/izem">izem</a>, <a href="https://profiles.wordpress.org/jdgrimes">J.D. Grimes</a>, <a href="https://profiles.wordpress.org/jacklenox">Jack Lenox</a>, <a href="https://profiles.wordpress.org/jadpm">jadpm</a>, <a href="https://profiles.wordpress.org/jamesgol">jamesgol</a>, <a href="https://profiles.wordpress.org/jancbeck">jancbeck</a>, <a href="https://profiles.wordpress.org/jfarthing84">Jeff Farthing</a>, <a href="https://profiles.wordpress.org/jeremyfelt">Jeremy Felt</a>, <a href="https://profiles.wordpress.org/jpry">Jeremy Pry</a>, <a href="https://profiles.wordpress.org/jmichaelward">Jeremy Ward</a>, <a href="https://profiles.wordpress.org/jesin">Jesin A</a>, <a href="https://profiles.wordpress.org/jipmoors">jipmoors</a>, <a href="https://profiles.wordpress.org/joedolson">Joe Dolson</a>, <a href="https://profiles.wordpress.org/joehoyle">Joe Hoyle</a>, <a href="https://profiles.wordpress.org/joemcgill">Joe McGill</a>, <a href="https://profiles.wordpress.org/jkudish">Joey Kudish</a>, <a href="https://profiles.wordpress.org/johnbillion">John Blackbourn</a>, <a href="https://profiles.wordpress.org/johnjamesjacoby">John James Jacoby</a>, <a href="https://profiles.wordpress.org/picard102">John Leschinski</a>, <a href="https://profiles.wordpress.org/joostdevalk">Joost de Valk</a>, <a href="https://profiles.wordpress.org/jpyper">Jpyper</a>, <a href="https://profiles.wordpress.org/jrf">jrf</a>, <a href="https://profiles.wordpress.org/juliobox">Julio Potier</a>, <a href="https://profiles.wordpress.org/jtsternberg">Justin Sternberg</a>, <a href="https://profiles.wordpress.org/ungestaltbar">Kai</a>, <a href="https://profiles.wordpress.org/karinchristen">karinchristen</a>, <a href="https://profiles.wordpress.org/karpstrucking">karpstrucking</a>, <a href="https://profiles.wordpress.org/ryelle">Kelly Dwan</a>, <a href="https://profiles.wordpress.org/kevkoeh">kevkoeh</a>, <a href="https://profiles.wordpress.org/kitchin">kitchin</a>, <a href="https://profiles.wordpress.org/ixkaito">Kite</a>, <a href="https://profiles.wordpress.org/kovshenin">Konstantin Kovshenin</a>, <a href="https://profiles.wordpress.org/lancewillett">Lance Willett</a>, <a href="https://profiles.wordpress.org/leewillis77">Lee Willis</a>, <a href="https://profiles.wordpress.org/leogopal">Leo Gopal</a>, <a href="https://profiles.wordpress.org/loushou">loushou</a>, <a href="https://profiles.wordpress.org/lumaraf">Lumaraf</a>, <a href="https://profiles.wordpress.org/tyxla">Marin Atanasov</a>, <a href="https://profiles.wordpress.org/nofearinc">Mario Peshev</a>, <a href="https://profiles.wordpress.org/clorith">Marius (Clorith)</a>, <a href="https://profiles.wordpress.org/markjaquith">Mark Jaquith</a>, <a href="https://profiles.wordpress.org/markoheijnen">Marko Heijnen</a>, <a href="https://profiles.wordpress.org/marsjaninzmarsa">marsjaninzmarsa</a>, <a href="https://profiles.wordpress.org/martinsachse">martinsachse</a>, <a href="https://profiles.wordpress.org/matt">Matt Mullenweg</a>, <a href="https://profiles.wordpress.org/veraxus">Matt van Andel</a>, <a href="https://profiles.wordpress.org/mattwiebe">Matt Wiebe</a>, <a href="https://profiles.wordpress.org/mattyrob">mattyrob</a>, <a href="https://profiles.wordpress.org/maxxsnake">maxxsnake</a>, <a href="https://profiles.wordpress.org/melchoyce">Mel Choyce</a>, <a href="https://profiles.wordpress.org/nikonratm">Michael</a>, <a href="https://profiles.wordpress.org/mdawaffe">Michael Adams (mdawaffe)</a>, <a href="https://profiles.wordpress.org/michael-arestad">Michael Arestad</a>, <a href="https://profiles.wordpress.org/michaelryanmcneill">michaelryanmcneill</a>, <a href="https://profiles.wordpress.org/mcguive7">Mickey Kay</a>, <a href="https://profiles.wordpress.org/mihai">mihai</a>, <a href="https://profiles.wordpress.org/mikehansenme">Mike Hansen</a>, <a href="https://profiles.wordpress.org/mnelson4">Mike Nelson</a>, <a href="https://profiles.wordpress.org/dh-shredder">Mike Schroder</a>, <a href="https://profiles.wordpress.org/dimadin">Milan Dinic</a>, <a href="https://profiles.wordpress.org/morganestes">Morgan Estes</a>, <a href="https://profiles.wordpress.org/mrutz">mrutz</a>, <a href="https://profiles.wordpress.org/nabil_kadimi">nabil_kadimi</a>, <a href="https://profiles.wordpress.org/Nao">Naoko Takano</a>, <a href="https://profiles.wordpress.org/nazmulhossainnihal">Nazmul Hossain Nihal</a>, <a href="https://profiles.wordpress.org/nicholas_io">nicholas_io</a>, <a href="https://profiles.wordpress.org/celloexpressions">Nick Halsey</a>, <a href="https://profiles.wordpress.org/nickmomrik">Nick Momrik</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/rabmalin">Nilambar Sharma</a>, <a href="https://profiles.wordpress.org/ohryan">ohryan</a>, <a href="https://profiles.wordpress.org/onnimonni">Onni Hakala</a>, <a href="https://profiles.wordpress.org/ozh">Ozh</a>, <a href="https://profiles.wordpress.org/pareshradadiya-1">Paresh Radadiya</a>, <a href="https://profiles.wordpress.org/swissspidy">Pascal Birchler</a>, <a href="https://profiles.wordpress.org/djpaul">Paul Gibbs</a>, <a href="https://profiles.wordpress.org/paulwilde">Paul Wilde</a>, <a href="https://profiles.wordpress.org/pavelevap">pavelevap</a>, <a href="https://profiles.wordpress.org/gungeekatx">Pete Nelson</a>, <a href="https://profiles.wordpress.org/peterwilsoncc">Peter Wilson</a>, <a href="https://profiles.wordpress.org/peterrknight">PeterRKnight</a>, <a href="https://profiles.wordpress.org/philiparthurmoore">Philip Arthur Moore</a>, <a href="https://profiles.wordpress.org/mordauk">Pippin Williamson</a>, <a href="https://profiles.wordpress.org/polevaultweb">polevaultweb</a>, <a href="https://profiles.wordpress.org/pragunbhutani">pragunbhutani</a>, <a href="https://profiles.wordpress.org/rachelbaker">Rachel Baker</a>, <a href="https://profiles.wordpress.org/ramiy">Rami Yushuvaev</a>, <a href="https://profiles.wordpress.org/rarylson">rarylson</a>, <a href="https://profiles.wordpress.org/lamosty">Rastislav Lamos</a>, <a href="https://profiles.wordpress.org/rauchg">rauchg</a>, <a href="https://profiles.wordpress.org/ravinderk">Ravinder Kumar</a>, <a href="https://profiles.wordpress.org/rclations">RC Lations</a>, <a href="https://profiles.wordpress.org/greuben">Reuben Gunday</a>, <a href="https://profiles.wordpress.org/rianrietveld">Rian Rietveld</a>, <a href="https://profiles.wordpress.org/ritteshpatel">Ritesh Patel</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/rdall">Robert Dall</a>, <a href="https://profiles.wordpress.org/rodrigosprimo">Rodrigo Primo</a>, <a href="https://profiles.wordpress.org/rommelxcastro">Rommel Castro</a>, <a href="https://profiles.wordpress.org/magicroundabout">Ross Wintle</a>, <a href="https://profiles.wordpress.org/rhurling">Rouven Hurling</a>, <a href="https://profiles.wordpress.org/ryan">Ryan Boren</a>, <a href="https://profiles.wordpress.org/rmarks">Ryan Marks</a>, <a href="https://profiles.wordpress.org/rmccue">Ryan McCue</a>, <a href="https://profiles.wordpress.org/welcher">Ryan Welcher</a>, <a href="https://profiles.wordpress.org/sagarjadhav">Sagar Jadhav</a>, <a href="https://profiles.wordpress.org/salcode">Sal Ferrarello</a>, <a href="https://profiles.wordpress.org/solarissmoke">Samir Shah</a>, <a href="https://profiles.wordpress.org/santagada">santagada</a>, <a href="https://profiles.wordpress.org/sc0ttkclark">Scott Kingsley Clark</a>, <a href="https://profiles.wordpress.org/coffee2code">Scott Reilly</a>, <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>, <a href="https://profiles.wordpress.org/scribu">scribu</a>, <a href="https://profiles.wordpress.org/scruffian">scruffian</a>, <a href="https://profiles.wordpress.org/seanchayes">Sean Hayes</a>, <a href="https://profiles.wordpress.org/sebastiantiede">sebastiantiede</a>, <a href="https://profiles.wordpress.org/sergeybiryukov">Sergey Biryukov</a>, <a href="https://profiles.wordpress.org/shooper">Shawn Hooper</a>, <a href="https://profiles.wordpress.org/designsimply">Sheri Bigelow</a>, <a href="https://profiles.wordpress.org/simonwheatley">Simon Wheatley</a>, <a href="https://profiles.wordpress.org/siobhan">Siobhan</a>, <a href="https://profiles.wordpress.org/metodiew">Stanko Metodiev</a>, <a href="https://profiles.wordpress.org/stephdau">Stephane Daury (stephdau)</a>, <a href="https://profiles.wordpress.org/netweb">Stephen Edgar</a>, <a href="https://profiles.wordpress.org/stevegrunwell">Steve Grunwell</a>, <a href="https://profiles.wordpress.org/stevenkword">Steven Word</a>, <a href="https://profiles.wordpress.org/stuartshields">stuartshields</a>, <a href="https://profiles.wordpress.org/sudar">Sudar</a>, <a href="https://profiles.wordpress.org/sunnyratilal">Sunny Ratilal</a>, <a href="https://profiles.wordpress.org/taka2">taka2</a>, <a href="https://profiles.wordpress.org/tharsheblows">tharsheblows</a>, <a href="https://profiles.wordpress.org/thorbrink">Thor Brink</a>, <a href="https://profiles.wordpress.org/creativeinfusion">Tim Smith</a>, <a href="https://profiles.wordpress.org/tlexcellent">tlexcellent</a>, <a href="https://profiles.wordpress.org/tmatsuur">tmatsuur</a>, <a href="https://profiles.wordpress.org/tobiasbg">TobiasBg</a>, <a href="https://profiles.wordpress.org/tomasm">Tomas Mackevicius</a>, <a href="https://profiles.wordpress.org/tomharrigan">TomHarrigan</a>, <a href="https://profiles.wordpress.org/toro_unit">Toro_Unit (Hiroshi Urabe)</a>, <a href="https://profiles.wordpress.org/toru">Toru Miki</a>, <a href="https://profiles.wordpress.org/liljimmi">Tracy Levesque</a>, <a href="https://profiles.wordpress.org/tryon">Tryon Eggleston</a>, <a href="https://profiles.wordpress.org/tywayne">Ty Carlson</a>, <a href="https://profiles.wordpress.org/desaiuditd">Udit Desai</a>, <a href="https://profiles.wordpress.org/vivekbhusal">vivekbhusal</a>, <a href="https://profiles.wordpress.org/westonruter">Weston Ruter</a>, <a href="https://profiles.wordpress.org/willnorris">Will Norris</a>, <a href="https://profiles.wordpress.org/willgladstone">willgladstone</a>, <a href="https://profiles.wordpress.org/earnjam">William Earnhardt</a>, <a href="https://profiles.wordpress.org/willstedt">willstedt</a>, <a href="https://profiles.wordpress.org/eltobiano">WPMU DEV Jose</a>, <a href="https://profiles.wordpress.org/yoavf">Yoav Farhi</a>, <a href="https://profiles.wordpress.org/ysalame">Yuri Salame</a>, <a href="https://profiles.wordpress.org/oxymoron">Zach Wills</a>, <a href="https://profiles.wordpress.org/katzwebdesign">Zack Katz</a> und <a href="https://profiles.wordpress.org/tollmanz">Zack Tollman</a>.</p>
<h3>Übersetzer ins Deutsche</h3>
<p><strong>Translation Editors (schalten die Übersetzungen frei):</strong> <a href="https://profiles.wordpress.org/fstaude">Frank Staude</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/arkonisus">Christian Rüggeberg</a> und <a href="https://profiles.wordpress.org/zodiac1978">Torsten Landsiedel</a>.</p>
<p><a href="https://profiles.wordpress.org/agadj">AgaDj</a>, <a href="https://profiles.wordpress.org/la-geek">Angelika Reisiger</a>, <a href="https://profiles.wordpress.org/pixolin">Bego Mario Garde</a>, <a href="https://profiles.wordpress.org/coachbirgit">Birgit Olzem</a>, <a href="https://profiles.wordpress.org/friendlyghost">Caspar</a>, <a href="https://profiles.wordpress.org/danielhuesken">Daniel Hüsken</a>, <a href="https://profiles.wordpress.org/kungtiger">Daniel Schneider</a>, <a href="https://profiles.wordpress.org/drivingralle">Drivingralle</a>, <a href="https://profiles.wordpress.org/florianbrinkmann">Florian Brinkmann</a>, <a href="https://profiles.wordpress.org/bueltge">Frank Bültge</a>, <a href="https://profiles.wordpress.org/obstschale">Hans-Helge Bürger</a>, <a href="https://profiles.wordpress.org/janreim">Jan Reimers</a>, <a href="https://profiles.wordpress.org/jozze_w">jozze_w</a>, <a href="https://profiles.wordpress.org/swissky">Kevin Kyburz (@swissky)</a>, <a href="https://profiles.wordpress.org/maxloewdev">maxloewdev</a>, <a href="https://profiles.wordpress.org/olikami">olikami</a>, <a href="https://profiles.wordpress.org/patloq">patloq</a>, <a href="https://profiles.wordpress.org/krafit">Simon Kraft</a>, <a href="https://profiles.wordpress.org/soean">soean</a>, <a href="https://profiles.wordpress.org/stk_jj">Stefan Kremer (stk_jj)</a>, <a href="https://profiles.wordpress.org/elbmedien">Stephanie Wiermann</a>, <a href="https://profiles.wordpress.org/thomas_u">Thomas_U</a>, <a href="https://profiles.wordpress.org/ipm-frommen">Thorsten Frommen</a>, <a href="https://profiles.wordpress.org/transl8or">transl8or</a> und <a href="https://profiles.wordpress.org/ww_hoax">ww_hoax</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:112:"https://de.wordpress.org/2015/08/18/wordpress-4-3-billie-bessere-passwoerter-menues-im-customizer-und-mehr/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:2:"15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress 4.2.4 Sicherheits- und Wartungs-Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"https://de.wordpress.org/2015/08/04/wordpress-4-2-4-sicherheits-und-wartungs-release/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:94:"https://de.wordpress.org/2015/08/04/wordpress-4-2-4-sicherheits-und-wartungs-release/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Tue, 04 Aug 2015 13:06:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"Sicherheit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1205";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:473:"Vor Kurzem wurde WordPress 4.2.4 veröffentlicht. Es handelt sich dabei um einen Sicherheits-Release dessen Installation dringend empfohlen wird. Der Release behebt sechs Probleme, darunter drei Cross-Site-Scripting-Lücken und eine potenzielle SQL-Injection. Die Sicherheitslücken wurden von Marc-Alexandre Montpas (Sucuri), Helen Hou-Sandí vom WordPress-Security-Team, Netanel Rubin von Check Point und Ivan Grigorov gefunden. Die neue Version beinhaltet auch [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2075:"<p>Vor Kurzem wurde WordPress 4.2.4 veröffentlicht. Es handelt sich dabei um einen Sicherheits-Release dessen Installation <strong>dringend empfohlen</strong> wird.</p>
<p><span id="more-1205"></span></p>
<p>Der Release behebt sechs Probleme, darunter drei Cross-Site-Scripting-Lücken und eine potenzielle SQL-Injection. Die Sicherheitslücken wurden von <a href="https://sucuri.net/">Marc-Alexandre Montpas</a> (Sucuri), <a href="http://helenhousandi.com/">Helen Hou-Sandí</a> vom WordPress-Security-Team, <a href="http://www.checkpoint.com/">Netanel Rubin</a> von Check Point und <a href="https://hackerone.com/reactors08">Ivan Grigorov</a> gefunden.</p>
<p>Die neue Version beinhaltet auch die Behebung einer potenziellen <a href="https://de.wikipedia.org/wiki/Seitenkanalattacke">Rechenzeitangriff-Seitenkanal-Attacke</a>, entdeckt von <a href="http://www.scrutinizer-ci.com/">Johannes Schmitt</a> (Scruntinizer) und verhindert, dass Angreifer einen Beitrag vor der Bearbeitung sperren, gefunden von <a href="https://www.linkedin.com/in/symbiansymoh">Mohamed A. Baset</a>.</p>
<p>Unser Dank geht an die, die <a href="https://make.wordpress.org/core/handbook/testing/reporting-security-vulnerabilities/">verantwortungsvoll mit Sicherheitslücken umgehen</a> und diese nicht öffentlich melden.</p>
<p>Daneben werden in der neuen Version vier Bugs behoben – <a href="https://codex.wordpress.org/Version_4.2.4">unter anderem</a> das fehlerhafte Verhalten mit Shortcodes in Spitzklammern.</p>
<p>Wenn ihr automatische Updates aktiv habt, solltet ihr die neue Version bereits erhalten haben oder bald bekommen. Wenn ihr automatische Updates deaktiviert habt, geht wie gewohnt in den Aktualisierungsbereich des Dashboards.</p>
<p><em>Habt ihr schon WordPress 4.3 getestet? Der zweite Release Candidate ist jetzt veröffentlicht (<a href="https://wordpress.org/wordpress-4.3-RC2.zip">ZIP</a>). Für mehr Informationen schaut euch den Beitrag über den <a href="https://de.wordpress.org/2015/07/30/wordpress-4-3-release-candidate/">ersten Release Candidate</a> an.</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:90:"https://de.wordpress.org/2015/08/04/wordpress-4-2-4-sicherheits-und-wartungs-release/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress 4.2.4 Release Candidate 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:72:"https://de.wordpress.org/2015/07/31/wordpress-4-2-4-release-candidate-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:80:"https://de.wordpress.org/2015/07/31/wordpress-4-2-4-release-candidate-1/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 31 Jul 2015 10:03:46 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Entwicklung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1175";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:395:"Seit Kurzem steht der erste Release Candidate für WordPress 4.2.4 zum Download bereit. Die neue Version behebt ein Problem mit Inline-Skripten und Shortcodes. Eine Änderung in WordPress 4.2.3 hatte den Effekt, dass einige Inline-Skripte mit dem CDATA-Block nicht mehr funktioniert haben. Das Skript wurde durch den Fehler auskommentiert und wurde so nicht ausgeführt. Dieses Problem [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1421:"<p>Seit Kurzem steht der erste Release Candidate für WordPress 4.2.4 zum Download bereit. Die neue Version behebt ein Problem mit Inline-Skripten und Shortcodes.</p>
<p><span id="more-1175"></span></p>
<p>Eine Änderung in WordPress 4.2.3 hatte den Effekt, dass einige Inline-Skripte mit dem CDATA-Block nicht mehr funktioniert haben. Das Skript wurde durch <a href="https://core.trac.wordpress.org/ticket/33106">den Fehler</a> auskommentiert und wurde so nicht ausgeführt.</p>
<p>Dieses Problem wird mit WordPress 4.2.4 behoben. Des Weiteren hat es nach dem Update auf WordPress 4.2.3 auf vielen Seiten <a href="https://core.trac.wordpress.org/ticket/33116">Probleme mit Shortcodes</a> gegeben, die in Spitzklammern genutzt werden, also so:</p>
<pre>&lt;[shortcode]&gt;</pre>
<p>Auch wenn von dieser Nutzung von Shortcodes abgeraten wird und Plugin-Entwickler dazu aufgerufen sind, solche Shortcodes nicht mehr zu verwenden, war dieses Verhalten unbeabsichtigt. Mit WordPress 4.2.4 soll der Einsatz solcher Shortcodes wieder funktionieren.</p>
<p>Ihr könnt euch den Release Candidate als <a href="https://wordpress.org/wordpress-4.2.4-RC1.zip">ZIP-Archiv</a> herunterladen und testen. Probleme könnt ihr im <a href="https://core.trac.wordpress.org/">Core Trac</a> oder unter dem <a href="https://make.wordpress.org/core/2015/07/30/wordpress-4-2-4-release-candidate-1/">Beitrag auf make.WordPress.org</a> melden.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:77:"https://de.wordpress.org/2015/07/31/wordpress-4-2-4-release-candidate-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:31:"WordPress 4.3 Release Candidate";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:68:"https://de.wordpress.org/2015/07/30/wordpress-4-3-release-candidate/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:76:"https://de.wordpress.org/2015/07/30/wordpress-4-3-release-candidate/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 30 Jul 2015 07:43:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Entwicklung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1173";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:398:"Gestern wurde der Release Candidate von WordPress 4.3 veröffentlicht. Die finale Version von 4.3 soll voraussichtlich am Dienstag, den 18. August, veröffentlicht werden. Wenn ihr WordPress 4.3 noch nicht getestet habt, dann tut es jetzt! Vor allem Entwickler von Themes oder Plugins sollten ihre Produkte auf der neuen Version ausprobieren. Plugin-Autoren sollen zusätzlich ihre Tested [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2038:"<p>Gestern wurde der Release Candidate von WordPress 4.3 veröffentlicht. Die finale Version von 4.3 soll voraussichtlich am Dienstag, den 18. August, veröffentlicht werden.</p>
<p><span id="more-1173"></span></p>
<p>Wenn ihr WordPress 4.3 noch nicht getestet habt, dann tut es jetzt! Vor allem Entwickler von Themes oder Plugins sollten ihre Produkte auf der neuen Version ausprobieren. Plugin-Autoren sollen zusätzlich ihre Tested up to Version vor der nächsten Woche auf 4.3 aktualisieren.</p>
<p>Wenn ihr als Entwickler Kompatibilitätsprobleme findet, dann schreibt das in die Support-Foren, sodass sie vor dem finalen Release begutachtet werden können.</p>
<p>Wenn ihr umfangreichere Infos über die Neuerungen von WordPress 4.3 haben möchtet, schaut euch die Artikel zu <a href="https://de.wordpress.org/2015/07/02/wordpress-4-3-beta-1/">Beta 1</a>, <a href="https://de.wordpress.org/2015/07/09/wordpress-4-3-beta-2/">Beta 2</a>, <a href="https://de.wordpress.org/2015/07/16/wordpress-4-3-beta-3/">Beta 3</a> und <a href="https://de.wordpress.org/2015/07/23/wordpress-4-3-beta-4/">Beta 4</a> an.</p>
<p>Wenn ihr den Release Candidate testen möchtet, könnt ihr ihn beispielsweise bequem über das <a href="https://wordpress.org/plugins/wordpress-beta-tester/">Beta-Tester-Plugin</a> installieren. Oder ihr ladet euch die <a href="https://wordpress.org/wordpress-4.3-RC1.zip">ZIP-Datei herunter</a>. Ihr solltet den Release Candidate nicht auf einer Live-Website einsetzen sondern nur in einer Testumgebung!</p>
<p>Wenn ihr einen Fehler gefunden habt, könnt ihr den in dem <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta-Bereich des Support-Forums melden</a>. Wenn Probleme aufkommen, <a href="https://core.trac.wordpress.org/report/5">könnt ihr sie hier finden</a>.</p>
<p>Auf dem <a href="https://make.wordpress.org/core/">Entwickler-Blog</a> werden weitere <a href="https://make.wordpress.org/core/tag/dev-notes+4-3/">4.3-Infos für Entwickler gepostet werden</a>, behaltet das Blog also im Blick.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:73:"https://de.wordpress.org/2015/07/30/wordpress-4-3-release-candidate/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress 4.2.3 Sicherheits- und Wartungs-Release";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"https://de.wordpress.org/2015/07/23/wordpress-4-2-3-sicherheits-und-wartungs-release/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:94:"https://de.wordpress.org/2015/07/23/wordpress-4-2-3-sicherheits-und-wartungs-release/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 13:14:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:10:"Sicherheit";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1155";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:427:"Vor Kurzem wurde mit WordPress 4.2.3 ein kritisches Sicherheits-Release veröffentlicht. Ein sofortiges Update wird dringend empfohlen! WordPress 4.2.2 und früher sind von einer kritischen Cross-Site-Scripting-Lücke betroffen. Diese kann es anonymen Nutzern erlauben, die Website zu kompromittieren. Die Lücke wurde von Jon Cave gefunden und von Robert Chapin behoben. Außerdem wurde das Problem behoben, dass ein [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2856:"<p>Vor Kurzem wurde mit WordPress 4.2.3 ein kritisches Sicherheits-Release veröffentlicht. <strong>Ein sofortiges Update wird dringend empfohlen!</strong></p>
<p><span id="more-1155"></span></p>
<p>WordPress 4.2.2 und früher sind von einer kritischen Cross-Site-Scripting-Lücke betroffen. Diese kann es anonymen Nutzern erlauben, die Website zu kompromittieren. Die Lücke wurde von <a href="https://profiles.wordpress.org/duck_">Jon Cave</a> gefunden und von <a href="http://www.miqrogroove.com/">Robert Chapin</a> behoben.</p>
<p>Außerdem wurde das Problem behoben, dass ein Nutzer mit Abonnenten-Rolle einen Entwurf mittels der Funktion „Schneller Entwurf“ erstellen konnte. Dieses Problem wurde von Netanel Rubin gemeldet und von <a href="https://www.checkpoint.com/">Check Point Software Technologies</a> behoben.</p>
<p>Vielen Dank an alle, die Sicherheitslücken <a href="//make.wordpress.org/core/handbook/reporting-security-vulnerabilities/”">nicht öffentlich melden</a>.</p>
<p>WordPress 4.2.3 behebt außerdem 20 Bugs von 4.2. Für mehr Informationen könnt ihr euch die <a href="https://codex.wordpress.org/Version_4.2.3">Release-Notes</a> oder die <a href="https://core.trac.wordpress.org/log/branches/4.2?rev=33382&amp;stop_rev=32430">Liste an Änderungen</a> anschauen.</p>
<p>Auch für die anderen Versions-Zweige gibt es Updates: 4.1.6, 4.0.6, 3.9.7, 3.8.9 sowie 3.7.9.</p>
<p>Ein Update könnt ihr über das Dashboard ausführen. Wenn ihr automatische Updates aktiv habt, sollte es bereits aktualisiert sein oder in Kürze aktualisiert werden. Wenn ihr euch die neue Version herunterladen möchtet, könnt ihr das <a href="https://de.wordpress.org/txt-download/">auf der Download-Seite tun</a>.</p>
<p>Danke an alle, die an WordPress 4.2.3 mitgeholfen haben:</p>
<p><a href="https://profiles.wordpress.org/jorbin">Aaron Jorbin</a>, <a href="https://profiles.wordpress.org/nacin">Andrew Nacin</a>, <a href="https://profiles.wordpress.org/azaozz">Andrew Ozz</a>, <a href="https://profiles.wordpress.org/boonebgorges">Boone Gorges</a>, <a href="https://profiles.wordpress.org/chriscct7">Chris Christoff</a>, <a href="https://profiles.wordpress.org/dd32">Dion Hulse</a>, <a href="https://profiles.wordpress.org/ocean90">Dominik Schilling</a>, <a href="https://profiles.wordpress.org/iseulde">Ella Iseulde Van Dorpe</a>, <a href="https://profiles.wordpress.org/gabrielperezs">Gabriel Pérez</a>, <a href="https://profiles.wordpress.org/pento">Gary Pendergast</a>, <a href="https://profiles.wordpress.org/mdawaffe">Mike Adams</a>, <a href="https://profiles.wordpress.org/miqrogroove">Robert Chapin</a>, <a href="https://profiles.wordpress.org/nbachiyski">Nikolay Bachiyski</a>, <a href="https://profiles.wordpress.org/magicroundabout">Ross Wintle</a> und <a href="https://profiles.wordpress.org/wonderboymusic">Scott Taylor</a>.</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:90:"https://de.wordpress.org/2015/07/23/wordpress-4-2-3-sicherheits-und-wartungs-release/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:45:"
		
		
		
		
		
				
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://de.wordpress.org/2015/07/23/wordpress-4-3-beta-4/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://de.wordpress.org/2015/07/23/wordpress-4-3-beta-4/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 23 Jul 2015 11:50:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:2:{i:0;a:5:{s:4:"data";s:11:"Entwicklung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1150";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:395:"Gestern ist die nächste Beta-Version für WordPress 4.3 veröffentlicht worden und hat neben einigen Verbesserungen sogar noch eine kleine neue Funktion mitgebracht. In der neuen Beta wurden diverse Fehler in der Box für die Veröffentlichung eines Beitrags in der Bearbeitungsansicht behoben. Daneben haben sich die Entwickler um ein paar Sonderfälle beim Zählen der Wörter eines [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:2860:"<p>Gestern ist die nächste Beta-Version für WordPress 4.3 veröffentlicht worden und hat neben einigen Verbesserungen sogar noch eine kleine neue Funktion mitgebracht.</p>
<p><span id="more-1150"></span></p>
<p>In der neuen Beta wurden diverse Fehler in der Box für die Veröffentlichung eines Beitrags in der Bearbeitungsansicht behoben. Daneben haben sich die Entwickler um ein paar Sonderfälle beim Zählen der Wörter eines Artikels gekümmert.</p>
<p>Als neue Funktion gibt es nun direkt im Customizer eine Vorschau für das Website-Icon. Die Funktion für das Festlegen eines Icons wurde aus den allgemeinen Einstellungen entfernt und ist damit nur noch über den Customizer zugänglich.</p>
<figure id="attachment_1151" style="width: 339px" class="wp-caption aligncenter"><img src="https://de.wordpress.org/files/2015/07/site-icon-vorschau.png" alt="Beim Zuschneiden eines Site-Icons im Customizer bekommt ihr rechts eine Vorschau angezeigt." width="339" height="294" class="size-full wp-image-1151" /><figcaption class="wp-caption-text">Beim Zuschneiden eines Site-Icons im Customizer bekommt ihr rechts eine Vorschau angezeigt.</figcaption></figure>
<p>Darüber hinaus wurden wieder einige Bugs behoben.</p>
<p>Wenn ihr umfangreichere Infos über die Neuerungen von WordPress 4.3 haben möchtet, schaut euch die Artikel zu <a href="https://de.wordpress.org/2015/07/02/wordpress-4-3-beta-1/">Beta 1</a>, <a href="https://de.wordpress.org/2015/07/09/wordpress-4-3-beta-2/">Beta 2</a> und <a href="https://de.wordpress.org/2015/07/16/wordpress-4-3-beta-3/">Beta 3</a> an.</p>
<p>Wenn ihr die Beta-Version testen möchtet, könnt ihr sie dir beispielsweise bequem über das <a href="https://wordpress.org/plugins/wordpress-beta-tester/">Beta-Tester-Plugin</a> installieren. Oder ihr ladet euch die <a href="https://wordpress.org/wordpress-4.3-beta4.zip">ZIP-Datei herunter</a>. Ihr solltet die Beta-Version nicht auf einer Live-Website einsetzen sondern nur in einer Testumgebung!</p>
<p>Wenn ihr einen Fehler gefunden habt, könnt ihr den in dem <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta-Bereich des Support-Forums melden</a>. Oder, wenn ihr damit vertraut seid einen Bug-Report zu schreiben, <a href="//core.trac.wordpress.org/">könnt ihr das im WordPress Trac machen</a>. Da könnt ihr auch <a href="//core.trac.wordpress.org/tickets/major">eine Liste aller bekannten Bugs</a> sowie <a href="//core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3">alle behobenen Probleme finden</a>.</p>
<p>Da in einer Beta-Version immer noch Sprach-Strings verändert werden können, kann es sein, dass die deutsche Übersetzung von WordPress 4.3 während der Beta-Phase noch Lücken aufweist. <a href="https://translate.wordpress.org/locale/de">Ihr könnt dabei helfen, sie komplett zu übersetzen</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"https://de.wordpress.org/2015/07/23/wordpress-4-3-beta-4/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 3";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://de.wordpress.org/2015/07/16/wordpress-4-3-beta-3/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:66:"https://de.wordpress.org/2015/07/16/wordpress-4-3-beta-3/#comments";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 16 Jul 2015 10:14:16 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Entwicklung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Beta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1126";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:382:"Seit Kurzem ist die dritte Beta zu der neuen WordPress-Version 4.3 verfügbar. Sie bringt einige weitere kleine Verbesserungen sowie ein paar neue Features mit. In der neuen Beta wurde weiter am Menu Customizer geschraubt. Die Performance wurde gesteigert, es wurden Bugs behoben und visuelle Verbesserungen vorgenommen. Seit dieser Version ist im Customizer die Option zu [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3304:"<p>Seit Kurzem ist die dritte Beta zu der neuen WordPress-Version 4.3 verfügbar. Sie bringt einige weitere kleine Verbesserungen sowie ein paar neue Features mit.</p>
<p><span id="more-1126"></span></p>
<p>In der neuen Beta wurde weiter am Menu Customizer geschraubt. Die Performance wurde gesteigert, es wurden Bugs behoben und visuelle Verbesserungen vorgenommen. Seit dieser Version ist im Customizer die Option zu finden , ein Icon für die Seite festzulegen. Dieses wird dann als Favicon und App-Icon genutzt. <strong>Dieses Feature muss noch getestet werden. Helft also mit und überprüft, ob es sowohl in den Einstellungen als auch im Customizer funktioniert</strong>!</p>
<p>Des Weiteren wurden Verbesserungen beim Thema Passwörter vorgenommen. Bei der Installation einer WordPress-Site wird dem Admin von nun an ein starkes Passwort vorgeschlagen. <strong>Auch dieses neue Feature muss noch ausgiebig getestet werden</strong>. Außerdem wurden Verbesserungen bei der Zugänglichkeit von Kommentar- und Medien-Tabellen integriert. Nutzer von Screenreadern sind dazu aufgerufen, eventuell noch vorhandene Probleme zu melden. Daneben gab es viele Verbesserungen der Code-Dokumentation und verschiedene andere Bug-Fixes.</p>
<p>Und zu guter Letzt ist es seit dieser Beta möglich, direkt über das Backend die formale „Sie“-Version des deutschen Sprachpakts zu installieren!</p>
<blockquote class="twitter-tweet" width="550"><p lang="en" dir="ltr">HA! Formal German has landed in core! <a href="https://twitter.com/hashtag/wordpress?src=hash">#wordpress</a> <a href="https://twitter.com/hashtag/sitelanguage?src=hash">#sitelanguage</a> <a href="https://twitter.com/hashtag/polyglots?src=hash">#polyglots</a> <a href="http://t.co/WbiwYaKkwq">pic.twitter.com/WbiwYaKkwq</a></p>
<p>&mdash; Caspar Hübinger (@glueckpress) <a href="https://twitter.com/glueckpress/status/620866636384309249">July 14, 2015</a></p></blockquote>
<p><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script></p>
<p>Wenn ihr die Beta-Version testen möchtet, könnt ihr sie dir beispielsweise bequem über das <a href="https://wordpress.org/plugins/wordpress-beta-tester/">Beta-Tester-Plugin</a> installieren. Oder ihr ladet euch die <a href="https://wordpress.org/wordpress-4.3-beta3.zip">ZIP-Datei herunter</a>. Ihr solltet die Beta-Version nicht auf einer Live-Website einsetzen sondern nur in einer Testumgebung!</p>
<p>Wenn ihr einen Fehler gefunden habt, könnt ihr den in dem <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta-Bereich des Support-Forums melden</a>. Oder, wenn ihr damit vertraut seid einen Bug-Report zu schreiben, <a href="//core.trac.wordpress.org/”">könnt ihr das im WordPress Trac machen</a>. Da könnt ihr auch <a href="//core.trac.wordpress.org/tickets/major”">eine Liste aller bekannten Bugs</a> sowie <a href="//core.trac.wordpress.org/query?status=closed&amp;group=component&amp;milestone=4.3”">alle behobenen Probleme finden</a>.</p>
<p>Da in einer Beta-Version immer noch Sprach-Strings verändert werden können, kann es sein, dass die deutsche Übersetzung von WordPress 4.3 während der Beta-Phase noch Lücken aufweist. <a href="https://translate.wordpress.org/locale/de">Ihr könnt dabei helfen, sie komplett zu übersetzen</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"https://de.wordpress.org/2015/07/16/wordpress-4-3-beta-3/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"4";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 2";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://de.wordpress.org/2015/07/09/wordpress-4-3-beta-2/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://de.wordpress.org/2015/07/09/wordpress-4-3-beta-2/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 09 Jul 2015 16:36:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Entwicklung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Beta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1090";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:364:"Keine ganze Woche nach der ersten Beta-Version wurde gestern bereits die zweite Beta für WordPress 4.3 veröffentlicht. WordPress 4.3 lässt nicht mehr allzu lange auf sich warten, am 18. August soll es soweit sein. Was es für Neuerungen geben wird, beziehungsweise in den Beta-Versionen schon gibt, könnt ihr in dem Beitrag zur ersten Beta nachlesen. [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:17:"Florian Brinkmann";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:1710:"<p>Keine ganze Woche nach der ersten Beta-Version wurde gestern bereits die zweite Beta für WordPress 4.3 veröffentlicht.<span id="more-1090"></span></p>
<p>WordPress 4.3 lässt nicht mehr allzu lange auf sich warten, am 18. August soll es soweit sein. Was es für Neuerungen geben wird, beziehungsweise in den Beta-Versionen schon gibt, könnt ihr <a href="https://de.wordpress.org/2015/07/02/wordpress-4-3-beta-1/">in dem Beitrag zur ersten Beta nachlesen</a>.</p>
<p>Im Vergleich zu Beta 1 wurden einige weitere Verbesserungen an dem Customizer vorgenommen sowie die Ansicht von Tabellenlisten in kleineren Viewports verbessert.</p>
<p>Außerdem gibt es nun in der Admin-Toolbar einen direkten Link zum Customizer. Des Weiteren wurden viele Bugs behoben – fast 100 Änderungen sind in der letzten Woche vorgenommen worden. Genauere Informationen zu der zweiten Beta findet ihr <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-2/">in dem Blogpost auf WordPress.org</a>.</p>
<p>Wenn ihr die Beta-Version testen möchtet, könnt ihr sie dir beispielsweise bequem über das <a href="https://wordpress.org/plugins/wordpress-beta-tester/">Beta-Tester-Plugin</a> installieren. Oder ihr ladet euch die <a href="https://wordpress.org/wordpress-4.3-beta2.zip">ZIP-Datei herunter</a>. Ihr solltet die Beta-Version nicht auf einer Live-Website einsetzen sondern nur in einer Testumgebung!</p>
<p>Da in einer Beta-Version immer noch Sprach-Strings verändert werden können, kann es sein, dass die deutsche Übersetzung von WordPress 4.3 während der Beta-Phase noch Lücken aufweist. <a href="https://translate.wordpress.org/languages/de">Ihr könnt dabei helfen, sie komplett zu übersetzen</a>!</p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"https://de.wordpress.org/2015/07/09/wordpress-4-3-beta-2/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:48:"
		
		
		
		
		
				
		
		

		
		
				
			
		
		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:5:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordPress 4.3 Beta 1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://de.wordpress.org/2015/07/02/wordpress-4-3-beta-1/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:65:"https://de.wordpress.org/2015/07/02/wordpress-4-3-beta-1/#respond";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Jul 2015 17:12:22 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"category";a:3:{i:0;a:5:{s:4:"data";s:11:"Entwicklung";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:1;a:5:{s:4:"data";s:8:"Releases";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}i:2;a:5:{s:4:"data";s:4:"Beta";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:32:"https://de.wordpress.org/?p=1063";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:387:"WordPress 4.3 Beta 1 ist jetzt verfügbar! Diese Version ist noch in der Entwicklung, wir empfehlen, sie nicht in einer produktiven Website, sondern am besten in einer eigens zu diesem Zweck eingerichteten Testumgebung laufen zu lassen. Um WordPress 4.3 zu testen, kannst du das Plugin Beta-Tester installieren (konfiguriere es für „bleeding edge Nightlies“, um immer den [&#8230;]";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Caspar Hübinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:40:"http://purl.org/rss/1.0/modules/content/";a:1:{s:7:"encoded";a:1:{i:0;a:5:{s:4:"data";s:3825:"<p>WordPress 4.3 Beta 1 ist jetzt verfügbar!</p>
<p><strong>Diese Version ist noch in der Entwicklung</strong>, wir empfehlen, sie nicht in einer produktiven Website, sondern am besten in einer eigens zu diesem Zweck eingerichteten Testumgebung laufen zu lassen. Um WordPress 4.3 zu testen, kannst du das <a href="https://wordpress.org/plugins/wordpress-beta-tester/">Plugin Beta-Tester</a> installieren (konfiguriere es für „bleeding edge Nightlies“, um immer den neusten Stand der Beta zu bekommen). Oder du kannst die <a href="https://wordpress.org/wordpress-4.3-beta1.zip">Beta-Version hier (zip) herunterladen</a>.</p>
<p><em>Da in einer Beta-Version immer nocht Sprach-Strings verändert werden können, kann es sein, dass die deutsche Übersetzung von WordPress 4.3 während der Beta-Phase noch Lücken aufweist. <a href="https://translate.wordpress.org/languages/de">Du kannst dabei helfen, sie komplett zu machen!</a></em></p>
<p><span id="more-1063"></span></p>
<p>Die Veröffentlichung von 4.3 ist terminiert auf nächsten Monat. Um den Termin zu halten, brauchen die Entwickler_innen deine Hilfe beim Testen der Features, an denen sie gearbeitet haben:</p>
<ul>
<li><strong>Menüs</strong> kannst du nun mit dem Customizer verwalten, mit dem dir die Möglichkeit einer Live-Vorschau deiner Änderungen zur Verfügung steht, bevor du sie speicherst und damit für deine Besucher_innen sichtbar machst. Die Entwickler_innen sind besonders daran interessiert, ob dieses neue Feature (und der Customizer allgemein) für dich den Prozess der Einrichtung deiner Website optimiert (<a href="https://core.trac.wordpress.org/ticket/32576">#32576</a>).</li>
<li>Mit dem neuen <strong>Site-Icon</strong>-Feature kannst du nun das Favicon und App-Symbol deiner Website aus dem Admin-Bereich heraus verwalten (<a href="https://core.trac.wordpress.org/ticket/16434">#16434</a>).</li>
<li>Die Entwickler_innen haben außerdem eine Menge Arbeit in <strong>bessere Passwörter</strong> für WordPress investiert. WordPress begrenzt nun die Lebensdauer einer Passwortzurücksetzung, sendet Passwörter nicht mehr per E-Mail und erzeugt bzw. schlägt sichere Passwörter für dich vor. Probiere es aus und lasse uns wissen, was du davon hältst! (<a href="https://core.trac.wordpress.org/ticket/32589">#32589</a>)</li>
<li>Im <strong>Editor</strong> werden bestimmte Textmuster (entlehnt aus der beliebten <a href="https://de.wikipedia.org/wiki/Markdown">Markdown</a>-Schreibweise) nun automatisch umgewandelt, während du schreibst, einschließlich <strong>*</strong> und <strong>&#8211;</strong> in ungeordneten Listen, <strong>1</strong> und <strong>1)</strong> für geordnete Listen, <strong>&gt;</strong> für Blockzitate und ein bis sechs Gatterzeichen (<strong>#</strong>) für Überschriften (<a href="https://core.trac.wordpress.org/ticket/31441">#31441</a>).</li>
<li>Die <strong>Listenansicht</strong> im Admin-Bereich funktioniert nun besser auf <strong>Geräten mit kleinem Bildschirm</strong>. Spalten werden nicht mehr abgeschnitten, sondern können als sichtbar hinzugeschaltet werden (<a href="https://core.trac.wordpress.org/ticket/32395">#32395</a>).</li>
</ul>
<p><strong>Entwickler_innen:</strong> Auch für euch gibt es einige Änderungen zu testen! Siehe dazu den <a href="https://wordpress.org/news/2015/07/wordpress-4-3-beta-1/">Original-Beitrag im WordPress-Blog</a>.</p>
<p><strong>Wenn du glaubst, einen Fehler gefunden haben</strong>, schreibe gerne einen Eintrag im <a href="https://wordpress.org/support/forum/alphabeta">Alpha/Beta-Bereich in den Support-Foren</a> (englischsprachig) dazu. Das Core-Team freut sich, von dir zu hören!</p>
<p>Viel Spaß beim Testen!</p>
<p><em>Site-Icons für alle</em><br />
<em> Live-Vorschau Menü-Änderungen</em><br />
<em> Vier drei Beta jetzt</em></p>
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:36:"http://wellformedweb.org/CommentAPI/";a:1:{s:10:"commentRss";a:1:{i:0;a:5:{s:4:"data";s:62:"https://de.wordpress.org/2015/07/02/wordpress-4-3-beta-1/feed/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:38:"http://purl.org/rss/1.0/modules/slash/";a:1:{s:8:"comments";a:1:{i:0;a:5:{s:4:"data";s:1:"0";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:47:"https://de.wordpress.org/category/release/feed/";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:44:"http://purl.org/rss/1.0/modules/syndication/";a:2:{s:12:"updatePeriod";a:1:{i:0;a:5:{s:4:"data";s:6:"hourly";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:15:"updateFrequency";a:1:{i:0;a:5:{s:4:"data";s:1:"1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:7:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 05 Oct 2015 12:10:21 GMT";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";s:10:"connection";s:5:"close";s:13:"last-modified";s:29:"Fri, 25 Sep 2015 11:53:42 GMT";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20151005115503";}', 'no') ; 
INSERT INTO `wp_options` VALUES (118, '_transient_timeout_feed_mod_e5132d2944a7be60661ee809629a6d9c', '1444090221', 'no') ; 
INSERT INTO `wp_options` VALUES (119, '_transient_feed_mod_e5132d2944a7be60661ee809629a6d9c', '1444047021', 'no') ; 
INSERT INTO `wp_options` VALUES (120, '_transient_timeout_feed_96c7dc9bec0a68fc131c26d6c304d150', '1444090222', 'no') ; 
INSERT INTO `wp_options` VALUES (121, '_transient_feed_96c7dc9bec0a68fc131c26d6c304d150', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:2:"

";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:4:"0.92";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:37:"
	
	
	
	
	
	

	

	
	
	
	
	
	
	
	
	
	
";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:45:"Planet WordPress » Deutschsprachiger Channel";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:22:"http://planet.wpde.org";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:103:"Der Planet listet Inhalte ausgewählter Blogs auf, die regelmäßig Beiträge zu WordPress publizieren.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:13:"lastBuildDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Oct 2015 08:12:10 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"docs";a:1:{i:0;a:5:{s:4:"data";s:34:"http://backend.userland.com/rss092";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"de-DE";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:10:{i:0;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress News #147 / Start in den Backup-Oktober";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/147/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:49:"WordPress News #146 / Child Themes aktuell halten";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/146/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:42:"WordPress News #145 / WordCamp Switzerland";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/145/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:44:"WordPress 4.3: Handbuch für Administratoren";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:76:"http://www.perun.net/2015/09/17/wordpress-4-3-handbuch-fuer-administratoren/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:20:"WordCamp Berlin 2015";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"http://www.perun.net/2015/09/14/wordcamp-berlin-2015/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:65:"WordPress 4.3.1 Sicherheits- und Wartungs-Release veröffentlicht";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:101:"https://de.wordpress.org/2015/09/15/wordpress-4-3-1-sicherheits-und-wartungs-release-veroeffentlicht/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:85:"MultilingualPress wird zum “freien” Plugin – Mehrsprachiges WordPress für alle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://marketpress.de/2015/multilingualpress-mehrsprachiges-wordpress/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:53:"WordPress News #144 / Kommentare komplett ausschalten";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/144/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:48:"Wir freuen uns sehr auf das WordCamp Berlin 2015";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"https://de.wordpress.org/2015/09/10/wir-freuen-uns-sehr-auf-das-wordcamp-berlin-2015/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:13:"
		
		
		
			";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:3:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:57:"WordPress News #143 / Alle Plugins und Themes übersetzen";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:32:"https://wpletter.de/archive/143/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:8;s:7:"headers";a:10:{s:4:"date";s:29:"Mon, 05 Oct 2015 12:10:23 GMT";s:6:"server";s:6:"Apache";s:4:"vary";s:26:"Accept-Encoding,User-Agent";s:12:"x-powered-by";s:14:"PHP/5.5.21-pl0";s:10:"x-pingback";s:33:"http://planet.wpde.org/xmlrpc.php";s:13:"last-modified";s:29:"Mon, 05 Oct 2015 08:12:10 GMT";s:4:"etag";s:34:""15cc600501c42a30d5dfe2529afbb37c"";s:14:"content-length";s:4:"2511";s:10:"connection";s:5:"close";s:12:"content-type";s:34:"application/rss+xml; charset=UTF-8";}s:5:"build";s:14:"20151005115503";}', 'no') ; 
INSERT INTO `wp_options` VALUES (122, '_transient_timeout_feed_mod_96c7dc9bec0a68fc131c26d6c304d150', '1444090222', 'no') ; 
INSERT INTO `wp_options` VALUES (123, '_transient_feed_mod_96c7dc9bec0a68fc131c26d6c304d150', '1444047022', 'no') ; 
INSERT INTO `wp_options` VALUES (124, '_transient_timeout_feed_b9388c83948825c1edaef0d856b7b109', '1444090224', 'no') ; 
INSERT INTO `wp_options` VALUES (125, '_transient_feed_b9388c83948825c1edaef0d856b7b109', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"
	
";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:117:"
		
		
		
		
		
		
				

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:7:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress Plugins » View: Populare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:45:"https://wordpress.org/plugins/browse/popular/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:35:"WordPress Plugins » View: Populare";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:8:"language";a:1:{i:0;a:5:{s:4:"data";s:5:"ro-RO";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Oct 2015 12:00:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:9:"generator";a:1:{i:0;a:5:{s:4:"data";s:25:"http://bbpress.org/?v=1.1";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:30:{i:0;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/regenerate-thumbnails/#post-6743";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 23 Aug 2008 14:38:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"6743@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:76:"Allows you to regenerate your thumbnails after changing the thumbnail sizes.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:25:"Alex Mills (Viper007Bond)";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"https://wordpress.org/plugins/wordpress-seo/#post-8321";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 01 Jan 2009 20:34:44 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"8321@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:114:"Improve your WordPress SEO: Write better content and have a fully optimized WordPress site using Yoast SEO plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:62:"https://wordpress.org/plugins/really-simple-captcha/#post-9542";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 09 Mar 2009 02:17:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"9542@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Really Simple CAPTCHA is a CAPTCHA module intended to be called from other plugins. It is originally created for my Contact Form 7 plugin.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:3;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"https://wordpress.org/plugins/tinymce-advanced/#post-2082";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 27 Jun 2007 15:00:26 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2082@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Enables the advanced features of TinyMCE, the WordPress WYSIWYG editor.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Andrew Ozz";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:4;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:49:"https://wordpress.org/plugins/jetpack/#post-23862";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 Jan 2011 02:21:38 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"23862@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:28:"Your WordPress, Streamlined.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Tim Moore";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:5;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/nextgen-gallery/#post-1169";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 23 Apr 2007 20:08:06 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"1169@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:121:"The most popular WordPress gallery plugin and one of the most popular plugins of all time with over 13 million downloads.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Alex Rabe";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:6;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/contact-form-7/#post-2141";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 02 Aug 2007 12:45:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2141@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:54:"Just another contact form plugin. Simple but flexible.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Takayuki Miyoshi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:7;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/wp-super-cache/#post-2572";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Nov 2007 11:40:04 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2572@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:73:"A very fast caching engine for WordPress that produces static html files.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Donncha O Caoimh";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:8;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wp-pagenavi/#post-363";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 23:17:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"363@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:49:"Adds a more advanced paging navigation interface.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Lester Chan";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:9;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/wordfence/#post-29832";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 04 Sep 2011 03:13:51 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29832@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"The Wordfence WordPress security plugin provides free enterprise-class WordPress security, protecting your website from hacks and malware.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Wordfence";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:10;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/all-in-one-seo-pack/#post-753";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 30 Mar 2007 20:08:18 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"753@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:126:"All in One SEO Pack is a WordPress SEO plugin to automatically optimize your WordPress blog for Search Engines such as Google.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:8:"uberdose";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:11;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:56:"https://wordpress.org/plugins/w3-total-cache/#post-12073";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 29 Jul 2009 18:46:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"12073@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:132:"Easy Web Performance Optimization (WPO) using caching: browser, page, object, database, minify and content delivery network support.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:16:"Frederick Townes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:12;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wordpress-importer/#post-18101";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 20 May 2010 17:42:45 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"18101@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:101:"Import posts, pages, comments, custom fields, categories, tags and more from a WordPress export file.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Brian Colinger";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:13;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/advanced-custom-fields/#post-25254";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 17 Mar 2011 04:07:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"25254@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:68:"Customise WordPress with powerful, professional and intuitive fields";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"elliotcondon";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:14;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/woocommerce/#post-29860";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 05 Sep 2011 08:13:36 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"29860@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:97:"WooCommerce is a powerful, extendable eCommerce plugin that helps you sell anything. Beautifully.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"WooThemes";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:15;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:71:"https://wordpress.org/plugins/google-analytics-for-wordpress/#post-2316";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 14 Sep 2007 12:15:27 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2316@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:124:"Track your WordPress site easily with the latest tracking codes and lots added data for search result pages and error pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Joost de Valk";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:16;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/hello-dolly/#post-5790";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 29 May 2008 22:11:34 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"5790@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"This is not just a plugin, it symbolizes the hope and enthusiasm of an entire generation summed up in two words sung most famously by Louis Armstrong.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:17;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:64:"https://wordpress.org/plugins/google-sitemap-generator/#post-132";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:31:32 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:34:"132@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:105:"This plugin will generate a special XML sitemap which will help search engines to better index your blog.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Arne Brachhold";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:18;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:46:"https://wordpress.org/plugins/akismet/#post-15";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 09 Mar 2007 22:11:30 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:33:"15@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:98:"Akismet checks your comments against the Akismet Web service to see if they look like spam or not.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"Matt Mullenweg";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:19;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"https://wordpress.org/plugins/duplicate-post/#post-2646";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Wed, 05 Dec 2007 17:40:03 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:35:"2646@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:22:"Clone posts and pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:4:"lopo";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:20;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:58:"https://wordpress.org/plugins/disable-comments/#post-26907";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 27 May 2011 04:42:58 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26907@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:134:"Allows administrators to globally disable comments on their site. Comments can be disabled according to post type. Multisite friendly.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Samir Shah";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:21;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/wp-multibyte-patch/#post-28395";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Jul 2011 12:22:53 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"28395@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:71:"Multibyte functionality enhancement for the WordPress Japanese package.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"plugin-master";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:22;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:69:"https://wordpress.org/plugins/black-studio-tinymce-widget/#post-31973";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 10 Nov 2011 15:06:14 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"31973@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"The visual editor widget for Wordpress.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:12:"Marco Chiesi";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:23;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:60:"https://wordpress.org/plugins/better-wp-security/#post-21738";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Fri, 22 Oct 2010 22:06:05 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"21738@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:150:"Protect your WordPress site by hiding vital areas of your site, protecting access to important files, preventing brute-force login attempts, detecting";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:13:"Chris Wiegman";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:24;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:59:"https://wordpress.org/plugins/siteorigin-panels/#post-51888";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 11 Apr 2013 10:36:42 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"51888@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:111:"Build responsive page layouts using the widgets you know and love using this simple drag and drop page builder.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Greg Priday";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:25;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:51:"https://wordpress.org/plugins/ml-slider/#post-49521";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 14 Feb 2013 16:56:31 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"49521@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:145:"Easy to use WordPress slider plugin. Create SEO optimised responsive slideshows with Nivo Slider, Flex Slider, Coin Slider and Responsive Slides.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:11:"Matcha Labs";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:26;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:75:"https://wordpress.org/plugins/google-analytics-dashboard-for-wp/#post-50539";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 10 Mar 2013 17:07:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"50539@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:127:"Displays Google Analytics reports in your WordPress Dashboard. Inserts the latest Google Analytics tracking code in your pages.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Alin Marcu";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:27;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:52:"https://wordpress.org/plugins/duplicator/#post-26607";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 16 May 2011 12:15:41 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"26607@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:88:"Duplicate, clone, backup, move and transfer an entire site from one location to another.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:10:"Cory Lamle";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:28;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:53:"https://wordpress.org/plugins/updraftplus/#post-38058";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 21 May 2012 15:14:11 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"38058@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:148:"Backup and restoration made easy. Complete backups; manual or scheduled (backup to S3, Dropbox, Google Drive, Rackspace, FTP, SFTP, email + others).";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:14:"David Anderson";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:29;a:6:{s:4:"data";s:30:"
			
			
			
			
			
			
					";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:2:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:30:"Clef Two-Factor Authentication";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:48:"https://wordpress.org/plugins/wpclef/#post-47509";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Thu, 27 Dec 2012 01:25:57 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:36:"47509@https://wordpress.org/plugins/";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:138:"Secure two-factor that people love to use: strong authentication without passwords or tokens; single sign on/off; magical user experience.";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}s:32:"http://purl.org/dc/elements/1.1/";a:1:{s:7:"creator";a:1:{i:0;a:5:{s:4:"data";s:9:"Dave Ross";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}s:27:"http://www.w3.org/2005/Atom";a:1:{s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:0:"";s:7:"attribs";a:1:{s:0:"";a:3:{s:4:"href";s:46:"https://wordpress.org/plugins/rss/view/popular";s:3:"rel";s:4:"self";s:4:"type";s:19:"application/rss+xml";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:12:{s:6:"server";s:5:"nginx";s:4:"date";s:29:"Mon, 05 Oct 2015 12:10:25 GMT";s:12:"content-type";s:23:"text/xml; charset=UTF-8";s:10:"connection";s:5:"close";s:4:"vary";s:15:"Accept-Encoding";s:25:"strict-transport-security";s:11:"max-age=360";s:7:"expires";s:29:"Mon, 05 Oct 2015 12:35:04 GMT";s:13:"cache-control";s:0:"";s:6:"pragma";s:0:"";s:13:"last-modified";s:31:"Mon, 05 Oct 2015 12:00:04 +0000";s:15:"x-frame-options";s:10:"SAMEORIGIN";s:4:"x-nc";s:11:"HIT lax 249";}s:5:"build";s:14:"20151005115503";}', 'no') ; 
INSERT INTO `wp_options` VALUES (126, '_transient_timeout_feed_mod_b9388c83948825c1edaef0d856b7b109', '1444090224', 'no') ; 
INSERT INTO `wp_options` VALUES (127, '_transient_feed_mod_b9388c83948825c1edaef0d856b7b109', '1444047024', 'no') ; 
INSERT INTO `wp_options` VALUES (128, '_transient_timeout_plugin_slugs', '1444136998', 'no') ; 
INSERT INTO `wp_options` VALUES (129, '_transient_plugin_slugs', 'a:10:{i:0;s:35:"backupwordpress/backupwordpress.php";i:1;s:23:"debug-bar/debug-bar.php";i:2;s:51:"fancy-product-designer-3/fancy-product-designer.php";i:3;s:27:"fusion-core/fusion-core.php";i:4;s:9:"hello.php";i:5;s:19:"wpintrojs/index.php";i:6;s:27:"LayerSlider/layerslider.php";i:7;s:23:"revslider/revslider.php";i:8;s:33:"total-security/total-security.php";i:9;s:37:"wp-system-health/wp-system-health.php";}', 'no') ; 
INSERT INTO `wp_options` VALUES (130, '_transient_timeout_dash_898c881de4a92ca37616885905bba3b7', '1444090225', 'no') ; 
INSERT INTO `wp_options` VALUES (131, '_transient_dash_898c881de4a92ca37616885905bba3b7', '<div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://de.wordpress.org/2015/09/15/wordpress-4-3-1-sicherheits-und-wartungs-release-veroeffentlicht/\'>WordPress 4.3.1 Sicherheits- und Wartungs-Release veröffentlicht</a> <span class="rss-date">15. September 2015</span><div class="rssSummary">Seit Kurzem ist WordPress 4.3.1 verfügbar. Dabei handelt es sich um einen Sicherheits-Release und ein Update auf die neue Version sollte dringend vorgenommen werden. Die neue Version schließt drei Sicherheitslücken. So sind WordPress 4.3 und frühere Versionen anfällig durch eine XSS-Lücke bei der Verarbeitung von Shortcode-Tags. Gemeldet wurde diese Lücke durch Shahar Tal und Netanel [&hellip;]</div></li></ul></div><div class="rss-widget"><ul><li><a class=\'rsswidget\' href=\'https://wpletter.de/archive/147/\'>WordPress News #147 / Start in den Backup-Oktober</a></li><li><a class=\'rsswidget\' href=\'https://wpletter.de/archive/146/\'>WordPress News #146 / Child Themes aktuell halten</a></li><li><a class=\'rsswidget\' href=\'https://wpletter.de/archive/145/\'>WordPress News #145 / WordCamp Switzerland</a></li></ul></div><div class="rss-widget"><ul><li class=\'dashboard-news-plugin\'><span>Beliebtes Plugin:</span> <a href=\'https://wordpress.org/plugins/ml-slider/\' class=\'dashboard-news-plugin-link\'>Clef Two-Factor Authentication</a>&nbsp;<span>(<a href=\'plugin-install.php?tab=plugin-information&amp;plugin=ml-slider&amp;_wpnonce=4752d3bb1a&amp;TB_iframe=true&amp;width=600&amp;height=800\' class=\'thickbox\' title=\'Clef Two-Factor Authentication\'>Installieren</a>)</span></li></ul></div>', 'no') ; 
INSERT INTO `wp_options` VALUES (132, 'can_compress_scripts', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (133, '_transient_is_multi_author', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (134, '_transient_twentyfifteen_categories', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (135, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:65:"https://downloads.wordpress.org/release/de_DE/wordpress-4.3.1.zip";s:6:"locale";s:5:"de_DE";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:65:"https://downloads.wordpress.org/release/de_DE/wordpress-4.3.1.zip";s:10:"no_content";b:0;s:11:"new_bundled";b:0;s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1444049832;s:15:"version_checked";s:5:"4.3.1";s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (137, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1444049882;s:7:"checked";a:9:{s:17:"Avada-Child-Theme";s:5:"1.0.0";s:5:"Avada";s:7:"3.8.6.1";s:12:"twentyeleven";s:3:"2.2";s:13:"twentyfifteen";s:3:"1.3";s:14:"twentyfourteen";s:3:"1.5";s:9:"twentyten";s:3:"2.0";s:14:"twentythirteen";s:3:"1.6";s:12:"twentytwelve";s:3:"1.8";s:8:"yeopress";s:3:"0.1";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (138, 'theme_mods_twentyfifteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1444047101;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (139, 'current_theme', 'Avada', 'yes') ; 
INSERT INTO `wp_options` VALUES (140, 'theme_mods_yeopress', 'a:2:{i:0;b:0;s:16:"sidebars_widgets";a:2:{s:4:"time";i:1444049785;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:12:"main-sidebar";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (141, 'theme_switched', '', 'yes') ; 
INSERT INTO `wp_options` VALUES (142, 'recently_activated', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (143, '_site_transient_timeout_theme_roots', '1444051574', 'yes') ; 
INSERT INTO `wp_options` VALUES (144, '_site_transient_theme_roots', 'a:9:{s:17:"Avada-Child-Theme";s:7:"/themes";s:5:"Avada";s:7:"/themes";s:12:"twentyeleven";s:7:"/themes";s:13:"twentyfifteen";s:7:"/themes";s:14:"twentyfourteen";s:7:"/themes";s:9:"twentyten";s:7:"/themes";s:14:"twentythirteen";s:7:"/themes";s:12:"twentytwelve";s:7:"/themes";s:8:"yeopress";s:7:"/themes";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (145, '_site_transient_timeout_wporg_theme_feature_list', '1444060492', 'yes') ; 
INSERT INTO `wp_options` VALUES (146, '_site_transient_wporg_theme_feature_list', 'a:4:{s:6:"Colors";a:15:{i:0;s:5:"black";i:1;s:4:"blue";i:2;s:5:"brown";i:3;s:4:"gray";i:4;s:5:"green";i:5;s:6:"orange";i:6;s:4:"pink";i:7;s:6:"purple";i:8;s:3:"red";i:9;s:6:"silver";i:10;s:3:"tan";i:11;s:5:"white";i:12;s:6:"yellow";i:13;s:4:"dark";i:14;s:5:"light";}s:6:"Layout";a:9:{i:0;s:12:"fixed-layout";i:1;s:12:"fluid-layout";i:2;s:17:"responsive-layout";i:3;s:10:"one-column";i:4;s:11:"two-columns";i:5;s:13:"three-columns";i:6;s:12:"four-columns";i:7;s:12:"left-sidebar";i:8;s:13:"right-sidebar";}s:8:"Features";a:20:{i:0;s:19:"accessibility-ready";i:1;s:8:"blavatar";i:2;s:10:"buddypress";i:3;s:17:"custom-background";i:4;s:13:"custom-colors";i:5;s:13:"custom-header";i:6;s:11:"custom-menu";i:7;s:12:"editor-style";i:8;s:21:"featured-image-header";i:9;s:15:"featured-images";i:10;s:15:"flexible-header";i:11;s:20:"front-page-post-form";i:12;s:19:"full-width-template";i:13;s:12:"microformats";i:14;s:12:"post-formats";i:15;s:20:"rtl-language-support";i:16;s:11:"sticky-post";i:17;s:13:"theme-options";i:18;s:17:"threaded-comments";i:19;s:17:"translation-ready";}s:7:"Subject";a:3:{i:0;s:7:"holiday";i:1;s:13:"photoblogging";i:2;s:8:"seasonal";}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (147, 'theme_mods_Avada', 'a:1:{i:0;b:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (148, 'avada_dynamic_css_time', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (149, 'avada_version', '3.8.5', 'yes') ; 
INSERT INTO `wp_options` VALUES (150, 'Avada_options', 'a:780:{s:15:"heading_general";s:0:"";s:10:"responsive";i:1;s:11:"mobile_zoom";i:1;s:12:"ipad_potrait";i:0;s:4:"code";s:81:"<h3 style=\'margin: 0;\'>Tracking / Space Before Head / Space Before Body Code</h3>";s:16:"google_analytics";s:0:"";s:10:"space_head";s:0:"";s:10:"space_body";s:0:"";s:18:"heading_site_width";s:0:"";s:6:"layout";s:4:"Wide";s:10:"site_width";s:6:"1100px";s:21:"content_sidebar_width";s:139:"<h3 style=\'margin: 0;\'>Content + Sidebar Width</h3><p>These settings are used on pages with 1 sidebar. Total values must add up to 100.</p>";s:13:"content_width";s:3:"77%";s:13:"sidebar_width";s:3:"23%";s:29:"content_sidebar_sidebar_width";s:150:"<h3 style=\'margin: 0;\'>Content + Sidebar + Sidebar Width</h3><p>These settings are used on pages with 2 sidebars. Total values must add up to 100.</p>";s:15:"content_width_2";s:3:"58%";s:17:"sidebar_2_1_width";s:3:"21%";s:17:"sidebar_2_2_width";s:3:"21%";s:14:"heading_header";s:0:"";s:13:"header_info_1";s:50:"<h3 style=\'margin: 0;\'>Header Content Options</h3>";s:15:"header_position";s:3:"Top";s:13:"header_layout";s:2:"v1";s:17:"side_header_width";s:5:"280px";s:23:"side_header_break_point";s:6:"1023px";s:13:"header_shadow";i:0;s:16:"header_100_width";i:0;s:15:"slider_position";s:5:"Below";s:19:"header_left_content";s:12:"Contact Info";s:20:"header_right_content";s:10:"Navigation";s:17:"header_v4_content";s:18:"Tagline And Search";s:13:"header_number";s:28:"Call Us Today! 1.555.555.555";s:12:"header_email";s:19:"info@yourdomain.com";s:18:"header_banner_code";s:0:"";s:14:"header_tagline";s:19:"Insert Tagline Here";s:13:"header_info_2";s:45:"<h3 style=\'margin: 0;\'>Header Background</h3>";s:15:"header_bg_image";s:0:"";s:14:"header_bg_full";i:0;s:18:"header_bg_parallax";i:1;s:16:"header_bg_repeat";s:0:"";s:17:"margin_header_top";s:3:"0px";s:20:"margin_header_bottom";s:3:"0px";s:19:"padding_header_left";s:3:"0px";s:20:"padding_header_right";s:3:"0px";s:13:"header_info_3";s:47:"<h3 style=\'margin: 0;\'>Header Social Icons</h3>";s:29:"header_social_links_font_size";s:2:"16";s:30:"header_social_links_icon_color";s:7:"#bebdbd";s:25:"header_social_links_boxed";s:2:"No";s:29:"header_social_links_box_color";s:7:"#e8e8e8";s:32:"header_social_links_boxed_radius";s:3:"4px";s:33:"header_social_links_boxed_padding";s:1:"8";s:37:"header_social_links_tooltip_placement";s:6:"Bottom";s:21:"heading_sticky_header";s:0:"";s:18:"sticky_header_info";s:49:"<h3 style=\'margin: 0;\'>Sticky Header Options</h3>";s:13:"header_sticky";i:1;s:20:"header_sticky_tablet";i:0;s:20:"header_sticky_mobile";i:0;s:23:"header_sticky_shrinkage";i:1;s:26:"header_sticky_type2_layout";s:9:"Menu Only";s:25:"header_sticky_nav_padding";s:0:"";s:27:"header_sticky_nav_font_size";s:0:"";s:12:"heading_logo";s:0:"";s:11:"header_info";s:46:"<h3 style=\'margin: 0;\'>Breadcrumb Options</h3>";s:4:"logo";s:67:"http://duktor-wordpress/content/themes/Avada/assets/images/logo.png";s:11:"logo_retina";s:0:"";s:17:"retina_logo_width";s:0:"";s:18:"retina_logo_height";s:0:"";s:19:"sticky_logo_wrapper";s:46:"<h3 style=\'margin: 0;\'>Sticky Header Logo</h3>";s:18:"sticky_header_logo";s:0:"";s:25:"sticky_header_logo_retina";s:0:"";s:24:"sticky_retina_logo_width";s:0:"";s:25:"sticky_retina_logo_height";s:0:"";s:19:"mobile_logo_wrapper";s:39:"<h3 style=\'margin: 0;\'>Mobile Logo</h3>";s:11:"mobile_logo";s:0:"";s:18:"mobile_logo_retina";s:0:"";s:24:"mobile_retina_logo_width";s:0:"";s:25:"mobile_retina_logo_height";s:0:"";s:21:"logo_settings_wrapper";s:41:"<h3 style=\'margin: 0;\'>Logo Settings</h3>";s:14:"logo_alignment";s:4:"Left";s:16:"margin_logo_left";s:3:"0px";s:17:"margin_logo_right";s:3:"0px";s:15:"margin_logo_top";s:4:"31px";s:18:"margin_logo_bottom";s:4:"31px";s:8:"favicons";s:43:"<h3 style=\'margin: 0;\'>Favicon Options</h3>";s:7:"favicon";s:0:"";s:11:"iphone_icon";s:0:"";s:18:"iphone_icon_retina";s:0:"";s:9:"ipad_icon";s:0:"";s:16:"ipad_icon_retina";s:0:"";s:12:"heading_menu";s:0:"";s:15:"menu_text_align";s:4:"left";s:10:"nav_height";s:2:"83";s:20:"nav_highlight_border";s:1:"3";s:11:"nav_padding";s:2:"45";s:19:"dropdown_menu_width";s:5:"170px";s:34:"mainmenu_dropdown_vertical_padding";s:3:"7px";s:33:"mainmenu_dropdown_display_divider";i:1;s:23:"topmenu_dropwdown_width";s:5:"100px";s:18:"megamenu_max_width";s:6:"1100px";s:19:"megamenu_title_size";s:4:"18px";s:30:"megamenu_item_vertical_padding";s:3:"5px";s:29:"megamenu_item_display_divider";i:0;s:31:"menu_display_dropdown_indicator";i:0;s:15:"megamenu_shadow";i:1;s:20:"main_nav_search_icon";i:1;s:20:"main_nav_icon_circle";i:0;s:19:"mobile_menu_options";s:47:"<h3 style=\'margin: 0;\'>Mobile Menu Options</h3>";s:18:"mobile_menu_design";s:6:"modern";s:18:"mobile_nav_padding";s:2:"25";s:22:"mobile_menu_text_align";s:4:"left";s:28:"mobile_menu_icons_top_margin";s:3:"0px";s:22:"mobile_menu_nav_height";s:2:"35";s:27:"mobile_nav_submenu_slideout";i:1;s:22:"heading_page_title_bar";s:0:"";s:14:"page_title_bar";s:15:"bar_and_content";s:19:"page_title_bar_text";s:3:"yes";s:20:"page_title_100_width";i:0;s:17:"page_title_height";s:4:"87px";s:24:"page_title_mobile_height";s:4:"70px";s:20:"page_title_alignment";s:4:"left";s:13:"page_title_bg";s:76:"http://duktor-wordpress/content/themes/Avada/assets/images/page_title_bg.png";s:20:"page_title_bg_retina";s:0:"";s:18:"page_title_bg_full";i:0;s:22:"page_title_bg_parallax";i:0;s:17:"page_title_fading";i:0;s:17:"page_title_bar_bs";s:11:"Breadcrumbs";s:17:"breadcrumb_mobile";i:0;s:16:"breacrumb_prefix";s:0:"";s:20:"breadcrumb_separator";s:1:"/";s:33:"breadcrumb_show_post_type_archive";i:0;s:26:"breadcrumb_show_categories";i:1;s:19:"heading_sliding_bar";s:0:"";s:11:"sliding_bar";s:47:"<h3 style=\'margin: 0;\'>Sliding Bar Options</h3>";s:18:"slidingbar_widgets";i:1;s:25:"mobile_slidingbar_widgets";i:1;s:21:"slidingbar_top_border";i:0;s:23:"slidingbar_open_on_load";i:0;s:26:"slidingbar_widgets_columns";s:1:"2";s:14:"heading_footer";s:0:"";s:25:"footer_widgets_area_title";s:55:"<h3 style=\'margin: 0;\'>Footer Widgets Area Options</h3>";s:16:"footer_100_width";i:0;s:22:"footer_special_effects";s:4:"none";s:27:"footer_parallax_effect_info";s:59:"This enables a fixed footer with parallax scrolling effect.";s:28:"footer_area_bg_parallax_info";s:115:"This enables a parallax effect on the background image selected in \'Background Image For Footer Widget Area\' field.";s:18:"footer_sticky_info";s:144:"This enables a sticky footer. The entire footer area will always be \'below the fold\'. IMPORTANT: \'Sticky Footer Height\' field must be filled in.";s:41:"footer_sticky_with_parallax_bg_image_info";s:200:"This enables a sticky footer together with a parallax effect on the background image. The entire footer area will always be \'below the fold\'. IMPORTANT: \'Sticky Footer Height\' field must be filled in.";s:20:"footer_sticky_height";s:0:"";s:14:"footer_widgets";i:1;s:22:"footer_widgets_columns";s:1:"4";s:16:"footerw_bg_image";s:0:"";s:15:"footerw_bg_full";i:0;s:17:"footerw_bg_repeat";s:0:"";s:14:"footerw_bg_pos";s:13:"center center";s:23:"footer_area_top_padding";s:4:"43px";s:26:"footer_area_bottom_padding";s:4:"40px";s:24:"footer_area_left_padding";s:3:"0px";s:25:"footer_area_right_padding";s:3:"0px";s:20:"copyright_area_title";s:57:"<h3 style=\'margin: 0;\'>Footer Copyright Area Options</h3>";s:16:"footer_copyright";i:1;s:11:"footer_text";s:155:"Copyright 2012 Avada | All Rights Reserved | Powered by <a href="http://wordpress.org">WordPress</a>  |  <a href="http://theme-fusion.com">Theme Fusion</a>";s:21:"copyright_top_padding";s:4:"18px";s:24:"copyright_bottom_padding";s:4:"16px";s:24:"footer_social_icon_title";s:47:"<h3 style=\'margin: 0;\'>Social Icon Options</h3>";s:12:"icons_footer";i:1;s:29:"footer_social_links_font_size";s:2:"16";s:30:"footer_social_links_icon_color";s:7:"#46494a";s:25:"footer_social_links_boxed";s:2:"No";s:29:"footer_social_links_box_color";s:7:"#222222";s:32:"footer_social_links_boxed_radius";s:3:"4px";s:33:"footer_social_links_boxed_padding";s:1:"8";s:37:"footer_social_links_tooltip_placement";s:3:"Top";s:16:"heading_sidebars";s:0:"";s:14:"pages_sidebars";s:33:"<h3 style=\'margin: 0;\'>Pages</h3>";s:20:"pages_global_sidebar";i:0;s:13:"pages_sidebar";s:4:"None";s:15:"pages_sidebar_2";s:4:"None";s:19:"default_sidebar_pos";s:5:"Right";s:12:"bbpress_only";s:35:"<h3 style=\'margin: 0;\'>BBPress</h3>";s:24:"portfolio_global_sidebar";i:0;s:17:"portfolio_sidebar";s:4:"None";s:19:"portfolio_sidebar_2";s:4:"None";s:26:"portfolio_sidebar_position";s:5:"Right";s:25:"portfolio_archive_sidebar";s:4:"None";s:27:"portfolio_archive_sidebar_2";s:4:"None";s:20:"posts_global_sidebar";i:0;s:13:"posts_sidebar";s:4:"None";s:15:"posts_sidebar_2";s:4:"None";s:21:"blog_sidebar_position";s:5:"Right";s:20:"blog_archive_sidebar";s:4:"None";s:22:"blog_archive_sidebar_2";s:4:"None";s:18:"woo_global_sidebar";i:0;s:11:"woo_sidebar";s:4:"None";s:13:"woo_sidebar_2";s:4:"None";s:20:"woo_sidebar_position";s:5:"Right";s:27:"woocommerce_archive_sidebar";s:4:"None";s:29:"woocommerce_archive_sidebar_2";s:4:"None";s:22:"bbpress_global_sidebar";i:0;s:15:"ppbress_sidebar";s:4:"None";s:17:"ppbress_sidebar_2";s:4:"None";s:24:"bbpress_sidebar_position";s:5:"Right";s:11:"search_only";s:39:"<h3 style=\'margin: 0;\'>Search Page</h3>";s:14:"search_sidebar";s:12:"Blog Sidebar";s:16:"search_sidebar_2";s:4:"None";s:23:"search_sidebar_position";s:5:"Right";s:18:"heading_background";s:0:"";s:15:"boxed_mode_only";s:76:"<h3 style=\'margin: 0;\'>Background options below only work in boxed mode</h3>";s:8:"bg_image";s:0:"";s:7:"bg_full";i:0;s:9:"bg_repeat";s:0:"";s:8:"bg_color";s:7:"#d7d6d6";s:17:"bg_pattern_option";i:0;s:10:"bg_pattern";s:8:"pattern1";s:15:"both_modes_only";s:79:"<h3 style=\'margin: 0;\'>Background Options Below Work For Boxed & Wide Mode</h3>";s:16:"content_bg_image";s:0:"";s:15:"content_bg_full";i:0;s:17:"content_bg_repeat";s:0:"";s:18:"heading_typography";s:0:"";s:19:"custom_heading_font";s:174:"<h3 style=\'margin: 0;\'>Custom Font For Menus And Headings</h3><p style=\'margin-bottom:0;\'>This will override the google / standard font options. All 4 files are required.</p>";s:16:"custom_font_woff";s:0:"";s:15:"custom_font_ttf";s:0:"";s:15:"custom_font_svg";s:0:"";s:15:"custom_font_eot";s:0:"";s:18:"google_fonts_intro";s:113:"<h3 style=\'margin: 0;\'>Google Fonts</h3><p style=\'margin-bottom:0;\'>This will override standard font options.</p>";s:11:"google_body";s:7:"PT Sans";s:10:"google_nav";s:10:"Antic Slab";s:15:"google_headings";s:10:"Antic Slab";s:22:"google_footer_headings";s:7:"PT Sans";s:13:"google_button";s:7:"PT Sans";s:14:"gfont_settings";s:40:"400,400italic,700,700italic&subset=latin";s:20:"standard_fonts_intro";s:42:"<h3 style=\'margin: 0;\'>Standard Fonts</h3>";s:13:"standard_body";s:0:"";s:12:"standard_nav";s:0:"";s:17:"standard_headings";s:0:"";s:24:"standard_footer_headings";s:0:"";s:15:"standard_button";s:0:"";s:15:"font_size_intro";s:38:"<h3 style=\'margin: 0;\'>Font Sizes</h3>";s:21:"typography_responsive";i:0;s:22:"typography_sensitivity";s:3:"0.6";s:17:"typography_factor";s:3:"1.5";s:14:"body_font_size";s:2:"13";s:13:"nav_font_size";s:2:"14";s:22:"nav_dropdown_font_size";s:2:"13";s:14:"snav_font_size";s:2:"12";s:18:"side_nav_font_size";s:2:"14";s:21:"mobile_menu_font_size";s:2:"12";s:21:"breadcrumbs_font_size";s:2:"10";s:15:"sidew_font_size";s:2:"13";s:20:"slidingbar_font_size";s:2:"13";s:15:"footw_font_size";s:2:"13";s:19:"copyright_font_size";s:2:"12";s:12:"h1_font_size";s:2:"34";s:12:"h2_font_size";s:2:"18";s:12:"h3_font_size";s:2:"16";s:12:"h4_font_size";s:2:"13";s:12:"h5_font_size";s:2:"12";s:12:"h6_font_size";s:2:"11";s:21:"post_titles_font_size";s:2:"18";s:28:"post_titles_extras_font_size";s:2:"18";s:17:"tagline_font_size";s:2:"16";s:14:"meta_font_size";s:2:"12";s:20:"page_title_font_size";s:2:"18";s:30:"page_title_subheader_font_size";s:2:"14";s:20:"pagination_font_size";s:2:"12";s:18:"woo_icon_font_size";s:2:"12";s:25:"font_line_heights_wrapper";s:45:"<h3 style=\'margin: 0;\'>Font Line Heights</h3>";s:12:"body_font_lh";s:2:"20";s:10:"h1_font_lh";s:2:"48";s:10:"h2_font_lh";s:2:"27";s:10:"h3_font_lh";s:2:"24";s:10:"h4_font_lh";s:2:"20";s:10:"h5_font_lh";s:2:"18";s:10:"h6_font_lh";s:2:"17";s:19:"post_titles_font_lh";s:2:"27";s:11:"sec_menu_lh";s:2:"44";s:20:"font_weights_wrapper";s:40:"<h3 style=\'margin: 0;\'>Font Weights</h3>";s:24:"font_weights_description";s:414:"<ul class=\'list\'><li>If you use a custom font, the font weight will correspond to the font weight of the uploaded files, thus these settings do not apply.</li><li>If you use a google font, make sure to load the font weight in \'Google Font Settings\' field that corresponds to the one in parenthesis here.</li><li>Browser standard fonts in general support only \'Normal (400)\' and \'Bold (700)\' font weights.</li></ul>";s:16:"font_weight_body";s:3:"400";s:16:"font_weight_menu";s:3:"400";s:20:"font_weight_headings";s:3:"400";s:27:"font_weight_footer_headings";s:3:"400";s:18:"font_weight_button";s:3:"700";s:27:"font_letter_spacing_wrapper";s:47:"<h3 style=\'margin: 0;\'>Font Letter Spacing</h3>";s:10:"h1_font_ls";s:1:"0";s:10:"h2_font_ls";s:1:"0";s:10:"h3_font_ls";s:1:"0";s:10:"h4_font_ls";s:1:"0";s:10:"h5_font_ls";s:1:"0";s:10:"h6_font_ls";s:1:"0";s:12:"menu_font_ls";s:1:"0";s:14:"button_font_ls";s:1:"0";s:20:"font_margins_wrapper";s:40:"<h3 style=\'margin: 0;\'>Font Margins</h3>";s:13:"h1_top_margin";s:4:"0.67";s:16:"h1_bottom_margin";s:4:"0.67";s:13:"h2_top_margin";s:1:"0";s:16:"h2_bottom_margin";s:3:"1.1";s:13:"h3_top_margin";s:1:"1";s:16:"h3_bottom_margin";s:1:"1";s:13:"h4_top_margin";s:4:"1.33";s:16:"h4_bottom_margin";s:4:"1.33";s:13:"h5_top_margin";s:4:"1.67";s:16:"h5_bottom_margin";s:4:"1.67";s:13:"h6_top_margin";s:4:"2.33";s:16:"h6_bottom_margin";s:4:"2.33";s:15:"heading_styling";s:0:"";s:11:"scheme_type";s:5:"Light";s:12:"color_scheme";s:5:"Green";s:17:"bg_colors_wrapper";s:45:"<h3 style=\'margin: 0;\'>Background Colors</h3>";s:13:"primary_color";s:7:"#a0ce4e";s:19:"slidingbar_bg_color";a:2:{s:5:"color";s:7:"#363839";s:7:"opacity";s:1:"1";}s:15:"header_bg_color";a:2:{s:5:"color";s:7:"#ffffff";s:7:"opacity";s:1:"1";}s:22:"header_sticky_bg_color";a:2:{s:5:"color";s:7:"#ffffff";s:7:"opacity";s:4:"0.97";}s:19:"header_border_color";s:7:"#e5e5e5";s:19:"header_top_bg_color";s:7:"#a0ce4e";s:19:"page_title_bg_color";s:7:"#F6F6F6";s:23:"page_title_border_color";s:7:"#d2d3d4";s:16:"content_bg_color";s:7:"#ffffff";s:16:"sidebar_bg_color";s:11:"transparent";s:15:"footer_bg_color";s:7:"#363839";s:19:"footer_border_color";s:7:"#e9eaee";s:18:"copyright_bg_color";s:7:"#282a2b";s:22:"copyright_border_color";s:7:"#4b4c4d";s:22:"element_colors_wrapper";s:42:"<h3 style=\'margin: 0;\'>Element Colors</h3>";s:24:"image_gradient_top_color";a:2:{s:5:"color";s:7:"#a0ce4e";s:7:"opacity";s:3:"0.8";}s:27:"image_gradient_bottom_color";s:7:"#a0ce4e";s:25:"image_rollover_text_color";s:7:"#333333";s:25:"image_rollover_icon_color";s:7:"#ffffff";s:28:"slidingbar_toggle_icon_color";s:7:"#ffffff";s:24:"slidingbar_divider_color";s:7:"#282A2B";s:20:"footer_divider_color";s:7:"#505152";s:13:"form_bg_color";s:7:"#ffffff";s:15:"form_text_color";s:7:"#aaa9a9";s:17:"form_border_color";s:7:"#d2d2d2";s:17:"timeline_bg_color";s:11:"transparent";s:14:"timeline_color";s:7:"#ebeaea";s:31:"load_more_posts_button_bg_color";s:7:"#ebeaea";s:12:"qty_bg_color";s:7:"#fbfaf9";s:18:"qty_bg_hover_color";s:7:"#ffffff";s:21:"woo_dropdown_bg_color";s:7:"#fbfaf9";s:23:"woo_dropdown_text_color";s:7:"#333333";s:25:"woo_dropdown_border_color";s:7:"#dbdbdb";s:19:"bbp_forum_header_bg";s:7:"#ebeaea";s:22:"bbp_forum_border_color";s:7:"#ebeaea";s:23:"element_options_wrapper";s:42:"<h3 style=\'margin: 0;\'>Layout Options</h3>";s:16:"main_top_padding";s:4:"55px";s:19:"main_bottom_padding";s:4:"40px";s:16:"hundredp_padding";s:4:"30px";s:15:"sidebar_padding";s:1:"0";s:14:"col_top_margin";s:3:"0px";s:17:"col_bottom_margin";s:4:"20px";s:22:"slidingbar_text_shadow";i:1;s:20:"rollover_text_shadow";i:1;s:18:"footer_text_shadow";i:1;s:19:"font_colors_wrapper";s:39:"<h3 style=\'margin: 0;\'>Font Colors</h3>";s:18:"tagline_font_color";s:7:"#747474";s:16:"page_title_color";s:7:"#333333";s:8:"h1_color";s:7:"#333333";s:8:"h2_color";s:7:"#333333";s:8:"h3_color";s:7:"#333333";s:8:"h4_color";s:7:"#333333";s:8:"h5_color";s:7:"#333333";s:8:"h6_color";s:7:"#333333";s:15:"body_text_color";s:7:"#747474";s:10:"link_color";s:7:"#333333";s:22:"breadcrumbs_text_color";s:7:"#333333";s:25:"slidingbar_headings_color";s:7:"#DDDDDD";s:21:"slidingbar_text_color";s:7:"#8C8989";s:21:"slidingbar_link_color";s:7:"#BFBFBF";s:21:"sidebar_heading_color";s:7:"#333333";s:21:"footer_headings_color";s:7:"#DDDDDD";s:17:"footer_text_color";s:7:"#8C8989";s:17:"footer_link_color";s:7:"#BFBFBF";s:24:"main_menu_colors_wrapper";s:44:"<h3 style=\'margin: 0;\'>Main Menu Colors</h3>";s:17:"menu_h45_bg_color";s:7:"#FFFFFF";s:16:"menu_first_color";s:7:"#333333";s:22:"menu_hover_first_color";s:7:"#a0ce4e";s:17:"menu_sub_bg_color";s:7:"#f2efef";s:19:"menu_bg_hover_color";s:7:"#f8f8f8";s:14:"menu_sub_color";s:7:"#333333";s:18:"menu_sub_sep_color";s:7:"#dcdadb";s:17:"woo_cart_bg_color";s:7:"#fafafa";s:17:"menu_colors_intro";s:49:"<h3 style=\'margin: 0;\'>Secondary Menu Colors</h3>";s:10:"snav_color";s:7:"#747474";s:29:"header_top_first_border_color";s:7:"#e5e5e5";s:23:"header_top_sub_bg_color";s:7:"#ffffff";s:25:"header_top_menu_sub_color";s:7:"#747474";s:30:"header_top_menu_bg_hover_color";s:7:"#fafafa";s:31:"header_top_menu_sub_hover_color";s:7:"#333333";s:29:"header_top_menu_sub_sep_color";s:7:"#e5e5e5";s:26:"mobile_menu_colors_wrapper";s:46:"<h3 style=\'margin: 0;\'>Mobile Menu Colors</h3>";s:22:"mobile_header_bg_color";s:7:"#ffffff";s:28:"mobile_menu_background_color";s:7:"#f9f9f9";s:24:"mobile_menu_border_color";s:7:"#dadada";s:23:"mobile_menu_hover_color";s:7:"#f6f6f6";s:22:"mobile_menu_font_color";s:7:"#333333";s:24:"mobile_menu_toggle_color";s:7:"#dadada";s:25:"heading_shortcode_styling";s:0:"";s:14:"blog_shortcode";s:42:"<h3 style=\'margin: 0;\'>Blog Shortcode</h3>";s:15:"dates_box_color";s:7:"#eef0f2";s:16:"button_shortcode";s:44:"<h3 style=\'margin: 0;\'>Button Shortcode</h3>";s:11:"button_size";s:5:"Large";s:12:"button_shape";s:5:"Round";s:11:"button_type";s:4:"Flat";s:25:"button_gradient_top_color";s:7:"#a0ce4e";s:28:"button_gradient_bottom_color";s:7:"#a0ce4e";s:31:"button_gradient_top_color_hover";s:7:"#96c346";s:34:"button_gradient_bottom_color_hover";s:7:"#96c346";s:19:"button_accent_color";s:4:"#fff";s:25:"button_accent_hover_color";s:4:"#fff";s:18:"button_bevel_color";s:7:"#54770F";s:19:"button_border_width";s:3:"0px";s:18:"carousel_shortcode";s:46:"<h3 style=\'margin: 0;\'>Carousel Shortcode</h3>";s:18:"carousel_nav_color";s:15:"rgba(0,0,0,0.6)";s:20:"carousel_hover_color";s:15:"rgba(0,0,0,0.7)";s:14:"carousel_speed";s:4:"2500";s:19:"checklist_shortcode";s:47:"<h3 style=\'margin: 0;\'>Checklist Shortcode</h3>";s:16:"checklist_circle";i:1;s:22:"checklist_circle_color";s:7:"#a0ce4e";s:21:"checklist_icons_color";s:7:"#ffffff";s:12:"cb_shortcode";s:49:"<h3 style=\'margin: 0;\'>Content Box Shortcode</h3>";s:20:"content_box_bg_color";s:11:"transparent";s:22:"content_box_title_size";s:2:"18";s:23:"content_box_title_color";s:0:"";s:22:"content_box_body_color";s:0:"";s:23:"content_box_icon_circle";s:3:"yes";s:30:"content_box_icon_circle_radius";s:5:"round";s:22:"content_box_icon_color";s:7:"#ffffff";s:25:"content_box_icon_bg_color";s:7:"#333333";s:38:"content_box_icon_bg_inner_border_color";s:7:"#333333";s:37:"content_box_icon_bg_inner_border_size";s:3:"1px";s:38:"content_box_icon_bg_outer_border_color";s:0:"";s:37:"content_box_icon_bg_outer_border_size";s:0:"";s:21:"content_box_icon_size";s:2:"21";s:27:"content_box_icon_hover_type";s:4:"fade";s:21:"content_box_link_type";s:4:"text";s:21:"content_box_link_area";s:9:"link-icon";s:23:"content_box_link_target";s:5:"_self";s:22:"content_box_margin_top";s:3:"0px";s:25:"content_box_margin_bottom";s:4:"60px";s:18:"counterb_shortcode";s:51:"<h3 style=\'margin: 0;\'>Counter Boxes Shortcode</h3>";s:17:"counter_box_color";s:7:"#a0ce4e";s:22:"counter_box_title_size";s:2:"50";s:21:"counter_box_icon_size";s:2:"50";s:22:"counter_box_body_color";s:7:"#747474";s:21:"counter_box_body_size";s:2:"13";s:24:"counter_box_border_color";s:7:"#e0dede";s:20:"counter_box_icon_top";s:2:"no";s:12:"cc_shortcode";s:52:"<h3 style=\'margin: 0;\'>Counter Circle Shortcode</h3>";s:20:"counter_filled_color";s:7:"#a0ce4e";s:22:"counter_unfilled_color";s:7:"#f6f6f6";s:17:"dropcap_shortcode";s:45:"<h3 style=\'margin: 0;\'>Dropcap Shortcode</h3>";s:13:"dropcap_color";s:7:"#a0ce4e";s:15:"flipb_shortcode";s:48:"<h3 style=\'margin: 0;\'>Flip Boxes Shortcode</h3>";s:19:"flip_boxes_front_bg";s:7:"#f6f6f6";s:24:"flip_boxes_front_heading";s:7:"#333333";s:21:"flip_boxes_front_text";s:7:"#747474";s:18:"flip_boxes_back_bg";s:7:"#a0ce4e";s:23:"flip_boxes_back_heading";s:7:"#eeeded";s:20:"flip_boxes_back_text";s:7:"#ffffff";s:22:"flip_boxes_border_size";s:3:"1px";s:23:"flip_boxes_border_color";s:11:"transparent";s:24:"flip_boxes_border_radius";s:3:"4px";s:19:"fullwidth_shortcode";s:48:"<h3 style=\'margin: 0;\'>Full Width Shortcode</h3>";s:19:"full_width_bg_color";s:0:"";s:22:"full_width_border_size";s:3:"0px";s:23:"full_width_border_color";s:7:"#eae9e9";s:14:"icon_shortcode";s:42:"<h3 style=\'margin: 0;\'>Icon Shortcode</h3>";s:17:"icon_circle_color";s:7:"#333333";s:17:"icon_border_color";s:7:"#333333";s:10:"icon_color";s:7:"#ffffff";s:14:"imgf_shortcode";s:49:"<h3 style=\'margin: 0;\'>Image Frame Shortcode</h3>";s:21:"imgframe_border_color";s:7:"#f6f6f6";s:22:"imageframe_border_size";s:3:"0px";s:24:"imageframe_border_radius";s:3:"0px";s:20:"imgframe_style_color";s:7:"#000000";s:15:"modal_shortcode";s:43:"<h3 style=\'margin: 0;\'>Modal Shortcode</h3>";s:14:"modal_bg_color";s:7:"#f6f6f6";s:18:"modal_border_color";s:7:"#ebebeb";s:16:"person_shortcode";s:44:"<h3 style=\'margin: 0;\'>Person Shortcode</h3>";s:19:"person_border_color";s:7:"#f6f6f6";s:18:"person_border_size";s:3:"0px";s:20:"person_border_radius";s:3:"0px";s:18:"person_style_color";s:7:"#000000";s:17:"popover_shortcode";s:45:"<h3 style=\'margin: 0;\'>Popover Shortcode</h3>";s:24:"popover_heading_bg_color";s:7:"#f6f6f6";s:24:"popover_content_bg_color";s:7:"#ffffff";s:20:"popover_border_color";s:7:"#ebebeb";s:18:"popover_text_color";s:7:"#747474";s:17:"popover_placement";s:3:"Top";s:22:"pricingtable_shortcode";s:51:"<h3 style=\'margin: 0;\'>Pricing Table Shortcode</h3>";s:36:"full_boxed_pricing_box_heading_color";s:7:"#333333";s:29:"sep_pricing_box_heading_color";s:7:"#333333";s:17:"pricing_box_color";s:7:"#a0ce4e";s:16:"pricing_bg_color";s:7:"#ffffff";s:20:"pricing_border_color";s:7:"#f8f8f8";s:21:"pricing_divider_color";s:7:"#ededed";s:21:"progressbar_shortcode";s:50:"<h3 style=\'margin: 0;\'>Progress Bar Shortcode</h3>";s:24:"progressbar_filled_color";s:7:"#a0ce4e";s:31:"progressbar_filled_border_color";s:0:"";s:30:"progressbar_filled_border_size";s:0:"";s:26:"progressbar_unfilled_color";s:7:"#f6f6f6";s:22:"progressbar_text_color";s:7:"#ffffff";s:26:"sectionseparator_shortcode";s:55:"<h3 style=\'margin: 0;\'>Section Separator Shortcode</h3>";s:23:"section_sep_border_size";s:3:"1px";s:14:"section_sep_bg";s:7:"#f6f6f6";s:24:"section_sep_border_color";s:7:"#f6f6f6";s:19:"separator_shortcode";s:47:"<h3 style=\'margin: 0;\'>Separator Shortcode</h3>";s:9:"sep_color";s:7:"#e0dede";s:16:"separator_circle";i:1;s:21:"separator_border_size";s:3:"1px";s:20:"sharingbox_shortcode";s:49:"<h3 style=\'margin: 0;\'>Sharing Box Shortcode</h3>";s:20:"sharing_box_bg_color";s:7:"#f6f6f6";s:30:"sharing_box_tagline_text_color";s:7:"#333333";s:21:"sociallinks_shortcode";s:50:"<h3 style=\'margin: 0;\'>Social Links Shortcode</h3>";s:22:"social_links_font_size";s:2:"16";s:23:"social_links_icon_color";s:7:"#bebdbd";s:18:"social_links_boxed";s:2:"No";s:22:"social_links_box_color";s:7:"#e8e8e8";s:25:"social_links_boxed_radius";s:3:"4px";s:26:"social_links_boxed_padding";s:1:"8";s:30:"social_links_tooltip_placement";s:3:"Top";s:14:"tabs_shortcode";s:42:"<h3 style=\'margin: 0;\'>Tabs Shortcode</h3>";s:13:"tabs_bg_color";s:7:"#ffffff";s:19:"tabs_inactive_color";s:7:"#ebeaea";s:17:"tabs_border_color";s:7:"#ebeaea";s:17:"tagline_shortcode";s:45:"<h3 style=\'margin: 0;\'>Tagline Shortcode</h3>";s:10:"tagline_bg";s:7:"#f6f6f6";s:20:"tagline_border_color";s:7:"#f6f6f6";s:18:"tagline_margin_top";s:0:"";s:21:"tagline_margin_bottom";s:2:"84";s:22:"testimonials_shortcode";s:50:"<h3 style=\'margin: 0;\'>Testimonials Shortcode</h3>";s:20:"testimonial_bg_color";s:7:"#f6f6f6";s:22:"testimonial_text_color";s:7:"#747474";s:18:"testimonials_speed";s:4:"4000";s:19:"testimonials_random";i:0;s:15:"title_shortcode";s:43:"<h3 style=\'margin: 0;\'>Title Shortcode</h3>";s:16:"title_style_type";s:6:"double";s:18:"title_border_color";s:7:"#e0dede";s:16:"title_top_margin";s:0:"";s:19:"title_bottom_margin";s:0:"";s:19:"accordion_shortcode";s:45:"<h3 style=\'margin: 0;\'>Toggles Shortcode</h3>";s:22:"accordion_divider_line";i:1;s:24:"accordian_inactive_color";s:7:"#333333";s:12:"heading_blog";s:0:"";s:16:"blog_single_post";s:62:"<h3 style=\'margin: 0;\'>Portfolio Single Post Page Options</h3>";s:10:"blog_title";s:4:"Blog";s:13:"blog_subtitle";s:0:"";s:24:"blog_show_page_title_bar";i:1;s:11:"blog_layout";s:5:"Large";s:19:"blog_archive_layout";s:5:"Large";s:20:"blog_pagination_type";s:10:"Pagination";s:17:"blog_grid_columns";s:1:"3";s:24:"blog_grid_column_spacing";s:2:"40";s:14:"content_length";s:7:"Excerpt";s:19:"excerpt_length_blog";s:2:"55";s:18:"strip_html_excerpt";i:1;s:15:"featured_images";i:1;s:32:"alternate_date_format_month_year";s:4:"m, Y";s:25:"alternate_date_format_day";s:1:"j";s:20:"timeline_date_format";s:3:"F Y";s:22:"featured_images_single";i:1;s:11:"blog_pn_nav";i:0;s:15:"blog_post_title";i:1;s:11:"author_info";i:1;s:18:"social_sharing_box";i:1;s:13:"related_posts";s:52:"<h3 style=\'margin: 0;\'>Related Posts / Projects</h3>";s:13:"blog_comments";i:1;s:9:"blog_meta";s:45:"<h3 style=\'margin: 0;\'>Blog Meta Options</h3>";s:9:"post_meta";i:1;s:16:"post_meta_author";i:0;s:14:"post_meta_date";i:0;s:14:"post_meta_cats";i:0;s:18:"post_meta_comments";i:0;s:14:"post_meta_read";i:0;s:14:"post_meta_tags";i:1;s:11:"date_format";s:7:"F jS, Y";s:17:"heading_portfolio";s:0:"";s:15:"portfolio_items";s:2:"10";s:24:"portfolio_archive_layout";s:20:"Portfolio One Column";s:24:"portfolio_column_spacing";s:2:"12";s:24:"portfolio_content_length";s:7:"Excerpt";s:24:"excerpt_length_portfolio";s:2:"55";s:28:"portfolio_strip_html_excerpt";i:1;s:20:"grid_pagination_type";s:10:"Pagination";s:21:"portfolio_text_layout";s:7:"unboxed";s:14:"portfolio_slug";s:15:"portfolio-items";s:29:"portfolio_featured_image_size";s:7:"cropped";s:16:"portfolio_pn_nav";i:0;s:25:"portfolio_featured_images";i:1;s:38:"portfolio_disable_first_featured_image";i:0;s:30:"portfolio_featured_image_width";s:2:"No";s:19:"portfolio_width_100";i:0;s:28:"portfolio_project_desc_title";i:1;s:25:"portfolio_project_details";i:1;s:26:"portfolio_link_icon_target";i:0;s:18:"portfolio_comments";i:0;s:16:"portfolio_author";i:0;s:28:"portfolio_social_sharing_box";i:1;s:23:"portfolio_related_posts";i:1;s:26:"heading_social_sharing_box";s:0:"";s:35:"social_share_box_icon_options_title";s:57:"<h3 style=\'margin: 0;\'>Social Share Box Icon Options</h3>";s:15:"social_bg_color";s:7:"#f6f6f6";s:30:"sharing_social_links_font_size";s:2:"16";s:31:"sharing_social_links_icon_color";s:7:"#bebdbd";s:26:"sharing_social_links_boxed";s:2:"No";s:30:"sharing_social_links_box_color";s:7:"#e8e8e8";s:33:"sharing_social_links_boxed_radius";s:3:"4px";s:34:"sharing_social_links_boxed_padding";s:1:"8";s:38:"sharing_social_links_tooltip_placement";s:3:"Top";s:28:"social_share_box_links_title";s:50:"<h3 style=\'margin: 0;\'>Social Share Box Links</h3>";s:16:"sharing_facebook";i:1;s:15:"sharing_twitter";i:1;s:14:"sharing_reddit";i:1;s:16:"sharing_linkedin";i:1;s:14:"sharing_google";i:1;s:14:"sharing_tumblr";i:1;s:17:"sharing_pinterest";i:1;s:10:"sharing_vk";i:1;s:13:"sharing_email";i:1;s:20:"heading_social_media";s:0:"";s:13:"social_sorter";s:0:"";s:27:"custom_color_scheme_element";s:46:"<h3 style=\'margin: 0;\'>Custom Social Icon</h3>";s:16:"custom_icon_name";s:0:"";s:17:"custom_icon_image";s:0:"";s:24:"custom_icon_image_retina";s:0:"";s:17:"retina_icon_width";s:0:"";s:18:"retina_icon_height";s:0:"";s:16:"custom_icon_link";s:0:"";s:18:"heading_slideshows";s:0:"";s:22:"posts_slideshow_number";s:1:"5";s:18:"slideshow_autoplay";i:1;s:23:"slideshow_smooth_height";i:0;s:15:"slideshow_speed";s:4:"7000";s:22:"pagination_video_slide";i:0;s:22:"heading_elastic_slider";s:0:"";s:17:"tfes_slider_width";s:4:"100%";s:18:"tfes_slider_height";s:5:"400px";s:14:"tfes_animation";s:5:"sides";s:13:"tfes_autoplay";i:1;s:13:"tfes_interval";s:4:"3000";s:10:"tfes_speed";s:3:"800";s:10:"tfes_width";s:3:"150";s:18:"es_title_font_size";s:2:"42";s:20:"es_caption_font_size";s:2:"20";s:14:"es_title_color";s:7:"#333333";s:16:"es_caption_color";s:7:"#747474";s:16:"heading_lightbox";s:0:"";s:8:"lightbox";s:44:"<h3 style=\'margin: 0;\'>Lightbox Options</h3>";s:15:"status_lightbox";i:0;s:22:"status_lightbox_single";i:0;s:17:"lightbox_behavior";s:3:"all";s:13:"lightbox_skin";s:11:"metro-white";s:13:"lightbox_path";s:8:"vertical";s:24:"lightbox_animation_speed";s:6:"Normal";s:15:"lightbox_arrows";i:1;s:16:"lightbox_gallery";i:1;s:17:"lightbox_autoplay";i:0;s:24:"lightbox_slideshow_speed";s:4:"5000";s:16:"lightbox_opacity";s:3:"0.9";s:14:"lightbox_title";i:1;s:13:"lightbox_desc";i:1;s:15:"lightbox_social";i:1;s:20:"lightbox_deeplinking";i:1;s:20:"lightbox_post_images";i:1;s:20:"lightbox_video_width";s:6:"1280px";s:21:"lightbox_video_height";s:5:"720px";s:15:"heading_contact";s:0:"";s:13:"email_address";s:0:"";s:9:"recaptcha";s:50:"<h3 style=\'margin: 0;\'>ReCaptcha Spam Options</h3>";s:16:"recaptcha_public";s:0:"";s:17:"recaptcha_private";s:0:"";s:22:"recaptcha_color_scheme";s:5:"Clean";s:10:"google_map";s:53:"<h3 style=\'margin: 0;\'>Google Map Design Styling</h3>";s:9:"gmap_type";s:7:"roadmap";s:10:"gmap_width";s:4:"100%";s:11:"gmap_height";s:5:"415px";s:14:"gmap_topmargin";s:4:"55px";s:12:"gmap_address";s:49:"775 New York Ave, Brooklyn, Kings, New York 11203";s:14:"map_zoom_level";s:1:"8";s:7:"map_pin";i:0;s:18:"gmap_pin_animation";i:1;s:9:"map_popup";i:0;s:15:"map_scrollwheel";i:0;s:9:"map_scale";i:0;s:15:"map_zoomcontrol";i:0;s:11:"map_styling";s:7:"default";s:17:"map_overlay_color";s:0:"";s:19:"map_infobox_styling";s:7:"default";s:19:"map_infobox_content";s:0:"";s:20:"map_infobox_bg_color";s:0:"";s:22:"map_infobox_text_color";s:0:"";s:22:"map_custom_marker_icon";s:0:"";s:19:"heading_search_page";s:0:"";s:6:"search";s:42:"<h3 style=\'margin: 0;\'>Search Options</h3>";s:13:"search_layout";s:4:"Grid";s:14:"search_content";s:15:"Posts and Pages";s:14:"search_excerpt";i:0;s:23:"search_results_per_page";s:2:"10";s:22:"search_featured_images";i:0;s:26:"search_new_search_position";s:3:"top";s:18:"search_form_height";s:4:"33px";s:13:"heading_extra";s:0:"";s:12:"misc_options";s:49:"<h3 style=\'margin: 0;\'>Miscellaneous Options</h3>";s:16:"sidenav_behavior";s:5:"hover";s:26:"featured_image_placeholder";i:1;s:12:"excerpt_base";s:5:"words";s:16:"disable_excerpts";i:0;s:14:"link_read_more";i:0;s:14:"comments_pages";i:0;s:21:"featured_images_pages";i:0;s:18:"faq_featured_image";i:0;s:11:"faq_filters";s:4:"show";s:21:"nofollow_social_links";i:0;s:16:"social_icons_new";i:1;s:20:"number_related_posts";s:1:"5";s:21:"related_posts_columns";s:1:"5";s:28:"related_posts_column_spacing";s:2:"44";s:20:"related_posts_layout";s:17:"title_on_rollover";s:24:"related_posts_image_size";s:7:"cropped";s:22:"related_posts_autoplay";i:0;s:19:"related_posts_speed";s:4:"2500";s:24:"related_posts_navigation";i:1;s:19:"related_posts_swipe";i:0;s:25:"related_posts_swipe_items";s:0:"";s:9:"rollovers";s:50:"<h3 style=\'margin: 0;\'>Image Rollover Options</h3>";s:14:"image_rollover";i:1;s:24:"image_rollover_direction";s:4:"left";s:24:"image_rollover_icon_size";s:2:"15";s:19:"link_image_rollover";i:0;s:19:"zoom_image_rollover";i:0;s:20:"title_image_rollover";i:0;s:19:"cats_image_rollover";i:0;s:26:"icon_circle_image_rollover";i:0;s:16:"heading_advanced";s:0:"";s:22:"enable_disable_heading";s:76:"<h3 style=\'margin: 0;\'>Enable / Disable Theme Features & Plugin Support</h3>";s:16:"smooth_scrolling";i:1;s:15:"disable_builder";i:0;s:27:"disable_code_block_encoding";i:0;s:16:"disable_megamenu";i:0;s:16:"avada_rev_styles";i:0;s:22:"avada_styles_dropdowns";i:0;s:15:"use_animate_css";i:0;s:26:"disable_mobile_animate_css";i:1;s:9:"status_yt";i:0;s:12:"status_vimeo";i:0;s:11:"status_gmap";i:0;s:12:"status_totop";i:0;s:19:"status_totop_mobile";i:0;s:20:"status_fusion_slider";i:0;s:14:"status_eslider";i:0;s:18:"status_fontawesome";i:0;s:16:"status_opengraph";i:0;s:31:"disable_date_rich_snippet_pages";i:0;s:19:"disable_woo_gallery";i:0;s:8:"dev_mode";i:0;s:28:"dynamic_css_compiler_heading";s:91:"<h3 style=\'margin: 0;\'>Compile to file all the dynamic CSS generated by theme options.</h3>";s:20:"dynamic_css_compiler";i:0;s:15:"cache_server_ip";s:0:"";s:19:"heading_woocommerce";s:0:"";s:9:"woo_items";s:2:"12";s:29:"woocommerce_shop_page_columns";s:1:"4";s:27:"woocommerce_related_columns";s:1:"4";s:32:"woocommerce_archive_page_columns";s:1:"3";s:30:"woocommerce_product_tab_design";s:8:"vertical";s:26:"woocommerce_avada_ordering";i:0;s:29:"woocommerce_one_page_checkout";i:0;s:30:"woocommerce_enable_order_notes";i:1;s:28:"woocommerce_acc_link_top_nav";i:1;s:29:"woocommerce_cart_link_top_nav";i:1;s:29:"woocommerce_acc_link_main_nav";i:0;s:30:"woocommerce_cart_link_main_nav";i:1;s:24:"woocommerce_social_links";i:1;s:28:"woocommerce_toggle_grid_list";i:1;s:13:"woo_acc_msg_1";s:55:"Need Assistance? Call customer service at 888-555-5555.";s:13:"woo_acc_msg_2";s:32:"E-mail them at info@yourshop.com";s:18:"heading_custom_css";s:0:"";s:18:"advanced_css_intro";s:55:"<h3 style=\'margin: 0;\'>Advanced CSS Customizations</h3>";s:15:"custom_css_info";s:254:"Paste your CSS code, do not include any tags or HTML in the field. Any custom CSS entered here will override the theme CSS. In some cases, the !important tag may be needed. Don\'t URL encode image or svg paths. Contents of this field will be auto encoded.";s:10:"custom_css";s:0:"";s:14:"heading_backup";s:0:"";s:9:"of_backup";s:0:"";s:11:"of_transfer";s:0:"";}', 'yes') ; 
INSERT INTO `wp_options` VALUES (151, 'avada_disable_builder', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (152, 'avada_disable_encoding', '0', 'yes') ; 
INSERT INTO `wp_options` VALUES (153, 'avada_dynamic_css_posts', 'a:0:{}', 'yes') ; 
INSERT INTO `wp_options` VALUES (154, 'shop_catalog_image_size', 'a:3:{s:5:"width";i:500;s:6:"height";s:0:"";i:0;i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (155, 'shop_single_image_size', 'a:3:{s:5:"width";i:500;s:6:"height";s:0:"";i:0;i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (156, 'shop_thumbnail_image_size', 'a:3:{s:5:"width";i:120;s:6:"height";s:0:"";i:0;i:0;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (159, '_site_transient_update_plugins', 'O:8:"stdClass":5:{s:12:"last_checked";i:1444050565;s:7:"checked";a:10:{s:35:"backupwordpress/backupwordpress.php";s:5:"3.2.7";s:23:"debug-bar/debug-bar.php";s:5:"0.8.2";s:51:"fancy-product-designer-3/fancy-product-designer.php";s:5:"2.2.4";s:27:"fusion-core/fusion-core.php";s:7:"1.7.5.1";s:9:"hello.php";s:3:"1.6";s:19:"wpintrojs/index.php";s:3:"1.0";s:27:"LayerSlider/layerslider.php";s:5:"5.5.1";s:23:"revslider/revslider.php";s:6:"4.6.93";s:33:"total-security/total-security.php";s:5:"3.3.1";s:37:"wp-system-health/wp-system-health.php";s:5:"1.4.0";}s:8:"response";a:0:{}s:12:"translations";a:0:{}s:9:"no_update";a:5:{s:35:"backupwordpress/backupwordpress.php";O:8:"stdClass":6:{s:2:"id";s:3:"885";s:4:"slug";s:15:"backupwordpress";s:6:"plugin";s:35:"backupwordpress/backupwordpress.php";s:11:"new_version";s:5:"3.2.7";s:3:"url";s:46:"https://wordpress.org/plugins/backupwordpress/";s:7:"package";s:64:"https://downloads.wordpress.org/plugin/backupwordpress.3.2.7.zip";}s:23:"debug-bar/debug-bar.php";O:8:"stdClass":7:{s:2:"id";s:5:"18561";s:4:"slug";s:9:"debug-bar";s:6:"plugin";s:23:"debug-bar/debug-bar.php";s:11:"new_version";s:5:"0.8.2";s:3:"url";s:40:"https://wordpress.org/plugins/debug-bar/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/debug-bar.0.8.2.zip";s:14:"upgrade_notice";s:60:"Updated to handle a new deprecated message in WordPress 4.0.";}s:9:"hello.php";O:8:"stdClass":6:{s:2:"id";s:4:"3564";s:4:"slug";s:11:"hello-dolly";s:6:"plugin";s:9:"hello.php";s:11:"new_version";s:3:"1.6";s:3:"url";s:42:"https://wordpress.org/plugins/hello-dolly/";s:7:"package";s:58:"https://downloads.wordpress.org/plugin/hello-dolly.1.6.zip";}s:33:"total-security/total-security.php";O:8:"stdClass":6:{s:2:"id";s:5:"36569";s:4:"slug";s:14:"total-security";s:6:"plugin";s:33:"total-security/total-security.php";s:11:"new_version";s:5:"3.3.1";s:3:"url";s:45:"https://wordpress.org/plugins/total-security/";s:7:"package";s:63:"https://downloads.wordpress.org/plugin/total-security.3.3.1.zip";}s:37:"wp-system-health/wp-system-health.php";O:8:"stdClass":6:{s:2:"id";s:4:"8680";s:4:"slug";s:16:"wp-system-health";s:6:"plugin";s:37:"wp-system-health/wp-system-health.php";s:11:"new_version";s:5:"1.4.0";s:3:"url";s:47:"https://wordpress.org/plugins/wp-system-health/";s:7:"package";s:65:"https://downloads.wordpress.org/plugin/wp-system-health.1.4.0.zip";}}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (160, 'ls-plugin-version', '5.5.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (161, 'ls-db-version', '5.0.0', 'yes') ; 
INSERT INTO `wp_options` VALUES (162, 'ls-installed', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (163, 'ls-google-fonts', 'a:4:{i:0;a:2:{s:5:"param";s:28:"Lato:100,300,regular,700,900";s:5:"admin";b:0;}i:1;a:2:{s:5:"param";s:13:"Open+Sans:300";s:5:"admin";b:0;}i:2;a:2:{s:5:"param";s:20:"Indie+Flower:regular";s:5:"admin";b:0;}i:3;a:2:{s:5:"param";s:22:"Oswald:300,regular,700";s:5:"admin";b:0;}}', 'yes') ; 
INSERT INTO `wp_options` VALUES (164, 'ls-date-installed', '1444050435', 'yes') ; 
INSERT INTO `wp_options` VALUES (166, 'revslider_checktables', '1', 'yes') ; 
INSERT INTO `wp_options` VALUES (167, 'revslider-static-css', '.tp-caption a {
color:#ff7302;
text-shadow:none;
-webkit-transition:all 0.2s ease-out;
-moz-transition:all 0.2s ease-out;
-o-transition:all 0.2s ease-out;
-ms-transition:all 0.2s ease-out;
}

.tp-caption a:hover {
color:#ffa902;
}', 'yes') ; 
INSERT INTO `wp_options` VALUES (168, 'revslider-update-check-short', '1444050460', 'yes') ; 
INSERT INTO `wp_options` VALUES (169, 'revslider-valid-notice', 'false', 'yes') ; 
INSERT INTO `wp_options` VALUES (170, 'avada_revslider_version', '4.6.93', 'yes') ; 
INSERT INTO `wp_options` VALUES (171, 'avada_theme_version', '3.8.6.1', 'yes') ; 
INSERT INTO `wp_options` VALUES (172, '_transient_timeout_avada_dynamic_css_global', '1444054096', 'no') ; 
INSERT INTO `wp_options` VALUES (173, '_transient_avada_dynamic_css_global', '.Avada_3861{color:green;}body,html,html body.custom-background{background-color:#ffffff;}#main,#slidingbar,.fusion-footer-copyright-area,.fusion-footer-widget-area,.fusion-page-title-bar,.fusion-secondary-header,.header-v4 #small-nav,.header-v5 #small-nav,.sticky-header .sticky-shadow,.tfs-slider .slide-content-container{padding-left:30px;padding-right:30px;}.width-100 .fusion-section-separator,.width-100 .nonhundred-percent-fullwidth{padding-left:;padding-right:;margin-left:-30px;margin-right:-30px;}.width-100 .fullwidth-box,.width-100 .fusion-section-separator{margin-left:-!important;margin-right:-!important;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder li a{padding-left:30px;padding-right:30px;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder .fusion-mobile-nav-item .fusion-open-submenu{padding-right:35px;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder .fusion-mobile-nav-item a{padding-left:30px;padding-right:30px;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder .fusion-mobile-nav-item li a{padding-left:42px;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder .fusion-mobile-nav-item li li a{padding-left:55px;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder .fusion-mobile-nav-item li li li a{padding-left:68px;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder .fusion-mobile-nav-item li li li li a{padding-left:81px;}.tooltip-shortcode,a:hover{color:#a0ce4e;}#main .about-author .title a:hover,#main .post h2 a:hover,#slidingbar-area .fusion-accordian .panel-title a:hover,#slidingbar-area a:hover,#slidingbar-area ul li a:hover,#wrapper #slidingbar-area .current-menu-item > a,#wrapper #slidingbar-area .current-menu-item > a:before,#wrapper #slidingbar-area .current_page_item > a,#wrapper #slidingbar-area .current_page_item > a:before,#wrapper .fusion-footer-widget-area .current-menu-item > a,#wrapper .fusion-footer-widget-area .current-menu-item > a:before,#wrapper .fusion-footer-widget-area .current_page_item > a,#wrapper .fusion-footer-widget-area .current_page_item > a:before,#wrapper .jtwt .jtwt_tweet a:hover,#wrapper .sidebar .current-menu-item > a,#wrapper .sidebar .current-menu-item > a:before,#wrapper .sidebar .current_page_item > a,#wrapper .sidebar .current_page_item > a:before,.content-box-percentage,.fusion-accordian .panel-title a:hover,.fusion-copyright-notice a:hover,.fusion-date-and-formats .fusion-format-box i,.fusion-filters .fusion-filter.fusion-active a,.fusion-footer-widget-area .fusion-accordian .panel-title a:hover,.fusion-footer-widget-area .fusion-tabs-widget .tab-holder .news-list li .post-holder a:hover,.fusion-footer-widget-area a:hover,.fusion-footer-widget-area ul li a:hover,.fusion-popover,.fusion-read-more:hover:after,.more a:hover:after,.pagination-next:hover:after,.pagination-prev:hover:before,.price > .amount,.price ins .amount,.project-content .project-info .project-info-box a:hover,.side-nav .arrow:hover:after,.side-nav li.current_page_ancestor > a,.side-nav ul > li.current_page_item > a,.sidebar .widget .recentcomments:hover:before,.sidebar .widget li a:hover,.sidebar .widget_archive li a:hover:before,.sidebar .widget_categories li a:hover,.sidebar .widget_categories li a:hover:before,.sidebar .widget_links li a:hover:before,.sidebar .widget_nav_menu li a:hover:before,.sidebar .widget_pages li a:hover:before,.sidebar .widget_recent_entries li a:hover:before,.single-navigation a[rel=next]:hover:after,.single-navigation a[rel=prev]:hover:before,.star-rating span:before,.star-rating:before,.tooltip-shortcode,h5.toggle:hover a,span.dropcap{color:#a0ce4e;}.link-area-box-hover .heading h2,.link-area-box-hover .icon .circle-no,.link-area-link-icon-hover .heading h2,.link-area-link-icon-hover .icon .circle-no,.link-area-link-icon-hover.link-area-box .fusion-read-more,.link-area-link-icon-hover.link-area-box .fusion-read-more::after,.link-area-link-icon-hover.link-area-box .fusion-read-more::before{color:#a0ce4e !important;}.fusion-accordian .panel-title a:hover .fa-fusion-box,.fusion-content-boxes .heading-link:hover .icon i.circle-yes,.fusion-content-boxes .link-area-box:hover .heading-link .icon i.circle-yes,.link-area-box-hover .heading .icon i.circle-yes,.link-area-link-icon-hover .heading .icon i.circle-yes{background-color:#a0ce4e !important;border-color:#a0ce4e !important;}.sidebar .fusion-image-wrapper .fusion-rollover .fusion-rollover-content a:hover{color:#333333;}.star-rating span:before,.star-rating:before{color:#a0ce4e;}#slidingbar-area .tagcloud a:hover,.fusion-footer-widget-area .tagcloud a:hover,.tagcloud a:hover{color:#FFFFFF;text-shadow:none;-webkit-text-shadow:none;-moz-text-shadow:none;}#nav ul li > a:hover,#sticky-nav ul li > a:hover,#wrapper .fusion-tabs-widget .tab-holder .tabs li.active a,#wrapper .fusion-tabs.classic .nav-tabs > li.active .tab-link,#wrapper .fusion-tabs.classic .nav-tabs > li.active .tab-link:focus,#wrapper .fusion-tabs.classic .nav-tabs > li.active .tab-link:hover,#wrapper .fusion-tabs.vertical-tabs.classic .nav-tabs > li.active .tab-link,#wrapper .post-content blockquote,.fusion-filters .fusion-filter.fusion-active a,.pagination .current,.pagination a.inactive:hover,.progress-bar-content,.reading-box,.tagcloud a:hover{border-color:#a0ce4e;}#wrapper .side-nav li.current_page_item a{border-right-color:#a0ce4e;border-left-color:#a0ce4e;}#toTop:hover,#wrapper .search-table .search-button input[type="submit"]:hover,.circle-yes ul li:before,.fusion-accordian .panel-title .active .fa-fusion-box,.fusion-date-and-formats .fusion-date-box,.pagination .current,.progress-bar-content,.table-2 table thead,.tagcloud a:hover,ul.arrow li:before,ul.circle-yes li:before{background-color:#a0ce4e;}#slidingbar{background-color:#363839;background-color:rgba(54,56,57,1);}.sb-toggle-wrapper{border-top-color:#363839;border-top-color:rgba( 54,56,57,1);}#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder .tabs li{border-color:#363839;border-color:rgba( 54,56,57,1);}#main,#wrapper,.fusion-separator .icon-wrapper,body,html{background-color:#ffffff;}.fusion-footer-widget-area{background-color:#363839;border-color:#e9eaee;padding-top:43px;padding-bottom:40px;}#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder .tabs li{border-color:#363839;}.fusion-footer-copyright-area{background-color:#282a2b;border-color:#4b4c4d;padding-top:18px;padding-bottom:16px;}.sep-boxed-pricing .panel-heading{background-color:#a0ce4e;border-color:#a0ce4e;}.full-boxed-pricing.fusion-pricing-table .standout .panel-heading h3,.fusion-pricing-table .panel-body .price .decimal-part,.fusion-pricing-table .panel-body .price .integer-part{color:#a0ce4e;}.fusion-image-wrapper .fusion-rollover{background-image:linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-webkit-gradient(linear, left top, left bottom, color-stop(0, rgba(160,206,78,0.8)), color-stop(1, rgba(160,206,78,0.8)));background-image:filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#a0ce4e, endColorstr=#a0ce4e), progid: DXImageTransform.Microsoft.Alpha(Opacity=0);background-image:-webkit-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-moz-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-ms-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);background-image:-o-linear-gradient(top, rgba(160,206,78,0.8) 0%, rgba(160,206,78,0.8) 100%);}.no-cssgradients .fusion-image-wrapper .fusion-rollover{background:#a0ce4e;}.fusion-image-wrapper:hover .fusion-rollover{filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#a0ce4e, endColorstr=#a0ce4e), progid: DXImageTransform.Microsoft.Alpha(Opacity=100);}#main .comment-submit,#reviews input#submit,.button-default,.button.default,.comment-form input[type="submit"],.fusion-button-default,.fusion-portfolio-one .fusion-button,.ticket-selector-submit-btn[type=submit]{background:#a0ce4e;color:#ffffff;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#a0ce4e, endColorstr=#a0ce4e);transition:all .2s;-webkit-transition:all .2s;-moz-transition:all .2s;-ms-transition:all .2s;-o-transition:all .2s;}.link-type-button-bar .fusion-read-more,.no-cssgradients #main .comment-submit,.no-cssgradients #reviews input#submit,.no-cssgradients .button-default,.no-cssgradients .button.default,.no-cssgradients .comment-form input[type="submit"],.no-cssgradients .fusion-button-default,.no-cssgradients .fusion-portfolio-one .fusion-button,.no-cssgradients .ticket-selector-submit-btn[type="submit"]{background:#a0ce4e;}#main .comment-submit:hover,#reviews input#submit:hover,.button-default:hover,.button.default:hover,.comment-form input[type="submit"]:hover,.fusion-button-default:hover,.fusion-portfolio-one .fusion-button:hover,.ticket-selector-submit-btn[type="submit"]:hover{background:#96c346;color:#ffffff;filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#96c346, endColorstr=#96c346);}.no-cssgradients #main .comment-submit:hover,.no-cssgradients #reviews input#submit:hover,.no-cssgradients .button-default:hover,.no-cssgradients .comment-form input[type="submit"]:hover,.no-cssgradients .fusion-button-default:hover,.no-cssgradients .fusion-portfolio-one .fusion-button:hover,.no-cssgradients .ticket-selector-submit-btn[type="submit"]:hover,.no-cssgradinets .button.default:hover{background:#96c346 !important;}.link-type-button-bar .fusion-read-more,.link-type-button-bar .fusion-read-more:after,.link-type-button-bar .fusion-read-more:before{color:#ffffff;}.link-type-button-bar .fusion-read-more:hover,.link-type-button-bar .fusion-read-more:hover:after,.link-type-button-bar .fusion-read-more:hover:before,.link-type-button-bar.link-area-box:hover .fusion-read-more,.link-type-button-bar.link-area-box:hover .fusion-read-more:after,.link-type-button-bar.link-area-box:hover .fusion-read-more:before{color:#ffffff !important;}.fusion-image-wrapper .fusion-rollover .fusion-rollover-gallery,.fusion-image-wrapper .fusion-rollover .fusion-rollover-link{background-color:#333333;width:36px;height:36px;}.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories a,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title a,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content a,.fusion-rollover .fusion-rollover-content .fusion-rollover-title{color:#333333;}.fusion-page-title-bar{border-color:#d2d3d4;background-image:url("http://duktor-wordpress/content/themes/Avada/assets/images/page_title_bg.png");background-color:#F6F6F6;height:87px;}.fusion-footer-copyright-area > .fusion-row,.fusion-footer-widget-area > .fusion-row{padding-left:0px;padding-right:0px;}.fontawesome-icon.circle-yes{background-color:#333333;}.content-box-shortcode-timeline,.fontawesome-icon.circle-yes{border-color:#333333;}.fontawesome-icon,.fontawesome-icon.circle-yes,.post-content .error-menu li:after,.post-content .error-menu li:before{color:#ffffff;}.fusion-title .title-sep,.product .product-border{border-color:#e0dede;}.checkout .payment_methods .payment_box,.post-content blockquote,.review blockquote q{background-color:#f6f6f6;}.fusion-testimonials .author:after{border-top-color:#f6f6f6;}.post-content blockquote,.review blockquote q{color:#747474;}#nav ul li ul li a,#reviews #comments > h2,#sticky-nav ul li ul li a,#wrapper #nav ul li ul li > a,#wrapper #sticky-nav ul li ul li > a,.avada-container h3,.comment-form input[type="submit"],.ei-title h3,.fusion-blog-shortcode .fusion-timeline-date,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .price,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content a,.fusion-load-more-button,.fusion-page-title-bar h3,.meta .fusion-date,.more,.post-content blockquote,.project-content .project-info h4,.review blockquote div strong,.review blockquote q,.ticket-selector-submit-btn[type="submit"],body{font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:400;}#slidingbar-area  h3,.avada-container h3,.comment-form input[type="submit"],.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3,.fusion-load-more-button,.project-content .project-info h4,.review blockquote div strong,.ticket-selector-submit-btn[type="submit"]{font-weight:bold;}.meta .fusion-date,.post-content blockquote,.review blockquote q{font-style:italic;}.side-nav li a{font-family:\'Antic Slab\', Arial, Helvetica, sans-serif;font-weight:400;font-size:14px;}#main .post h2,#main .reading-box h2,#main h2,#wrapper .fusion-tabs-widget .tab-holder .tabs li a,.ei-title h2,.fusion-accordian .panel-heading a,.fusion-accordian .panel-title,.fusion-author .fusion-author-title,.fusion-carousel-title,.fusion-flip-box .flip-box-heading-back,.fusion-header-tagline,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-title a,.fusion-modal .modal-title,.fusion-page-title-bar h1,.fusion-person .person-desc .person-author .person-author-wrapper,.fusion-pricing-table .pricing-row,.fusion-pricing-table .title-row,.fusion-tabs .nav-tabs  li .fusion-tab-heading,.fusion-title h3,.main-flex .slide-content h2,.main-flex .slide-content h3,.popover .popover-title,.post-content h1,.post-content h2,.post-content h3,.post-content h4,.post-content h5,.post-content h6,.project-content h3,.share-box h4,.sidebar .widget h4,table th{font-family:\'Antic Slab\', Arial, Helvetica, sans-serif;font-weight:400;}.project-content .project-info h4{font-family:\'Antic Slab\', Arial, Helvetica, sans-serif;}#slidingbar-area .widget-title,#slidingbar-area h3,.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3{font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:400;}#slidingbar-area .slide-excerpt h2,.fusion-footer-widget-area .slide-excerpt h2,.jtwt .jtwt_tweet,.sidebar .jtwt .jtwt_tweet,.sidebar .slide-excerpt h2,body{font-size:13px;line-height:20px;}#slidingbar-area ul,.fusion-footer-widget-area ul,.fusion-tabs-widget .tab-holder .news-list li .post-holder .meta,.fusion-tabs-widget .tab-holder .news-list li .post-holder a,.project-content .project-info h4{font-size:13px;line-height:20px;}.fusion-blog-layout-timeline .fusion-timeline-date{font-size:13;}.counter-box-content,.fusion-alert,.fusion-progressbar .sr-only,.post-content blockquote,.review blockquote q{font-size:13px;}#side-header .fusion-contact-info,#side-header .header-social .top-menu,#slidingbar-area .slide-excerpt h2,.fusion-accordian .panel-body,.fusion-footer-widget-area .slide-excerpt h2,.post-content blockquote,.project-content .project-info h4,.review blockquote q,.sidebar .slide-excerpt h2,body{line-height:20px;}.fusion-page-title-bar .fusion-breadcrumbs,.fusion-page-title-bar .fusion-breadcrumbs li,.fusion-page-title-bar .fusion-breadcrumbs li a{font-size:10px;}.sidebar .widget h4{font-size:13px;}#slidingbar-area .widget-title,#slidingbar-area h3{font-size:13px;line-height:13px;color:#DDDDDD;}.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3{font-size:13px;line-height:13px;}.fusion-copyright-notice{font-size:12px;}#main .fusion-row,#slidingbar-area .fusion-row,.fusion-footer-copyright-area .fusion-row,.fusion-footer-widget-area .fusion-row,.fusion-page-title-row,.tfs-slider .slide-content-container .slide-content{max-width:1100px;}.post-content h1{font-size:34px;line-height:48px;}#main .fusion-portfolio h2,#wrapper  #main .post h2,#wrapper #main .post-content .fusion-title h2,#wrapper #main .post-content .title h2,#wrapper .fusion-title h2,#wrapper .post-content h2,#wrapper .title h2,h2.entry-title{font-size:18px;line-height:41px;}#main .fusion-portfolio h2,#wrapper #main .post h2,#wrapper #main .post-content .fusion-title h2,#wrapper #main .post-content .title h2,#wrapper .fusion-title h2,#wrapper .post-content h2,#wrapper .title h2,h2.entry-title{line-height:27px;}#wrapper #main .fusion-portfolio-content > h2.entry-title,#wrapper #main .fusion-post-content > h2.entry-title,#wrapper #main .post > h2.entry-title{font-size:18px;line-height:27px;}#wrapper #main #comments h3,#wrapper #main #respond h3,#wrapper #main .about-author h3,#wrapper #main .related-posts h3{font-size:18px;line-height:27px;}.post-content h3,.project-content h3{font-size:16px;line-height:24px;}.fusion-modal .modal-title{font-size:16px;line-height:36px;}.fusion-carousel-title,.fusion-person .person-author-wrapper .person-name,.fusion-person .person-author-wrapper .person-title,.fusion-portfolio-post .fusion-portfolio-content h4,.fusion-rollover .fusion-rollover-content .fusion-rollover-title,.post-content h4{font-size:13px;line-height:20px;}#reviews #comments > h2,#wrapper .fusion-tabs-widget .tab-holder .tabs li a,.fusion-flip-box .flip-box-heading-back,.person-author-wrapper,.popover .popover-title{font-size:13px;}.fusion-accordian .panel-title,.fusion-sharing-box h4,.fusion-tabs .nav-tabs > li .fusion-tab-heading{font-size:13px;line-height:30px;}.post-content h5{font-size:12px;line-height:18px;}.post-content h6{font-size:11px;line-height:17px;}.ei-title h2{font-size:42px;line-height:63px;color:#333333;}.ei-title h3{font-size:20px;line-height:30px;color:#747474;}.fusion-carousel-meta,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories,.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-rollover-categories a,.fusion-recent-posts .columns .column .meta,.fusion-single-line-meta{font-size:12px;line-height:18px;}.fusion-carousel-meta,.fusion-meta,.fusion-meta-info,.fusion-recent-posts .columns .column .meta,.post .single-line-meta{font-size:12px;}.fusion-image-wrapper .fusion-rollover .fusion-rollover-content .fusion-product-buttons a,.product-buttons a{font-size:12px;line-height:18px;}.page-links,.pagination,.pagination .pagination-next,.pagination .pagination-prev{font-size:12px;}#reviews #comments > h2,#wrapper .fusion-tabs-widget .tab-holder .news-list li .post-holder .meta,#wrapper .meta,.fusion-blog-timeline-layout .fusion-timeline-date,.fusion-rollover .price .amount,.post .post-content,.post-content blockquote,.project-content .project-info h4,.quantity .minus,.quantity .plus,.quantity .qty,.review blockquote div,.search input,.sidebar .jtwt,.sidebar .widget .recentcomments,.sidebar .widget_archive li,.sidebar .widget_categories li,.sidebar .widget_links li,.sidebar .widget_meta li,.sidebar .widget_nav_menu li,.sidebar .widget_pages li,.sidebar .widget_recent_entries li,.title-row,body{color:#747474;}.fusion-post-content h1,.post-content h1,.title h1{color:#333333;}#main .post h2,.cart-empty,.fusion-post-content h2,.fusion-title h2,.post-content h2,.search-page-search-form h2,.title h2{color:#333333;}.fusion-post-content h3,.fusion-title h3,.person-author-wrapper span,.post-content h3,.product-title,.project-content h3,.title h3{color:#333333;}#wrapper .fusion-tabs-widget .tab-holder .tabs li a,.fusion-accordian .panel-title a,.fusion-carousel-title,.fusion-post-content h4,.fusion-tabs .nav-tabs > li .fusion-tab-heading,.fusion-title h4,.post-content h4,.project-content .project-info h4,.share-box h4,.sidebar .widget h4,.title h4{color:#333333;}.fusion-post-content h5,.fusion-title h5,.post-content h5,.title h5{color:#333333;}.fusion-post-content h6,.fusion-title h6,.post-content h6,.title h6{color:#333333;}.fusion-page-title-bar h1,.fusion-page-title-bar h3{color:#333333;}.sep-boxed-pricing .panel-heading h3{color:#333333;}.full-boxed-pricing.fusion-pricing-table .panel-heading h3{color:#333333;}#main .post h2 a,.about-author .title a,.fusion-load-more-button,.fusion-rollover a,.project-content .project-info .project-info-box a,.shop_attributes tr th,.sidebar .widget .recentcomments,.sidebar .widget li a,.sidebar .widget_categories li,.single-navigation a[rel="next"]:after,.single-navigation a[rel="prev"]:before,body a,body a:after,body a:before{color:#333333;}body #toTop:before{color:#fff;}.fusion-page-title-bar .fusion-breadcrumbs,.fusion-page-title-bar .fusion-breadcrumbs a{color:#333333;}#slidingbar-area,#slidingbar-area .fusion-column,#slidingbar-area .jtwt,#slidingbar-area .jtwt .jtwt_tweet{color:#8C8989;} #slidingbar-area .jtwt .jtwt_tweet a,#slidingbar-area .fusion-accordian .panel-title a,#slidingbar-area a,#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder .tabs li a{color:#BFBFBF;}.sidebar .widget .heading h4,.sidebar .widget h4{color:#333333;}.fusion-footer-widget-area .widget-title,.fusion-footer-widget-area h3,.fusion-footer-widget-column .product-title{color:#DDDDDD;}.fusion-copyright-notice,.fusion-footer-widget-area,.fusion-footer-widget-area .jtwt,.fusion-footer-widget-area .jtwt .jtwt_tweet,.fusion-footer-widget-area article.col{color:#8C8989;}#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder .tabs li a,.fusion-copyright-notice a,.fusion-footer-widget-area .fusion-accordian .panel-title a,.fusion-footer-widget-area .fusion-tabs-widget .tab-holder .news-list li .post-holder a,.fusion-footer-widget-area .jtwt .jtwt_tweet a,.fusion-footer-widget-area a{color:#BFBFBF;}#customer_login .col-1,#customer_login .col-2,#customer_login h2,#customer_login_box,#reviews li .comment-text,#small-nav,#wrapper .fusion-tabs-widget .tab-holder,#wrapper .side-nav li a,#wrapper .side-nav li.current_page_item li a,.avada-skin-rev,.chzn-container-single .chzn-single,.chzn-container-single .chzn-single div,.chzn-drop,.commentlist .the-comment,.es-carousel-wrapper.fusion-carousel-small .es-carousel ul li img,.fusion-accordian .fusion-panel,.fusion-author .fusion-author-social,.fusion-blog-layout-grid .post .flexslider,.fusion-blog-layout-grid .post .fusion-content-sep,.fusion-blog-layout-grid .post .post-wrapper,.fusion-counters-box .fusion-counter-box .counter-box-border,.fusion-filters,.fusion-layout-timeline .post,.fusion-layout-timeline .post .flexslider,.fusion-layout-timeline .post .fusion-content-sep,.fusion-portfolio .fusion-portfolio-boxed .fusion-content-sep,.fusion-portfolio .fusion-portfolio-boxed .fusion-portfolio-post-wrapper,.fusion-portfolio-one .fusion-portfolio-boxed .fusion-portfolio-post-wrapper,.fusion-tabs.vertical-tabs.clean .nav-tabs li .tab-link,.fusion-timeline-arrow,.fusion-timeline-date,.input-radio,.ls-avada,.page-links a,.pagination a.inactive,.panel.entry-content,.post .fusion-meta-info,.price_slider_wrapper,.progress-bar,.project-content .project-info .project-info-box,.quantity,.quantity .minus,.quantity .qty,.search-page-search-form,.sep-dashed,.sep-dotted,.sep-double,.sep-single,.side-nav,.side-nav li a,.sidebar .widget .recentcomments,.sidebar .widget li a,.sidebar .widget_archive li,.sidebar .widget_categories li,.sidebar .widget_links li,.sidebar .widget_meta li,.sidebar .widget_nav_menu li,.sidebar .widget_pages li,.sidebar .widget_recent_entries li,.single-navigation,.table,.table > tbody > tr > td,.table > tbody > tr > th,.table > tfoot > tr > td,.table > tfoot > tr > th,.table > thead > tr > td,.table > thead > tr > th,.table-1 table,.table-1 table th,.table-1 tr td,.table-2 table thead,.table-2 tr td,.tabs-vertical .tabs-container .tab_content,.tabs-vertical .tabset,.tagcloud a,.tkt-slctr-tbl-wrap-dv table,.tkt-slctr-tbl-wrap-dv tr td,h5.toggle.active + .toggle-content,tr td{border-color:#e0dede;}.price_slider_wrapper .ui-widget-content{background-color:#e0dede;}.fusion-load-more-button{background-color:#ebeaea;}.fusion-load-more-button:hover{background-color:rgba(235,234,234,0.8);}.quantity .minus,.quantity .plus{background-color:#fbfaf9;}.quantity .minus:hover,.quantity .plus:hover{background-color:#ffffff;}.sb-toggle-wrapper .sb-toggle:after{color:#ffffff;}#slidingbar-area .product_list_widget li,#slidingbar-area .widget_categories li a,#slidingbar-area .widget_recent_entries ul li,#slidingbar-area li.recentcomments,#slidingbar-area ul li a{border-bottom-color:#ffffff;}#slidingbar-area .fusion-accordian .fusion-panel,#slidingbar-area .tagcloud a,#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder,#wrapper #slidingbar-area .fusion-tabs-widget .tab-holder .news-list li{border-color:#282A2B;}#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder,#wrapper .fusion-footer-widget-area .fusion-tabs-widget .tab-holder .news-list li,.fusion-footer-widget-area .fusion-accordian .fusion-panel,.fusion-footer-widget-area .product_list_widget li,.fusion-footer-widget-area .tagcloud a,.fusion-footer-widget-area .widget_categories li a,.fusion-footer-widget-area .widget_recent_entries li,.fusion-footer-widget-area li.recentcomments,.fusion-footer-widget-area ul li a{border-color:#505152;}#comment-input input,#comment-textarea textarea,#wrapper .search-table .search-field input,#wrapper .select-arrow,.avada-select .select2-container .select2-choice,.avada-select .select2-container .select2-choice2,.avada-select-parent .select-arrow,.avada-select-parent select,.chzn-container .chzn-drop,.chzn-container-single .chzn-single,.comment-form-comment textarea,.input-text,.main-nav-search-form input,.post-password-form .password,.search-page-search-form input,input.s,input[type="text"],select,textarea{background-color:#ffffff;}#comment-input .placeholder,#comment-input input,#comment-textarea .placeholder,#comment-textarea textarea,#wrapper .search-table .search-field input,.avada-select .select2-container .select2-choice,.avada-select .select2-container .select2-choice2,.avada-select-parent select,.chzn-container .chzn-drop,.chzn-container-single .chzn-single,.comment-form-comment textarea,.input-text,.main-nav-search-form input,.post-password-form .password,.search-page-search-form input,input.s,input.s .placeholder,input[type="text"],select,textarea{color:#aaa9a9;}#comment-input input:-moz-placeholder,#comment-input input:-ms-input-placeholder,#comment-input input::-webkit-input-placeholder,#comment-textarea textarea:-moz-placeholder,#comment-textarea textarea::-webkit-input-placeholder,.comment-form-comment textarea:-moz-placeholder,.comment-form-comment textarea:-ms-input-placeholder,.comment-form-comment textarea::-webkit-input-placeholder,.input-text:-moz-placeholder,.input-text:-ms-input-placeholder,.input-text::-webkit-input-placeholder,.post-password-form .password::-moz-input-placeholder,.post-password-form .password::-ms-input-placeholder,.post-password-form .password::-webkit-input-placeholder,input#s:-moz-placeholder,input#s:-ms-input-placeholder,input#s::-webkit-input-placeholder{color:#aaa9a9;}#comment-input input,#comment-textarea textarea,#wrapper .search-table .search-field input,.avada-select .select2-container .select2-choice,.avada-select .select2-container .select2-choice .select2-arrow,.avada-select .select2-container .select2-choice2 .select2-arrow,.avada-select-parent .select-arrow,.avada-select-parent select,.chzn-container .chzn-drop,.chzn-container-single .chzn-single,.comment-form-comment textarea,.gravity-select-parent .select-arrow,.input-text,.main-nav-search-form input,.post-password-form .password,.search-page-search-form input,.select-arrow,input.s,input[type="text"],select,textarea{border-color:#d2d2d2;}.select-arrow,.select2-arrow{color:#d2d2d2;}.fusion-page-title-bar h1{font-size:18px;line-height:normal;}.fusion-page-title-bar h3{font-size:14px;line-height:26px;}#content{width:71%;}#main .sidebar{width:23%;background-color:transparent;padding:0;}.double-sidebars #content{width:52%;margin-left:24%;}.double-sidebars #main #sidebar{width:21%;margin-left:-76%;}.double-sidebars #main #sidebar-2{width:21%;margin-left:3%;}.fusion-accordian .panel-title a .fa-fusion-box{background-color:#333333;}.progress-bar-content{background-color:#a0ce4e;border-color:#a0ce4e;}.content-box-percentage{color:#a0ce4e;}.progress-bar{background-color:#f6f6f6;border-color:#f6f6f6;}#wrapper .fusion-date-and-formats .fusion-format-box{background-color:#eef0f2;}.fusion-carousel .fusion-carousel-nav .fusion-nav-next,.fusion-carousel .fusion-carousel-nav .fusion-nav-prev{background-color:rgba(0,0,0,0.6);}.fusion-carousel .fusion-carousel-nav .fusion-nav-next:hover,.fusion-carousel .fusion-carousel-nav .fusion-nav-prev:hover{background-color:rgba(0,0,0,0.7);}.fusion-flexslider .flex-direction-nav .flex-next,.fusion-flexslider .flex-direction-nav .flex-prev{background-color:rgba(0,0,0,0.6);}.fusion-flexslider .flex-direction-nav .flex-next:hover,.fusion-flexslider .flex-direction-nav .flex-prev:hover{background-color:rgba(0,0,0,0.7);}.content-boxes .col{background-color:transparent;}#wrapper .sidebar .fusion-tabs-widget .tabs-container{background-color:#ffffff;}body .sidebar .fusion-tabs-widget .tab-hold .tabs li{border-right:1px solid #ffffff;}.sidebar .fusion-tabs-widget .tab-holder .tabs li a,body .sidebar .fusion-tabs-widget .tab-holder .tabs li a{background:#ebeaea;border-bottom:0;color:#747474;}body .sidebar .fusion-tabs-widget .tab-hold .tabs li a:hover{background:#ffffff;border-bottom:0;}body .sidebar .fusion-tabs-widget .tab-hold .tabs li.active a,body .sidebar .fusion-tabs-widget .tab-holder .tabs li.active a{background:#ffffff;border-bottom:0;border-top-color:#a0ce4e;}#wrapper .sidebar .fusion-tabs-widget .tab-holder,.sidebar .fusion-tabs-widget .tab-holder .news-list li{border-color:#ebeaea;}.fusion-single-sharing-box{background-color:#f6f6f6;}.fusion-blog-layout-grid .post .fusion-post-wrapper,.fusion-blog-layout-timeline .post,.fusion-portfolio.fusion-portfolio-boxed .fusion-portfolio-content-wrapper,.products li.product{background-color:transparent;}.fusion-blog-layout-grid .post .flexslider,.fusion-blog-layout-grid .post .fusion-content-sep,.fusion-blog-layout-grid .post .fusion-post-wrapper,.fusion-blog-layout-timeline .fusion-timeline-date,.fusion-blog-layout-timeline .fusion-timeline-line,.fusion-blog-layout-timeline .post,.fusion-blog-layout-timeline .post .flexslider,.fusion-blog-layout-timeline .post .fusion-content-sep,.fusion-blog-timeline-layout .post,.fusion-blog-timeline-layout .post .flexslider,.fusion-blog-timeline-layout .post .fusion-content-sep,.fusion-portfolio.fusion-portfolio-boxed .fusion-content-sep,.fusion-portfolio.fusion-portfolio-boxed .fusion-portfolio-content-wrapper,.product .product-buttons,.product-buttons,.product-buttons-container,.product-details-container,.products li{border-color:#ebeaea;}.fusion-blog-layout-timeline .fusion-timeline-circle,.fusion-blog-layout-timeline .fusion-timeline-date,.fusion-blog-timeline-layout .fusion-timeline-circle,.fusion-blog-timeline-layout .fusion-timeline-date{background-color:#ebeaea;}.fusion-blog-timeline-layout .fusion-timeline-arrow:before,.fusion-blog-timeline-layout .fusion-timeline-icon,.fusion-timeline-arrow:before,.fusion-timeline-icon{color:#ebeaea;}div.indicator-hint{background:#ebeaea;border-color:#ebeaea;}#posts-container.fusion-blog-layout-grid{margin:-20px -20px 0 -20px;}#posts-container.fusion-blog-layout-grid .fusion-post-grid{padding:20px;}.quicktags-toolbar input{background:linear-gradient(to top, #ffffff, #ffffff ) #3E3E3E;background:-webkit-linear-gradient(to top, #ffffff, #ffffff ) #3E3E3E;background:-moz-linear-gradient(to top, #ffffff, #ffffff ) #3E3E3E;background:-ms-linear-gradient(to top, #ffffff, #ffffff ) #3E3E3E;background:-o-linear-gradient(to top, #ffffff, #ffffff ) #3E3E3E;background-image:-webkit-gradient( linear, left top, left bottom, color-stop(0, #ffffff), color-stop(1, #ffffff));filter:progid:DXImageTransform.Microsoft.gradient(startColorstr=#ffffff, endColorstr=#ffffff), progid: DXImageTransform.Microsoft.Alpha(Opacity=0);border:1px solid #d2d2d2;color:#aaa9a9;}.quicktags-toolbar input:hover{background:#ffffff;}.ei-slider{width:100%;height:400px;}#comment-submit,#reviews input#submit,.button.default,.fusion-button.fusion-button-default,.ticket-selector-submit-btn[type="submit"]{border-color:#ffffff;}#comment-submit:hover,#reviews input#submit:hover,.button.default:hover,.fusion-button.fusion-button-default:hover,.ticket-selector-submit-btn[type="submit"]:hover{border-color:#ffffff;}.button.default,.fusion-button-default{padding:13px 29px;line-height:17px;font-size:14px;}.button.default.button-3d.button-small,.fusion-button.button-small.button-3d,.fusion-button.fusion-button-3d.fusion-button-small,.ticket-selector-submit-btn[type="submit"]{box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);}.button.default.button-3d.button-small:active,.fusion-button.button-small.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-small:active,.ticket-selector-submit-btn[type="submit"]:active{box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 4px 4px 2px rgba(0, 0, 0, 0.3);}.button.default.button-3d.button-medium,.fusion-button.button-medium.button-3d,.fusion-button.fusion-button-3d.fusion-button-medium{box-shadow:inset 0px 1px 0px #ffffff, 0px 3px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 3px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 3px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);}.button.default.button-3d.button-medium:active,.fusion-button.button-medium.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-medium:active{box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 5px 5px 3px rgba(0, 0, 0, 0.3);}.button.default.button-3d.button-large,.fusion-button.button-large.button-3d,.fusion-button.fusion-button-3d.fusion-button-large{box-shadow:inset 0px 1px 0px #ffffff, 0px 4px 0px #54770F, 1px 5px 6px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 4px 0px #54770F, 1px 5px 6px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 4px 0px #54770F, 1px 5px 6px 3px rgba(0, 0, 0, 0.3);}.button.default.button-3d.button-large:active,.fusion-button.button-large.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-large:active{box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 6px 6px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 6px 6px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 1px 0px #54770F, 1px 6px 6px 3px rgba(0, 0, 0, 0.3);}.button.default.button-3d.button-xlarge,.fusion-button.button-xlarge.button-3d,.fusion-button.fusion-button-3d.fusion-button-xlarge{box-shadow:inset 0px 1px 0px #ffffff, 0px 5px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 5px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 5px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);}.button.default.button-3d.button-xlarge:active,.fusion-button.button-xlarge.button-3d:active,.fusion-button.fusion-button-3d.fusion-button-xlarge:active{box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-webkit-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);-moz-box-shadow:inset 0px 1px 0px #ffffff, 0px 2px 0px #54770F, 1px 7px 7px 3px rgba(0, 0, 0, 0.3);}#comment-submit,#reviews input#submit,.button-default,.button.default,.fusion-button,.fusion-button-default{border-width:0px;border-style:solid;}.button.default:hover,.fusion-button.button-default:hover,.ticket-selector-submit-btn[type="submit"]{border-width:0px;border-style:solid;}.fusion-menu-item-button .menu-text{border-color:#fff;}.fusion-menu-item-button:hover .menu-text{border-color:#fff;}#comment-submit,#reviews input#submit,.button-default,.button.default,.fusion-button-default,.ticket-selector-submit-btn[type="submit"]{border-radius:2px;-webkit-border-radius:2px;}.reading-box{background-color:#f6f6f6;}.isotope .isotope-item{transition-property:top, left, opacity;-webkit-transition-property:top, left, opacity;-moz-transition-property:top, left, opacity;-ms-transition-property:top, left, opacity;-o-transition-property:top, left, opacity;}.comment-form input[type="submit"],.fusion-button,.fusion-load-more-button,.ticket-selector-submit-btn[type="submit"]{font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:700;}.fusion-image-wrapper .fusion-rollover .fusion-rollover-gallery:before,.fusion-image-wrapper .fusion-rollover .fusion-rollover-link:before{font-size:15px;margin-left:-7px;line-height:36px;color:#ffffff;}.searchform .search-table .search-field input{height:33px;}.searchform .search-table .search-button input[type="submit"]{height:33px;width:33px;line-height:33px;}.fusion-title-size-one,h1{margin-top:0.67em;margin-bottom:0.67em;}.fusion-title-size-two,h2{margin-top:0em;margin-bottom:1.1em;}.fusion-title-size-three,h3{margin-top:1em;margin-bottom:1em;}.fusion-title-size-four,h4{margin-top:1.33em;margin-bottom:1.33em;}.fusion-title-size-five,h5{margin-top:1.67em;margin-bottom:1.67em;}.fusion-title-size-six,h6{margin-top:2.33em;margin-bottom:2.33em;}.fusion-logo{margin-top:31px;margin-right:0px;margin-bottom:31px;margin-left:0px;}.fusion-header-wrapper .fusion-row{padding-left:0px;padding-right:0px;max-width:1100px;}.fusion-header-v2 .fusion-header,.fusion-header-v3 .fusion-header,.fusion-header-v4 .fusion-header,.fusion-header-v5 .fusion-header{border-bottom-color:#e5e5e5;}#side-header .fusion-secondary-menu-search-inner{border-top-color:#e5e5e5;}.fusion-header .fusion-row{padding-top:0px;padding-bottom:0px;}.fusion-secondary-header{background-color:#a0ce4e;font-size:12px;color:#747474;border-bottom-color:#e5e5e5;}.fusion-secondary-header a,.fusion-secondary-header a:hover{color:#747474;}.fusion-header-v2 .fusion-secondary-header{border-top-color:#a0ce4e;}.fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-alignleft{border-bottom-color:#e5e5e5;}.fusion-header-tagline{font-size:16px;color:#747474;}.fusion-mobile-menu-sep,.fusion-secondary-main-menu{border-bottom-color:#e5e5e5;}#side-header{width:0px;padding-top:0px;padding-bottom:0px;border-color:#e5e5e5;}#side-header .side-header-content{padding-left:0px;padding-right:0px;}#side-header .fusion-main-menu > ul > li > a{padding-left:0px;padding-right:0px;border-top-color:#e5e5e5;border-bottom-color:#e5e5e5;text-align:left;height:auto;min-height:83px;}.side-header-left .fusion-main-menu > ul > li > a > .fusion-caret{right:0px;}.side-header-right .fusion-main-menu > ul > li > a > .fusion-caret{left:0px;}#side-header .fusion-main-menu > ul > li.current-menu-ancestor > a,#side-header .fusion-main-menu > ul > li.current-menu-item > a{color:#a0ce4e;border-right-color:#a0ce4e;border-left-color:#a0ce4e;}body.side-header-left #side-header .fusion-main-menu > ul > li > ul{left:-1px;}body.side-header-left #side-header .fusion-main-menu .fusion-custom-menu-item-contents{top:0;left:-1px;}#side-header .fusion-main-menu .fusion-main-menu-search .fusion-custom-menu-item-contents{border-top-width:1px;border-top-style:solid;}#side-header .fusion-secondary-menu > ul > li > a,#side-header .side-header-content-1,#side-header .side-header-content-2{color:#747474;font-size:12px;}.side-header-left #side-header .fusion-main-menu > ul > li.current-menu-ancestor > a,.side-header-left #side-header .fusion-main-menu > ul > li.current-menu-item > a{border-right-width:3px;}.side-header-right #side-header .fusion-main-menu > ul > li.current-menu-ancestor > a,.side-header-right #side-header .fusion-main-menu > ul > li.current-menu-item > a{border-left-width:3px;}.side-header-right #side-header .fusion-main-menu ul .fusion-dropdown-menu .sub-menu,.side-header-right #side-header .fusion-main-menu ul .fusion-dropdown-menu .sub-menu li ul,.side-header-right #side-header .fusion-main-menu ul .fusion-menu-login-box .sub-menu{left:-170px;}.side-header-right #side-header .fusion-main-menu-search .fusion-custom-menu-item-contents{left:-250px;}.side-header-right #side-header .fusion-main-menu-cart .fusion-custom-menu-item-contents{left:-180px;}.fusion-main-menu > ul > li{padding-right:45px;}.fusion-main-menu > ul > li > a{border-top:3px solid transparent;height:83px;line-height:83px;font-family:\'Antic Slab\', Arial, Helvetica, sans-serif;font-weight:400;font-size:14px;color:#333333;}.fusion-megamenu-icon img{max-height:14px;}.fusion-main-menu > ul > li > a:hover{color:#a0ce4e;border-color:#a0ce4e;}.fusion-main-menu > ul > .fusion-menu-item-button > a:hover{border-color:transparent;}.fusion-main-menu .current-menu-ancestor > a,.fusion-main-menu .current-menu-item > a,.fusion-main-menu .current-menu-parent > a,.fusion-main-menu .current_page_item > a{color:#a0ce4e;border-color:#a0ce4e;}.fusion-main-menu > ul > .fusion-menu-item-button > a{border-color:transparent;}.fusion-main-menu .fusion-main-menu-icon:after{color:#333333;height:14px;width:14px;}.fusion-main-menu .fusion-main-menu-icon:hover{border-color:transparent;}.fusion-main-menu .fusion-main-menu-icon:hover:after{color:#a0ce4e;}.fusion-main-menu .fusion-main-menu-icon-active:after,.fusion-main-menu .fusion-main-menu-search-open .fusion-main-menu-icon:after{color:#a0ce4e;}.fusion-main-menu .sub-menu{background-color:#f2efef;width:170px;border-top:3px solid #a0ce4e;font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:400;box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-webkit-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-moz-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);}.fusion-main-menu .sub-menu ul{left:170px;top:-3px;}.fusion-main-menu .sub-menu li a{border-bottom:1px solid #dcdadb;padding-top:7px;padding-bottom:7px;color:#333333;font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:400;font-size:13px;}.fusion-main-menu .sub-menu li a:hover{background-color:#f8f8f8;}.fusion-main-menu .sub-menu .current-menu-item > a,.fusion-main-menu .sub-menu .current-menu-parent > a,.fusion-main-menu .sub-menu .current_page_item > a{background-color:#f8f8f8;}.fusion-main-menu .fusion-custom-menu-item-contents{font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:400;}.fusion-main-menu .fusion-main-menu-cart .fusion-custom-menu-item-contents,.fusion-main-menu .fusion-main-menu-search .fusion-custom-menu-item-contents,.fusion-main-menu .fusion-menu-login-box .fusion-custom-menu-item-contents{background-color:#f2efef;border-color:#dcdadb;}.fusion-secondary-menu > ul > li{border-color:#e5e5e5;}.fusion-secondary-menu > ul > li > a{height:44px;line-height:44px;}.fusion-secondary-menu .sub-menu{width:100px;background-color:#ffffff;border-color:#e5e5e5;}.fusion-secondary-menu .sub-menu a{border-color:#e5e5e5;color:#747474;}.fusion-secondary-menu .sub-menu a:hover{background-color:#fafafa;color:#333333;}.fusion-secondary-menu > ul > li > .sub-menu .sub-menu{left:100px;}.fusion-secondary-menu .fusion-custom-menu-item-contents{background-color:#ffffff;border-color:#e5e5e5;color:#747474;}.fusion-secondary-menu .fusion-secondary-menu-icon,.fusion-secondary-menu .fusion-secondary-menu-icon:hover{color:#333333;}.fusion-secondary-menu .fusion-menu-cart-items a{color:#747474;}.fusion-secondary-menu .fusion-menu-cart-item a{border-color:#e5e5e5;}.fusion-secondary-menu .fusion-menu-cart-item img{border-color:#e0dede;}.fusion-secondary-menu .fusion-menu-cart-item a:hover{background-color:#fafafa;color:#333333;}.fusion-secondary-menu-icon{background-color:#fafafa;color:#333333;}.fusion-secondary-menu-icon:after,.fusion-secondary-menu-icon:before{color:#333333;}.fusion-contact-info{line-height:44px;}.fusion-megamenu-holder{border-color:#a0ce4e;}.fusion-megamenu{background-color:#f2efef;box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-webkit-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);-moz-box-shadow:1px 1px 30px rgba(0, 0, 0, 0.06);}.fusion-megamenu-wrapper .fusion-megamenu-submenu{border-color:#dcdadb;}.fusion-megamenu-wrapper .fusion-megamenu-submenu .sub-menu a{padding-top:5px;padding-bottom:5px;}.fusion-megamenu-wrapper .fusion-megamenu-submenu > a:hover{background-color:#f8f8f8;color:#333333;font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:400;font-size:13;}.fusion-megamenu-title{font-family:\'Antic Slab\', Arial, Helvetica, sans-serif;font-weight:400;font-size:18px;color:#333333;}.fusion-megamenu-title a{color:#333333;}.fusion-megamenu-bullet{border-left-color:#333333;}.fusion-megamenu-widgets-container{color:#333333;font-family:\'PT Sans\', Arial, Helvetica, sans-serif;font-weight:400;font-size:13px;}.fusion-header-wrapper.fusion-is-sticky .fusion-header,.fusion-header-wrapper.fusion-is-sticky .fusion-secondary-main-menu{background-color:rgba(255,255,255,0.97);}.no-rgba .fusion-header-wrapper.fusion-is-sticky .fusion-header,.no-rgba .fusion-header-wrapper.fusion-is-sticky .fusion-secondary-main-menu{background-color:rgba(255,255,255,0.97);opacity:0.97;filter:progid: DXImageTransform.Microsoft.Alpha(Opacity=97);}.fusion-is-sticky .fusion-main-menu > ul > li:last-child{padding-right:0;}.fusion-mobile-selector{background-color:#f9f9f9;border-color:#dadada;font-size:12px;height:35px;line-height:35px;color:#333333;}.fusion-selector-down{height:33px;line-height:33px;border-color:#dadada;}.fusion-selector-down:before{color:#dadada;}.fusion-mobile-menu-design-modern .fusion-mobile-nav-holder > ul,.fusion-mobile-nav-holder > ul{border-color:#dadada;}.fusion-mobile-nav-item a{color:#333333;font-size:12px;background-color:#f9f9f9;border-color:#dadada;height:35px;line-height:35px;}.fusion-mobile-nav-item a:hover{background-color:#f6f6f6;}.fusion-mobile-nav-item a:before{color:#333333;}.fusion-mobile-current-nav-item > a{background-color:#f6f6f6;}.fusion-mobile-menu-icons{margin-top:0px;}.fusion-mobile-menu-icons a{color:#dadada;}.fusion-mobile-menu-icons a:before{color:#dadada;}.fusion-open-submenu{font-size:12px;height:35px;line-height:35px;}.fusion-open-submenu:hover{color:#a0ce4e;}#wrapper .post-content .content-box-heading{font-size:18px;line-height:27px;}.fusion-social-links-header .fusion-social-networks a{font-size:16px;}.fusion-social-links-header .fusion-social-networks.boxed-icons a{padding:8px;}.fusion-social-links-footer .fusion-social-networks a{font-size:16px;}.fusion-social-links-footer .fusion-social-networks.boxed-icons a{padding:8px;}.fusion-sharing-box .fusion-social-networks a{font-size:16px;}.fusion-sharing-box .fusion-social-networks.boxed-icons a{padding:8px;}.post-content .fusion-social-links .fusion-social-networks a,.widget .fusion-social-links .fusion-social-networks a{font-size:16px;}.post-content .fusion-social-links .fusion-social-networks.boxed-icons a,.widget .fusion-social-links .fusion-social-networks.boxed-icons a{padding:8px;}.avada-select-parent .select-arrow,.select-arrow{height:33px;line-height:33px;}#wrapper{width:100%;max-width:none;}#side-header,.fusion-header,.layout-boxed-mode .side-header-wrapper{background-color:rgba(255,255,255,1);}.fusion-secondary-main-menu{background-color:rgba(255,255,255,1);}.rev_slider_wrapper{position:relative;}.rev_slider_wrapper .shadow-left{position:absolute;pointer-events:none;background-image:url("http://duktor-wordpress/content/themes/Avada/assets/images/shadow-top.png");background-repeat:no-repeat;background-position:top center;height:42px;width:100%;top:-1px;z-index:99;}.rev_slider_wrapper .shadow-right{position:absolute;pointer-events:none;background-image:url("http://duktor-wordpress/content/themes/Avada/assets/images/shadow-bottom.png");background-repeat:no-repeat;background-position:bottom center;height:32px;width:100%;bottom:0;z-index:99;}.avada-skin-rev{border-top:1px solid #d2d3d4;border-bottom:1px solid #d2d3d4;box-sizing:content-box;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;}.tparrows{border-radius:0;-webkit-border-radius:0;}.rev_slider_wrapper .tp-leftarrow,.rev_slider_wrapper .tp-rightarrow{opacity:0.8;position:absolute;top:50% !important;margin-top:-31px !important;width:63px !important;height:63px !important;background:none;background-color:rgba(0, 0, 0, 0.5);color:#fff;}.rev_slider_wrapper .tp-leftarrow:before{content:"\\e61e";-webkit-font-smoothing:antialiased;margin-left:-2px;}.rev_slider_wrapper .tp-rightarrow:before{content:"\\e620";-webkit-font-smoothing:antialiased;margin-left:-1px;}.rev_slider_wrapper .tp-leftarrow:before,.rev_slider_wrapper .tp-rightarrow:before{position:absolute;padding:0;width:100%;line-height:63px;text-align:center;font-size:25px;font-family:\'icomoon\';}.rev_slider_wrapper .tp-rightarrow{left:auto;right:0;background-position:29px 19px;margin-left:0;z-index:100;}.no-rgba .rev_slider_wrapper .tp-leftarrow,.no-rgba .rev_slider_wrapper .tp-rightarrow{background-color:#ccc;}.rev_slider_wrapper:hover .tp-leftarrow,.rev_slider_wrapper:hover .tp-rightarrow{display:block;opacity:0.8;}.rev_slider_wrapper .tp-leftarrow:hover,.rev_slider_wrapper .tp-rightarrow:hover{opacity:1;}.rev_slider_wrapper .tp-leftarrow{background-position:19px 19px;left:0;margin-left:0;z-index:100;}.rev_slider_wrapper .tp-leftarrow.hidearrows,.rev_slider_wrapper .tp-rightarrow.hidearrows{opacity:0;}.tp-bullets .bullet.last{clear:none;}.side-header-left .fusion-footer-parallax,body.side-header-left #wrapper{margin-left:280px;}.side-header-right .fusion-footer-parallax,body.side-header-right #wrapper{margin-right:280px;}body.side-header-left #side-header #nav .login-box,body.side-header-left #side-header #nav .main-nav-search-form,body.side-header-left #side-header #nav > ul > li > ul{left:279px;}body.side-header-left #slidingbar .avada-row,body.side-header-right #slidingbar .avada-row{max-width:none;}@media only screen and (max-width: 800px){.fusion-mobile-menu-design-modern .fusion-secondary-header{padding-left:0 !important;padding-right:0 !important;padding:0px;}#side-header{width:auto;}.no-overflow-y{overflow-y:visible !important;}.fusion-layout-column{margin-left:0;margin-right:0;}.fusion-layout-column:nth-child(2n),.fusion-layout-column:nth-child(3n),.fusion-layout-column:nth-child(4n),.fusion-layout-column:nth-child(5n){margin-left:0;margin-right:0;}.fusion-layout-column.fusion-spacing-no{margin-bottom:0;width:100%;}.fusion-layout-column.fusion-spacing-yes{width:100%;}.fusion-filters{border-bottom:0;}.fusion-body .fusion-filter{float:none;margin:0;border-bottom:1px solid #E7E6E6;}.fusion-header .fusion-row{padding-left:0;padding-right:0;}.fusion-header-wrapper #side-header,.fusion-header-wrapper .fusion-header,.fusion-header-wrapper .fusion-secondary-main-menu{background-color:#ffffff;}.fusion-header-wrapper .fusion-row{padding-left:0;padding-right:0;}.fusion-footer-copyright-area > .fusion-row,.fusion-footer-widget-area > .fusion-row{padding-left:0;padding-right:0;}.fusion-secondary-header .fusion-row{display:block;}.fusion-secondary-header .fusion-alignleft{margin-right:0;}.fusion-secondary-header .fusion-alignright{margin-left:0;}body.fusion-body .fusion-secondary-header .fusion-alignright > *{float:none;}body.fusion-body .fusion-secondary-header .fusion-alignright .fusion-social-links-header .boxed-icons{margin-bottom:5px;}.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-header,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-header,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-header{padding-top:20px;padding-bottom:20px;}.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-logo a,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-logo a,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-logo a{float:none;text-align:center;margin:0 !important;}.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-main-menu{display:none;}.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-mobile-nav-holder{display:block;margin-top:20px;}.fusion-mobile-menu-design-classic .fusion-secondary-header{padding:10px;}.fusion-mobile-menu-design-classic .fusion-secondary-header .fusion-mobile-nav-holder{margin-top:0;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-header,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-header{padding-top:20px;padding-bottom:20px;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-secondary-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-secondary-main-menu{padding-top:6px;padding-bottom:6px;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-main-menu,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-main-menu{display:none;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-mobile-nav-holder{display:block;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-logo a,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-logo,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-logo a{float:none;text-align:center;margin:0 !important;}.fusion-mobile-menu-design-classic.fusion-header-v4 .searchform,.fusion-mobile-menu-design-classic.fusion-header-v5 .searchform{display:block;float:none;width:100%;margin:0;margin-top:13px;}.fusion-mobile-menu-design-classic.fusion-header-v4 .search-table,.fusion-mobile-menu-design-classic.fusion-header-v5 .search-table{width:100%;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-logo a{float:none;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-header-banner{margin-top:10px;}.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-secondary-main-menu .searchform{display:none;}.fusion-mobile-menu-design-classic .fusion-alignleft{margin-bottom:10px;}.fusion-mobile-menu-design-classic .fusion-alignleft,.fusion-mobile-menu-design-classic .fusion-alignright{float:none;width:100%;line-height:normal;display:block;}.fusion-mobile-menu-design-classic .fusion-contact-info{text-align:center;line-height:normal;}.fusion-mobile-menu-design-classic .fusion-secondary-menu{display:none;}.fusion-mobile-menu-design-classic .fusion-social-links-header{max-width:100%;margin-top:5px;text-align:center;}.fusion-mobile-menu-design-classic .fusion-social-links-header a{margin-bottom:5px;}.fusion-mobile-menu-design-classic .fusion-header-tagline{float:none;text-align:center;margin-top:10px;line-height:24px;}.fusion-mobile-menu-design-classic .fusion-header-banner{float:none;text-align:center;margin:0 auto;width:100%;margin-top:20px;clear:both;}.fusion-mobile-menu-design-modern .ubermenu-responsive-toggle,.fusion-mobile-menu-design-modern .ubermenu-sticky-toggle-wrapper{clear:both;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-main-menu{display:none;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-header,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-header{padding-top:20px;padding-bottom:20px;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-header .fusion-row,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-header .fusion-row{width:100%;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-logo{margin:0 !important;}.fusion-mobile-menu-design-modern.fusion-header-v1 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v2 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v3 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v4 .modern-mobile-menu-expanded .fusion-logo,.fusion-mobile-menu-design-modern.fusion-header-v5 .modern-mobile-menu-expanded .fusion-logo{margin-bottom:20px !important;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-nav-holder{padding-top:20px;margin-left:-30px;margin-right:-30px;margin-bottom:-20px;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-nav-holder > ul{display:block;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-sticky-nav-holder{display:none;}.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-menu-icons,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-menu-icons{display:block;}.fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-row{padding-left:0px;padding-right:0px;}.fusion-mobile-menu-design-modern .fusion-social-links-header{max-width:100%;text-align:center;margin-top:10px;margin-bottom:8px;}.fusion-mobile-menu-design-modern .fusion-social-links-header a{margin-right:20px;margin-bottom:5px;}.fusion-mobile-menu-design-modern .fusion-alignleft{border-bottom:1px solid transparent;}.fusion-mobile-menu-design-modern .fusion-alignleft,.fusion-mobile-menu-design-modern .fusion-alignright{width:100%;float:none;display:block;}.fusion-body .fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-alignleft,.fusion-body .fusion-mobile-menu-design-modern .fusion-secondary-header .fusion-alignright{text-align:center;}.fusion-mobile-menu-design-modern .fusion-secondary-menu > ul > li{display:inline-block;text-align:left;}.fusion-body .fusion-mobile-menu-design-modern .fusion-secondary-menu > ul > li{float:none;}.fusion-mobile-menu-design-modern .fusion-secondary-menu-cart{border-right:0;}.fusion-mobile-menu-design-modern .fusion-secondary-menu-icon{background-color:transparent;padding-left:10px;padding-right:7px;min-width:100%;}.fusion-mobile-menu-design-modern .fusion-secondary-menu-icon:after{display:none;}.fusion-mobile-menu-design-modern .fusion-secondary-menu .fusion-secondary-menu-icon,.fusion-mobile-menu-design-modern .fusion-secondary-menu .fusion-secondary-menu-icon:hover,.fusion-mobile-menu-design-modern .fusion-secondary-menu-icon:before{color:#747474;}.fusion-mobile-menu-design-modern .fusion-header-tagline{margin-top:10px;float:none;line-height:24px;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-logo{width:50%;float:left;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-logo a{float:none;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-logo .searchform{float:none;display:none;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-header-banner{margin-top:10px;}.fusion-mobile-menu-design-modern.fusion-header-v5.fusion-logo-center .fusion-logo{float:left;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-nav-holder{padding-top:0;margin-left:-30px;margin-right:-30px;margin-bottom:0;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-secondary-main-menu,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-secondary-main-menu{position:static;border:0;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-secondary-main-menu .fusion-mobile-nav-holder > ul,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-secondary-main-menu .fusion-mobile-nav-holder > ul{border:0;}.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-secondary-main-menu .searchform,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-secondary-main-menu .searchform{float:none;}.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-sticky-header-wrapper,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-sticky-header-wrapper{position:fixed;width:100%;}.fusion-mobile-menu-design-modern.fusion-logo-right.fusion-header-v4 .fusion-logo,.fusion-mobile-menu-design-modern.fusion-logo-right.fusion-header-v5 .fusion-logo{float:right;}.fusion-mobile-menu-design-modern.fusion-sticky-menu-only.fusion-header-v4 .fusion-secondary-main-menu,.fusion-mobile-menu-design-modern.fusion-sticky-menu-only.fusion-header-v5 .fusion-secondary-main-menu{position:static;}.fusion-mobile-menu-design-modern.fusion-sticky-menu-only.fusion-header-v4 .fusion-header-tagline,.fusion-mobile-menu-design-modern.fusion-sticky-menu-only.fusion-header-v5 .fusion-header-tagline{display:none;}.fusion-mobile-menu-design-classic.fusion-header-v1 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v2 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v3 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v4 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-classic.fusion-header-v5 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v1 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v2 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v3 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v4 .fusion-mobile-sticky-nav-holder,.fusion-mobile-menu-design-modern.fusion-header-v5 .fusion-mobile-sticky-nav-holder{display:none;}.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v1.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v2.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v3.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v4.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v5.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v1.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v2.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v3.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v4.fusion-sticky-menu-1 .fusion-mobile-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-modern.fusion-header-v5.fusion-sticky-menu-1 .fusion-mobile-nav-holder{display:none;}.fusion-mobile-menu-design-classic .fusion-mobile-nav-item,.fusion-mobile-menu-design-classic .fusion-mobile-selector,.fusion-mobile-menu-design-modern .fusion-mobile-nav-item,.fusion-mobile-menu-design-modern .fusion-mobile-selector{text-align:left;}.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v1.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v2.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v3.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v4.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder,.fusion-is-sticky .fusion-mobile-menu-design-classic.fusion-header-v5.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder{display:block;}.fusion-mobile-menu-design-classic .fusion-mobile-nav-holder .fusion-secondary-menu-icon{text-align:inherit;}.fusion-mobile-menu-design-classic .fusion-mobile-nav-holder .fusion-secondary-menu-icon:after,.fusion-mobile-menu-design-classic .fusion-mobile-nav-holder .fusion-secondary-menu-icon:before{display:none;}.fusion-body .fusion-page-title-bar{padding-top:5px;padding-bottom:5px;min-height:60px;height:auto;}.fusion-page-title-bar-left .fusion-page-title-captions,.fusion-page-title-bar-left .fusion-page-title-secondary,.fusion-page-title-bar-right .fusion-page-title-captions,.fusion-page-title-bar-right .fusion-page-title-secondary{display:block;float:none;width:100%;line-height:normal;}.fusion-page-title-bar-left .fusion-page-title-secondary{text-align:left;}.fusion-page-title-bar-left .searchform{display:block;max-width:100%;}.fusion-page-title-bar-right .fusion-page-title-secondary{text-align:right;}.fusion-page-title-bar-right .searchform{max-width:100%;}.fusion-page-title-row{display:table;width:100%;min-height:50px;}.fusion-page-title-bar-center .fusion-page-title-row{width:auto;}.fusion-page-title-wrapper{display:table-cell;vertical-align:middle;}.fusion-body .fusion-blog-layout-medium-alternate .fusion-post-content,.fusion-body .fusion-blog-layout-medium-alternate .has-post-thumbnail .fusion-post-content{float:none;clear:both;margin:0;padding-top:20px;}.fusion-author .fusion-social-networks{display:block;margin-top:10px;}.fusion-body .fusion-author .fusion-social-networks{text-align:center;}.fusion-author .fusion-social-networks .fusion-social-network-icon:first-child{margin-left:0;}.fusion-author-tagline{display:block;float:none;text-align:center;max-width:100%;}#side-header .fusion-mobile-logo-1 .fusion-standard-logo,.fusion-mobile-logo-1 .fusion-standard-logo{display:none;}#side-header .fusion-mobile-logo-1 .fusion-mobile-logo-1x,.fusion-mobile-logo-1 .fusion-mobile-logo-1x{display:inline-block;}.fusion-secondary-menu-icon{min-width:100%;}.fusion-content-boxes.content-boxes-clean-horizontal .content-box-column,.fusion-content-boxes.content-boxes-clean-vertical .content-box-column{border-right-width:1px;}.fusion-content-boxes .content-box-shortcode-timeline{display:none;}.fusion-columns-1 .fusion-column:first-child,.fusion-columns-2 .fusion-column:first-child,.fusion-columns-3 .fusion-column:first-child,.fusion-columns-4 .fusion-column:first-child,.fusion-columns-5 .fusion-column:first-child{margin-left:0;}.fusion-columns-5 .col-lg-2,.fusion-columns-5 .col-md-2,.fusion-columns-5 .col-sm-2{width:100%;}.fusion-columns .fusion-column{float:none;width:100% !important;margin:0 0 50px;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;}.avada-container .columns{float:none;width:100%;margin-bottom:20px;}.avada-container .columns .col{float:left;}.avada-container .col img{display:block;margin:0 auto;}#wrapper{width:auto !important;}.create-block-format-context{display:none;}.review{float:none;width:100%;}.fusion-body .fusion-social-links-footer,.fusion-copyright-notice{display:block;text-align:center;}.fusion-social-links-footer{width:auto;}.fusion-social-links-footer .fusion-social-networks{display:inline-block;float:none;margin-top:0;}.fusion-copyright-notice{padding:0 0 15px;}.fusion-copyright-notice:after,.fusion-social-networks:after{content:"";display:block;clear:both;}.fusion-copyright-notice li,.fusion-social-networks li{float:none;display:inline-block;}.fusion-title{margin-top:0px !important;margin-bottom:20px !important;}#main .cart-empty{float:none;text-align:center;border-top:1px solid;border-bottom:none;width:100%;line-height:normal !important;height:auto !important;margin-bottom:10px;padding-top:10px;}#main .return-to-shop{float:none;border-top:none;border-bottom:1px solid;width:100%;text-align:center;line-height:normal !important;height:auto !important;padding-bottom:10px;}#content.full-width{margin-bottom:0;}.sidebar .social_links .social li{width:auto;margin-right:5px;}#comment-input{margin-bottom:0;}#comment-input input{width:90%;float:none !important;margin-bottom:10px;}#comment-textarea textarea{width:90%;}.widget.facebook_like iframe{width:100% !important;max-width:none !important;}.pagination{margin-top:40px;}.portfolio-one .portfolio-item .image{float:none;width:auto;height:auto;margin-bottom:20px;}h5.toggle span.toggle-title{width:80%;}#wrapper .sep-boxed-pricing .panel-wrapper{padding:0;}#wrapper .full-boxed-pricing .column,#wrapper .sep-boxed-pricing .column{float:none;margin-bottom:10px;margin-left:0;width:100%;}.share-box{height:auto;}#wrapper .share-box h4{float:none;line-height:20px !important;margin-top:0;padding:0;}.share-box ul{float:none;overflow:hidden;padding:0 25px;padding-bottom:15px;margin-top:0px;}.project-content .project-description{float:none !important;}.single-avada_portfolio .portfolio-half .project-content .project-description h3{margin-top:24px;}.project-content .fusion-project-description-details{margin-bottom:50px;}.project-content .project-description,.project-content .project-info{width:100% !important;}.portfolio-half .flexslider{width:100% !important;}.portfolio-half .project-content{width:100% !important;}#style_selector{display:none;}.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev{display:none !important;}#footer .social-networks{width:100%;margin:0 auto;position:relative;left:-11px;}.tab-holder .tabs{height:auto !important;width:100% !important;}.shortcode-tabs .tab-hold .tabs li{width:100% !important;}body .shortcode-tabs .tab-hold .tabs li,body.dark .sidebar .tab-hold .tabs li{border-right:none !important;}.error-message{line-height:170px;margin-top:20px;}.error_page .useful_links{width:100%;}.error-page .useful_links{padding-left:0;}.fusion-google-map{width:100% !important;margin-bottom:20px !important;}.social_links_shortcode .social li{width:10% !important;}#wrapper .ei-slider{width:100% !important;height:200px !important;}.progress-bar{margin-bottom:10px !important;}#wrapper .content-boxes-icon-boxed .content-wrapper-boxed{min-height:inherit !important;padding-bottom:20px;padding-left:3%;padding-right:3%;}#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column{margin-bottom:55px;}.fusion-counters-box .fusion-counter-box{margin-bottom:20px;padding:0 15px;}.fusion-counters-box .fusion-counter-box:last-child{margin-bottom:0;}.popup{display:none !important;}.share-box .social-networks{text-align:left;}.product .images #carousel .flex-direction-nav,.product .images #slider .flex-direction-nav{display:none !important;}.fullwidth-box{background-attachment:scroll !important;}#toTop{bottom:30px;border-radius:4px;height:40px;z-index:10000;-webkit-border-radius:4px;}#toTop:before{line-height:38px;}#toTop:hover{background-color:#333333;}.no-mobile-totop .to-top-container{display:none;}.no-mobile-slidingbar #slidingbar-area{display:none;}.no-mobile-slidingbar.mobile-logo-pos-left .mobile-menu-icons{margin-right:0;}.tfs-slider .slide-content-container .btn{min-height:0 !important;padding-left:30px;padding-right:30px !important;height:26px !important;line-height:26px !important;}.fusion-soundcloud iframe{width:100%;}.ua-mobile #main,.ua-mobile .footer-area,.ua-mobile .fusion-page-title-bar,.ua-mobile body{background-attachment:scroll !important;}.fusion-revslider-mobile-padding{padding-left:30px !important;padding-right:30px !important;}.fusion-contact-info{padding:1em 30px;line-height:1.5em;}}@media only screen and (max-width: 1100px){.width-100#main{padding-left:30px !important;padding-right:30px !important;}.width-100 .fusion-section-separator,.width-100 .nonhundred-percent-fullwidth{padding-left:30px !important;padding-right:30px !important;}.width-100 .fullwidth-box,.width-100 .fusion-section-separator{margin-left:-30px !important;margin-right:-30px !important;}}@media only screen and (min-width: 1130px) and (max-width: 1210px){.fusion-portfolio-six .fusion-portfolio-post,.grid-layout-6 .fusion-post-grid{width:20% !important;}0{width:25% !important;}}@media only screen and (min-width: 800px) and (max-width: 1130px){.fusion-portfolio-six .fusion-portfolio-post,.grid-layout-6 .fusion-post-grid{width:25% !important;}.fusion-portfolio-five .fusion-portfolio-post,.grid-layout-5 .fusion-post-grid{width:33.3333333333% !important;}.fusion-portfolio-four .fusion-portfolio-post,.grid-layout-4 .fusion-post-grid{width:33.3333333333% !important;}}@media only screen and (min-width: 700px ) and (max-width: 800px){.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-six .fusion-portfolio-post{width:33.3333333333% !important;}.fusion-blog-layout-grid-3 .fusion-post-grid,.fusion-blog-layout-grid-4 .fusion-post-grid,.fusion-blog-layout-grid-5 .fusion-post-grid,.fusion-portfolio-five .fusion-portfolio-post,.fusion-portfolio-four .fusion-portfolio-post,.fusion-portfolio-masonry .fusion-portfolio-post,.fusion-portfolio-three .fusion-portfolio-post{width:50% !important;}}@media only screen and (min-width: 640px) and (max-width: 700px){.fusion-blog-layout-grid-3 .fusion-post-grid,.fusion-blog-layout-grid-4 .fusion-post-grid,.fusion-blog-layout-grid-5 .fusion-post-grid,.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-five .fusion-portfolio-post,.fusion-portfolio-four .fusion-portfolio-post,.fusion-portfolio-masonry .fusion-portfolio-post,.fusion-portfolio-six .fusion-portfolio-post,.fusion-portfolio-three .fusion-portfolio-post{width:50% !important;}}@media only screen and (max-width: 640px){.fusion-blog-layout-grid .fusion-post-grid,.fusion-portfolio-post{width:100% !important;}.fusion-body .fusion-page-title-bar{max-height:none;}.fusion-body .fusion-page-title-bar h1{margin:0;}.fusion-body .fusion-page-title-secondary{margin-top:2px;}.fusion-blog-layout-large .fusion-meta-info .fusion-alignleft,.fusion-blog-layout-large .fusion-meta-info .fusion-alignright,.fusion-blog-layout-medium .fusion-meta-info .fusion-alignleft,.fusion-blog-layout-medium .fusion-meta-info .fusion-alignright{display:block;float:none;margin:0;width:100%;}.fusion-body .fusion-blog-layout-medium .fusion-post-slideshow{float:none;margin:0 0 20px 0;height:auto;width:auto;}.fusion-blog-layout-large-alternate .fusion-date-and-formats{margin-bottom:55px;}.fusion-body .fusion-blog-layout-large-alternate .fusion-post-content{margin:0;}.fusion-blog-layout-medium-alternate .has-post-thumbnail .fusion-post-slideshow{display:inline-block;float:none;margin-right:0;max-width:197px;}.fusion-blog-layout-grid .fusion-post-grid{position:static;width:100%;}#slidingbar-area .columns .col,.avada-container .columns .col,.footer-area .fusion-columns .fusion-column{float:none;width:100%;}.flex-direction-nav,.wooslider-direction-nav,.wooslider-pauseplay{display:none;}.share-box ul li{margin-bottom:10px;margin-right:15px;}.buttons a{margin-right:5px;}.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev{display:none !important;}#wrapper .ei-slider{width:100% !important;height:200px !important;}.progress-bar{margin-bottom:10px !important;}#wrapper .content-boxes-icon-boxed .content-wrapper-boxed{min-height:inherit !important;padding-bottom:20px;padding-left:3% !important;padding-right:3% !important;}#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column{margin-bottom:55px;}#wrapper .content-boxes-icon-boxed .content-box-column .heading h2{margin-top:-5px;}#wrapper .content-boxes-icon-boxed .content-box-column .more{margin-top:12px;}.page-template-contact-php .fusion-google-map{height:270px !important;}.share-box .social-networks li{margin-right:20px !important;}.timeline-icon{display:none !important;}.timeline-layout{padding-top:0 !important;}.fusion-counters-circle .counter-circle-wrapper{display:block;margin-right:auto;margin-left:auto;}.post-content .wooslider .wooslider-control-thumbs{margin-top:-10px;}body .wooslider .overlay-full.layout-text-left .slide-excerpt{padding:20px !important;}.content-boxes-icon-boxed .col{box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;}.social_links_shortcode li{height:40px !important;}.products-slider .es-nav span{transform:scale(0.5) !important;-webkit-transform:scale(0.5) !important;-moz-transform:scale(0.5) !important;-ms-transform:scale(0.5) !important;-o-transform:scale(0.5) !important;}.portfolio-masonry .portfolio-item{width:100% !important;}.table-1 table,.tkt-slctr-tbl-wrap-dv table{border-collapse:collapse;border-spacing:0;width:100%;}.table-1 td,.table-1 th,.tkt-slctr-tbl-wrap-dv td,.tkt-slctr-tbl-wrap-dv th{white-space:nowrap;}.table-2 table{border-collapse:collapse;border-spacing:0;width:100%;}.table-2 td,.table-2 th{white-space:nowrap;}#main,.footer-area,.page-title-bar,body{background-attachment:scroll !important;}.tfs-slider[data-animation="slide"]{height:auto !important;}#wrapper .share-box h4{display:block;float:none;line-height:20px !important;margin-top:0;padding:0;margin-bottom:10px;}.fusion-sharing-box .fusion-social-networks{float:none;display:block;width:100%;text-align:left;}#content{width:100% !important;margin-left:0px !important;}.sidebar{width:100% !important;float:none !important;margin-left:0 !important;clear:both;}.fusion-hide-on-mobile{display:none;}.fusion-blog-layout-timeline{padding-top:0;}.fusion-blog-layout-timeline .fusion-post-timeline{float:none;width:100%;}.fusion-blog-layout-timeline .fusion-timeline-date{margin-bottom:0;margin-top:2px;}.fusion-timeline-arrow,.fusion-timeline-circle,.fusion-timeline-icon,.fusion-timeline-line{display:none;}}@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: portrait){.fusion-blog-layout-grid-6 .fusion-post-grid,.fusion-portfolio-six .fusion-portfolio-post{width:33.3333333333% !important;}.fusion-blog-layout-grid-3 .fusion-post-grid,.fusion-blog-layout-grid-4 .fusion-post-grid,.fusion-blog-layout-grid-5 .fusion-post-grid,.fusion-portfolio-five .fusion-portfolio-post,.fusion-portfolio-four .fusion-portfolio-post,.fusion-portfolio-masonry .fusion-portfolio-post,.fusion-portfolio-three .fusion-portfolio-post{width:50% !important;}.fusion-body .fusion-page-title-bar .fusion-breadcrumbs{display:none;}#footer > .fusion-row,.footer-area > .fusion-row,.fusion-header .fusion-row,.fusion-secondary-header .fusion-row{padding-left:0px !important;padding-right:0px !important;}#wrapper .ei-slider{width:100% !important;height:200px !important;}#main,.fullwidth-box,.fusion-footer-widget-area,.page-title-bar,body{background-attachment:scroll !important;}.fusion-columns-1 .fusion-column:first-child,.fusion-columns-2 .fusion-column:first-child,.fusion-columns-3 .fusion-column:first-child,.fusion-columns-4 .fusion-column:first-child,.fusion-columns-5 .fusion-column:first-child{margin-left:0;}.fusion-column,.fusion-column:nth-child(2n),.fusion-column:nth-child(3n),.fusion-column:nth-child(4n),.fusion-column:nth-child(5n){margin-right:0;}#wrapper{width:auto !important;}.create-block-format-context{display:none;}.columns .col{float:none;width:100% !important;margin:0 0 20px;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;}.avada-container .columns{float:none;width:100%;margin-bottom:20px;}.avada-container .columns .col{float:left;}.avada-container .col img{display:block;margin:0 auto;}.review{float:none;width:100%;}.fusion-social-links-footer,.fusion-social-networks{display:block;text-align:center;}.fusion-social-links-footer{width:auto;}.fusion-social-links-footer .fusion-social-networks{display:inline-block;float:none;}.fusion-social-links-footer .fusion-social-networks .fusion-social-network-icon:first-child{margin-left:0;margin-right:0;}.fusion-social-networks{padding:0 0 15px;}.fusion-author .fusion-author-ssocial .fusion-author-tagline{float:none;text-align:center;max-width:100%;}.fusion-author .fusion-author-ssocial .fusion-social-networks{text-align:center;}.fusion-author .fusion-author-ssocial .fusion-social-networks .fusion-social-network-icon:first-child{margin-left:0;}.fusion-social-networks:after{content:"";display:block;clear:both;}.fusion-social-networks li{float:none;display:inline-block;}.fusion-reading-box-container .reading-box.reading-box-center,.fusion-reading-box-container .reading-box.reading-box-right{text-align:left;}.fusion-reading-box-container .continue{display:block;}.fusion-reading-box-container .mobile-button{display:none;float:none;}.fusion-title{margin-top:0px !important;margin-bottom:20px !important;}.fusion-body .fusion-page-title-bar{height:70px;}.fusion-page-title-bar-left .fusion-page-title-captions,.fusion-page-title-bar-left .fusion-page-title-secondary,.fusion-page-title-bar-right .fusion-page-title-captions,.fusion-page-title-bar-right .fusion-page-title-secondary{display:block;float:none;width:100%;line-height:normal;}.fusion-page-title-bar-left .fusion-page-title-secondary{text-align:left;}.fusion-page-title-bar-left .searchform{display:block;max-width:100%;}.fusion-page-title-bar-right .fusion-page-title-secondary{text-align:right;}.fusion-page-title-bar-right .searchform{max-width:100%;}.fusion-page-title-row{display:table;width:100%;height:100%;min-height:50px;}.fusion-page-title-wrapper{display:table-cell;vertical-align:middle;}.sidebar .social_links .social li{width:auto;margin-right:5px;}#comment-input{margin-bottom:0;}#comment-input input{width:90%;float:none !important;margin-bottom:10px;}#comment-textarea textarea{width:90%;}.pagination{margin-top:40px;}.portfolio-one .portfolio-item .image{float:none;width:auto;height:auto;margin-bottom:20px;}h5.toggle span.toggle-title{width:80%;}#wrapper .sep-boxed-pricing .panel-wrapper{padding:0;}#wrapper .full-boxed-pricing .column,#wrapper .sep-boxed-pricing .column{float:none;margin-bottom:10px;margin-left:0;width:100%;}.share-box{height:auto;}#wrapper .share-box h4{float:none;line-height:20px !important;padding:0;}.share-box ul{float:none;overflow:hidden;padding:0 25px;padding-bottom:15px;margin-top:0px;}.project-content .project-description{float:none !important;}.project-content .fusion-project-description-details{margin-bottom:50px;}.project-content .project-description,.project-content .project-info{width:100% !important;}.portfolio-half .flexslider{width:100%;}.portfolio-half .project-content{width:100% !important;}#style_selector{display:none;}.faq-tabs,.portfolio-tabs{height:auto;border-bottom-width:1px;border-bottom-style:solid;}.faq-tabs li,.portfolio-tabs li{float:left;margin-right:30px;border-bottom:0;}.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev{display:none !important;}nav#nav,nav#sticky-nav{margin-right:0;}#footer .social-networks{width:100%;margin:0 auto;position:relative;left:-11px;}.tab-holder .tabs{height:auto !important;width:100% !important;}.shortcode-tabs .tab-hold .tabs li{width:100% !important;}body .shortcode-tabs .tab-hold .tabs li,body.dark .sidebar .tab-hold .tabs li{border-right:none !important;}.error-message{line-height:170px;margin-top:20px;font-size:130px;}.error_page .useful_links{width:100%;padding-left:0;}.fusion-google-map{width:100% !important;margin-bottom:20px !important;}.social_links_shortcode .social li{width:10% !important;}.progress-bar{margin-bottom:10px !important;}.fusion-blog-layout-medium-alternate .fusion-post-content{float:none;width:100% !important;margin-top:20px;}#wrapper .content-boxes-icon-boxed .content-wrapper-boxed{min-height:inherit !important;padding-bottom:20px;padding-left:3%;padding-right:3%;}#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column{margin-bottom:55px;}.fusion-counters-box .fusion-counter-box{margin-bottom:20px;padding:0 15px;}.fusion-counters-box .fusion-counter-box:last-child{margin-bottom:0;}.popup{display:none !important;}.share-box .social-networks{text-align:left;}body #small-nav{visibility:visible !important;}{float:none !important;width:100% !important;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;}#nav-uber #megaMenu{width:100%;}.fullwidth-box{background-attachment:scroll;}#toTop{bottom:30px;border-radius:4px;height:40px;z-index:10000;-webkit-border-radius:4px;}#toTop:before{line-height:38px;}#toTop:hover{background-color:#333333;}.no-mobile-totop .to-top-container{display:none;}.no-mobile-slidingbar #slidingbar-area{display:none;}.tfs-slider .slide-content-container .btn{min-height:0 !important;padding-left:20px;padding-right:20px !important;height:26px !important;line-height:26px !important;}.fusion-soundcloud iframe{width:100%;}.fusion-columns-2 .fusion-column,.fusion-columns-2 .fusion-flip-box-wrapper,.fusion-columns-4 .fusion-column,.fusion-columns-4 .fusion-flip-box-wrapper{width:50% !important;float:left !important;}.fusion-columns-2 .fusion-column:nth-child(3n),.fusion-columns-2 .fusion-flip-box-wrapper:nth-child(3n),.fusion-columns-4 .fusion-column:nth-child(3n){clear:both;}.fusion-columns-3 .fusion-column,.fusion-columns-3 .fusion-flip-box-wrapper,.fusion-columns-5 .col-lg-2,.fusion-columns-5 .col-md-2,.fusion-columns-5 .col-sm-2,.fusion-columns-5 .fusion-column,.fusion-columns-5 .fusion-flip-box-wrapper,.fusion-columns-6 .fusion-column,.fusion-columns-6 .fusion-flip-box-wrapper{width:33.33% !important;float:left !important;}.fusion-columns-3 .fusion-column:nth-child(4n),.fusion-columns-3 .fusion-flip-box-wrapper:nth-child(4n),.fusion-columns-5 .fusion-column:nth-child(4n),.fusion-columns-5 .fusion-flip-box-wrapper:nth-child(4n),.fusion-columns-6 .fusion-column:nth-child(4n),.fusion-columns-6 .fusion-flip-box-wrapper:nth-child(4n){clear:both;}#slidingbar .fusion-column,.footer-area .fusion-column{margin-bottom:40px;}.fusion-layout-column.fusion-five-sixth,.fusion-layout-column.fusion-four-fifth,.fusion-layout-column.fusion-one-fifth,.fusion-layout-column.fusion-one-fourth,.fusion-layout-column.fusion-one-half,.fusion-layout-column.fusion-one-sixth,.fusion-layout-column.fusion-one-third,.fusion-layout-column.fusion-three-fifth,.fusion-layout-column.fusion-three-fourth,.fusion-layout-column.fusion-two-fifth,.fusion-layout-column.fusion-two-third{position:relative;float:left;margin-right:4%;margin-bottom:20px;}.fusion-layout-column.fusion-one-sixth{width:13.3333%;}.fusion-layout-column.fusion-five-sixth{width:82.6666%;}.fusion-layout-column.fusion-one-fifth{width:16.8%;}.fusion-layout-column.fusion-two-fifth{width:37.6%;}.fusion-layout-column.fusion-three-fifth{width:58.4%;}.fusion-layout-column.fusion-four-fifth{width:79.2%;}.fusion-layout-column.fusion-one-fourth{width:22%;}.fusion-layout-column.fusion-three-fourth{width:74%;}.fusion-layout-column.fusion-one-third{width:30.6666%;}.fusion-layout-column.fusion-two-third{width:65.3333%;}.fusion-layout-column.fusion-one-half{width:48%;}.fusion-layout-column.fusion-spacing-no{margin-left:0;margin-right:0;}.fusion-layout-column.fusion-one-sixth.fusion-spacing-no{width:16.6666666667% !important;}.fusion-layout-column.fusion-five-sixth.fusion-spacing-no{width:83.333333333% !important;}.fusion-layout-column.fusion-one-fifth.fusion-spacing-no{width:20% !important;}.fusion-layout-column.fusion-two-fifth.fusion-spacing-no{width:40% !important;}.fusion-layout-column.fusion-three-fifth.fusion-spacing-no{width:60% !important;}.fusion-layout-column.fusion-four-fifth.fusion-spacing-no{width:80% !important;}.fusion-layout-column.fusion-one-fourth.fusion-spacing-no{width:25% !important;}.fusion-layout-column.fusion-three-fourth.fusion-spacing-no{width:75% !important;}.fusion-layout-column.fusion-one-third.fusion-spacing-no{width:33.33333333% !important;}.fusion-layout-column.fusion-two-third.fusion-spacing-no{width:66.66666667% !important;}.fusion-layout-column.fusion-one-half.fusion-spacing-no{width:50% !important;}.fusion-layout-column.fusion-column-last{clear:right;zoom:1;margin-left:0;margin-right:0;}.fusion-column.fusion-spacing-no{margin-bottom:0;width:100% !important;}.sidebar{margin-left:0 !important;width:25% !important;}#content{margin-left:0 !important;}#main #content.with-sidebar,.has-sidebar #main #content,.has-sidebar .project-content .project-description{width:72% !important;}.sidebar-position-left .sidebar{float:left !important;}.sidebar-position-left #content{float:right !important;}.sidebar-position-right .sidebar{float:right !important;}.sidebar-position-right #content{float:left !important;}#sidebar-2{clear:left;}.ua-mobile #main,.ua-mobile .fusion-footer-widget-area,.ua-mobile .page-title-bar,.ua-mobile body{background-attachment:scroll !important;}#footer > .fusion-row,#header-sticky .fusion-row,.footer-area > .fusion-row,.fusion-header .fusion-row,.fusion-secondary-header .fusion-row{padding-left:0px !important;padding-right:0px !important;}.fusion-main-menu > ul > li{padding-right:25px;}.products .product-list-view{width:100% !important;min-width:100% !important;}}@media only screen and (max-width: 1220px){	.fusion-body .fusion-page-title-bar .fusion-breadcrumbs{display:none;}}@media only screen and (min-device-width: 768px) and (max-device-width: 1024px) and (orientation: landscape){#wrapper .fusion-page-title-bar{height:87px !important;}#wrapper .ei-slider{width:100%;}#main,.fullwidth-box,.fusion-footer-widget-area,.page-title-bar,body{background-attachment:scroll !important;}.fusion-main-menu > ul > li{padding-right:25px;}}@media only screen and (max-width: 1023px){body.side-header #wrapper{margin-left:0 !important;margin-right:0 !important;}#side-header{position:static;height:auto;width:100% !important;padding:20px 30px 20px 30px !important;margin:0 !important;border:none !important;}#side-header .side-header-wrapper{padding-bottom:0;}#side-header .header-social,#side-header .header-v4-content{display:none;}#side-header .fusion-logo{margin:0;float:left;}#side-header .side-header-content{padding:0 !important;}#side-header.fusion-mobile-menu-design-classic .fusion-logo{float:none;text-align:center;}body #wrapper .header-shadow:after,body.side-header #wrapper #side-header.header-shadow:before{position:static;height:auto;box-shadow:none;-webkit-box-shadow:none;-moz-box-shadow:none;}#side-header .fusion-main-menu,#side-header .side-header-content-1-2,#side-header .side-header-content-3{display:none;}#side-header.fusion-mobile-menu-design-classic .fusion-main-menu-container .fusion-mobile-nav-holder{display:block;margin-top:20px;}#side-header.fusion-mobile-menu-design-classic .fusion-main-menu-container .fusion-mobile-sticky-nav-holder{display:none;}#side-header.fusion-mobile-menu-design-modern .fusion-logo{float:left;margin:0;}#side-header.fusion-mobile-menu-design-modern .fusion-logo-left{float:left;}#side-header.fusion-mobile-menu-design-modern .fusion-logo-right{float:right;}#side-header.fusion-mobile-menu-design-modern .fusion-logo-center{float:left;}#side-header.fusion-mobile-menu-design-modern .fusion-mobile-menu-icons{display:block;}#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-right .fusion-mobile-menu-icons{float:left;}#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-left .fusion-mobile-menu-icons{float:right;}#side-header.fusion-mobile-menu-design-modern .fusion-logo-menu-left .fusion-mobile-menu-icons a:last-child{margin-left:0;}#side-header.fusion-mobile-menu-design-modern .fusion-main-menu-container .fusion-mobile-nav-holder,#side-header.fusion-mobile-menu-design-modern .side-header-wrapper > .fusion-secondary-menu-search{padding-top:20px;margin-left:-30px;margin-right:-30px;margin-bottom:-20px;}#side-header.fusion-mobile-menu-design-modern .fusion-main-menu-container .fusion-mobile-nav-holder > ul{display:block;border-right:0;border-left:0;border-bottom:0;}#side-header.fusion-is-sticky.fusion-sticky-menu-1 .fusion-mobile-nav-holder{display:none;}#side-header.fusion-is-sticky.fusion-sticky-menu-1 .fusion-mobile-sticky-nav-holder{display:none;}}@media only screen and (max-width: 800px) and (-webkit-min-device-pixel-ratio: 1.5), only screen and (max-width: 800px) and (min-resolution: 144dpi), only screen and (max-width: 800px) and (min-resolution: 1.5dppx){#side-header .fusion-mobile-logo-1 .fusion-mobile-logo-1x,.fusion-mobile-logo-1 .fusion-mobile-logo-1x{display:none;}#side-header .fusion-mobile-logo-1 .fusion-mobile-logo-2x,.fusion-mobile-logo-1 .fusion-mobile-logo-2x{display:inline-block;}}@media only screen and (max-width: 1000px){.no-csstransforms .sep-boxed-pricing .column{margin-left:1.5% !important;}}@media only screen and (min-width: 800px){body.side-header-right.layout-boxed-mode #side-header{position:absolute;top:0;}body.side-header-right.layout-boxed-mode #side-header .side-header-wrapper{position:absolute;}}@media screen and (max-width: 782px){.admin-bar p.demo_store,body.admin-bar #wrapper #slidingbar-area,body.layout-boxed-mode.side-header-right #slidingbar-area{top:46px;}body.body_blank.admin-bar{top:45px;}html #wpadminbar{z-index:99999 !important;position:fixed !important;}}@media screen and (max-width: 768px){.fusion-tabs.vertical-tabs .tab-pane{max-width:none !important;}}@media screen and (max-width: 767px){#content{width:100% !important;margin-left:0px !important;}.sidebar{width:100% !important;float:none !important;margin-left:0 !important;clear:both;}}@media only screen and (min-device-width: 320px) and (max-device-width: 640px){#wrapper{width:auto !important;overflow-x:hidden !important;}.fusion-columns .fusion-column{float:none;width:100% !important;margin:0 0 50px;box-sizing:border-box;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;}#slidingbar-area .fusion-columns .fusion-column,.footer-area .fusion-columns .fusion-column{float:left;width:98% !important;}.avada-container .columns{float:none;width:100%;margin-bottom:20px;}.avada-container .columns .col{float:left;}.avada-container .col img{display:block;margin:0 auto;}.review{float:none;width:100%;}.copyright,.social-networks{float:none;padding:0 0 15px;text-align:center;}.copyright:after,.social-networks:after{content:"";display:block;clear:both;}.copyright li,.social-networks li{float:none;display:inline-block;}.continue{display:none;}.mobile-button{display:block !important;float:none;}.title{margin-top:0px !important;margin-bottom:20px !important;}#content{width:100% !important;float:none !important;margin-left:0px !important;margin-bottom:50px;}#content.full-width{margin-bottom:0;}.sidebar{width:100% !important;float:none !important;margin-left:0 !important;clear:both;}.sidebar .social_links .social li{width:auto;margin-right:5px;}#comment-input{margin-bottom:0;}#comment-input input{width:90%;float:none !important;margin-bottom:10px;}#comment-textarea textarea{width:90%;}.widget.facebook_like iframe{width:100% !important;max-width:none !important;}.pagination{margin-top:40px;}.portfolio-one .portfolio-item .image{float:none;width:auto;height:auto;margin-bottom:20px;}h5.toggle span.toggle-title{width:80%;}#wrapper .sep-boxed-pricing .panel-wrapper{padding:0;}#wrapper .full-boxed-pricing .column,#wrapper .sep-boxed-pricing .column{float:none;margin-bottom:10px;margin-left:0;width:100%;}.share-box{height:auto;}#wrapper .share-box h4{float:none;line-height:20px !important;margin-top:0;padding:0;}.share-box ul{float:none;overflow:hidden;padding:0 25px;padding-bottom:25px;margin-top:0px;}.project-content .project-description{float:none !important;}.project-content .fusion-project-description-details{margin-bottom:50px;}.project-content .project-description,.project-content .project-info{width:100% !important;}.portfolio-half .flexslider{width:100% !important;}.portfolio-half .project-content{width:100% !important;}#style_selector{display:none;}.ls-avada .ls-nav-next,.ls-avada .ls-nav-prev{display:none !important;}#footer .social-networks{width:100%;margin:0 auto;position:relative;left:-11px;}.recent-works-items a{max-width:64px;}#slidingbar-area .flickr_badge_image img,.footer-area .flickr_badge_image img{max-width:64px;padding:3px !important;}.tab-holder .tabs{height:auto !important;width:100% !important;}.shortcode-tabs .tab-hold .tabs li{width:100% !important;}body .shortcode-tabs .tab-hold .tabs li,body.dark .sidebar .tab-hold .tabs li{border-right:none !important;}.error_page .useful_links{width:100%;padding-left:0;}.fusion-google-map{width:100% !important;margin-bottom:20px !important;}.social_links_shortcode .social li{width:10% !important;}#wrapper .ei-slider{width:100% !important;height:200px !important;}.progress-bar{margin-bottom:10px !important;}#wrapper .content-boxes-icon-boxed .content-wrapper-boxed{min-height:inherit !important;padding-bottom:20px;padding-left:3% !important;padding-right:3% !important;}#wrapper .content-boxes-icon-boxed .content-box-column,#wrapper .content-boxes-icon-on-top .content-box-column{margin-bottom:55px;}.share-box .social-networks{text-align:left;}}@media only screen and (min-device-width: 768px) and (max-device-width: 1024px){#wrapper .ei-slider{width:100%;}}@media only screen and (min-device-width: 320px) and (max-device-width: 480px){#wrapper .ei-slider{width:100%;}}@media screen and (-ms-high-contrast: active), (-ms-high-contrast: none){.gravity-select-parent .select-arrow{height:24px;line-height:24px;}.fusion-imageframe, .imageframe-align-center{font-size:0px;line-height:normal;}}@media only screen and (min-width: 801px) and (max-width: 1014px){#wrapper{width:auto;}}@media only screen and (min-device-width: 801px) and (max-device-width: 1014px){#wrapper{width:auto;}}@-webkit-keyframes avadaSonarEffect{0%{opacity:0.3;}40%{opacity:0.5;box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-webkit-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-moz-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);}100%{box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-webkit-transform:scale(1.5);opacity:0;-webkit-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-moz-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);}}@-moz-keyframes avadaSonarEffect{0%{opacity:0.3;}40%{opacity:0.5;box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-webkit-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-moz-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);}100%{box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-moz-transform:scale(1.5);opacity:0;-webkit-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-moz-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);}}@keyframes avadaSonarEffect{0%{opacity:0.3;}40%{opacity:0.5;box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-webkit-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-moz-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);}100%{box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);transform:scale(1.5);opacity:0;-webkit-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-moz-box-shadow:0 0 0 2px rgba(255,255,255,0.1), 0 0 10px 10px #a0ce4e, 0 0 0 10px rgba(255,255,255,0.5);-webkit-transform:scale(1.5);-moz-transform:scale(1.5);-ms-transform:scale(1.5);-o-transform:scale(1.5);}}', 'no') ; 
INSERT INTO `wp_options` VALUES (174, 'layerslider_update_info', 'O:8:"stdClass":1:{s:7:"checked";i:1444050565;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (175, 'hmbkp_schedule_1444050597', 'a:4:{s:4:"type";s:8:"database";s:12:"reoccurrence";s:11:"hmbkp_daily";s:19:"schedule_start_time";d:1444078800;s:11:"max_backups";i:7;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (176, 'hmbkp_schedule_1444050598', 'a:4:{s:4:"type";s:8:"complete";s:12:"reoccurrence";s:12:"hmbkp_weekly";s:19:"schedule_start_time";d:1444525200;s:11:"max_backups";i:3;}', 'yes') ; 
INSERT INTO `wp_options` VALUES (177, 'hmbkp_plugin_version', '3.2.7', 'yes') ; 
INSERT INTO `wp_options` VALUES (182, '_transient_timeout_hmbkp_wp_cron_test_beacon', '1444655707', 'no') ; 
INSERT INTO `wp_options` VALUES (183, '_transient_hmbkp_wp_cron_test_beacon', '1', 'no') ; 
INSERT INTO `wp_options` VALUES (184, '_transient_timeout_hmbkp_directory_filesizes', '1444137332', 'no') ; 
INSERT INTO `wp_options` VALUES (189, '_transient_timeout_hm_backdrop-604ba5d9a07b8b120b80cf17d561', '1444053114', 'no') ; 
INSERT INTO `wp_options` VALUES (190, '_transient_hm_backdrop-604ba5d9a07b8b120b80cf17d561', 'a:2:{s:8:"callback";s:24:"hmbkp_run_schedule_async";s:6:"params";a:1:{i:0;s:10:"1444050597";}}', 'no') ;
#
# End of data contents of table wp_options
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_postmeta (1 records)
#
 
INSERT INTO `wp_postmeta` VALUES (1, 2, '_wp_page_template', 'default') ;
#
# End of data contents of table wp_postmeta
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------


#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_posts (3 records)
#
 
INSERT INTO `wp_posts` VALUES (1, 1, '2015-10-05 14:08:37', '2015-10-05 12:08:37', 'Willkommen zur deutschen Version von WordPress. Dies ist der erste Beitrag. Du kannst ihn bearbeiten oder löschen. Und dann starte mit dem Schreiben!', 'Hallo Welt!', '', 'publish', 'open', 'open', '', 'hallo-welt', '', '', '2015-10-05 14:08:37', '2015-10-05 12:08:37', '', 0, 'http://duktor-wordpress/?p=1', 0, 'post', '', 1) ; 
INSERT INTO `wp_posts` VALUES (2, 1, '2015-10-05 14:08:37', '2015-10-05 12:08:37', 'This is an example page. It\'s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:

<blockquote>Hi there! I\'m a bike messenger by day, aspiring actor by night, and this is my website. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin\' caught in the rain.)</blockquote>

...or something like this:

<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>

As a new WordPress user, you should go to <a href="http://duktor-wordpress/wordpress/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Beispiel-Seite', '', 'publish', 'closed', 'open', '', 'beispiel-seite', '', '', '2015-10-05 14:08:37', '2015-10-05 12:08:37', '', 0, 'http://duktor-wordpress/?page_id=2', 0, 'page', '', 0) ; 
INSERT INTO `wp_posts` VALUES (3, 1, '2015-10-05 14:10:15', '0000-00-00 00:00:00', '', 'Automatisch gespeicherter Entwurf', '', 'auto-draft', 'open', 'open', '', '', '', '', '2015-10-05 14:10:15', '0000-00-00 00:00:00', '', 0, 'http://duktor-wordpress/?p=3', 0, 'post', '', 0) ;
#
# End of data contents of table wp_posts
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_css`
#

DROP TABLE IF EXISTS `wp_revslider_css`;


#
# Table structure of table `wp_revslider_css`
#

CREATE TABLE `wp_revslider_css` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text NOT NULL,
  `settings` text,
  `hover` text,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_css (59 records)
#
 
INSERT INTO `wp_revslider_css` VALUES (1, '.tp-caption.medium_grey', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"20px","line-height":"20px","font-family":"Arial","padding":"2px 4px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#888","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (2, '.tp-caption.small_text', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"14px","line-height":"20px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (3, '.tp-caption.medium_text', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"20px","line-height":"20px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (4, '.tp-caption.large_text', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"40px","line-height":"40px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (5, '.tp-caption.very_large_text', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700","font-size":"60px","line-height":"60px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap","letter-spacing":"-2px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (6, '.tp-caption.very_big_white', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"800","font-size":"60px","line-height":"60px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap","padding":"0px 4px","padding-top":"1px","background-color":"#000"}') ; 
INSERT INTO `wp_revslider_css` VALUES (7, '.tp-caption.very_big_black', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"700","font-size":"60px","line-height":"60px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap","padding":"0px 4px","padding-top":"1px","background-color":"#fff"}') ; 
INSERT INTO `wp_revslider_css` VALUES (8, '.tp-caption.modern_medium_fat', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"800","font-size":"24px","line-height":"20px","font-family":"\\"Open Sans\\", sans-serif","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (9, '.tp-caption.modern_medium_fat_white', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"800","font-size":"24px","line-height":"20px","font-family":"\\"Open Sans\\", sans-serif","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (10, '.tp-caption.modern_medium_light', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"300","font-size":"24px","line-height":"20px","font-family":"\\"Open Sans\\", sans-serif","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (11, '.tp-caption.modern_big_bluebg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"800","font-size":"30px","line-height":"36px","font-family":"\\"Open Sans\\", sans-serif","padding":"3px 10px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#4e5b6c","letter-spacing":"0"}') ; 
INSERT INTO `wp_revslider_css` VALUES (12, '.tp-caption.modern_big_redbg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"300","font-size":"30px","line-height":"36px","font-family":"\\"Open Sans\\", sans-serif","padding":"3px 10px","padding-top":"1px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#de543e","letter-spacing":"0"}') ; 
INSERT INTO `wp_revslider_css` VALUES (13, '.tp-caption.modern_small_text_dark', NULL, NULL, '{"position":"absolute","color":"#555","text-shadow":"none","font-size":"14px","line-height":"22px","font-family":"Arial","margin":"0px","border-width":"0px","border-style":"none","white-space":"nowrap"}') ; 
INSERT INTO `wp_revslider_css` VALUES (14, '.tp-caption.boxshadow', NULL, NULL, '{"-moz-box-shadow":"0px 0px 20px rgba(0, 0, 0, 0.5)","-webkit-box-shadow":"0px 0px 20px rgba(0, 0, 0, 0.5)","box-shadow":"0px 0px 20px rgba(0, 0, 0, 0.5)"}') ; 
INSERT INTO `wp_revslider_css` VALUES (15, '.tp-caption.black', NULL, NULL, '{"color":"#000","text-shadow":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (16, '.tp-caption.noshadow', NULL, NULL, '{"text-shadow":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (17, '.tp-caption.thinheadline_dark', NULL, NULL, '{"position":"absolute","color":"rgba(0,0,0,0.85)","text-shadow":"none","font-weight":"300","font-size":"30px","line-height":"30px","font-family":"\\"Open Sans\\"","background-color":"transparent"}') ; 
INSERT INTO `wp_revslider_css` VALUES (18, '.tp-caption.thintext_dark', NULL, NULL, '{"position":"absolute","color":"rgba(0,0,0,0.85)","text-shadow":"none","font-weight":"300","font-size":"16px","line-height":"26px","font-family":"\\"Open Sans\\"","background-color":"transparent"}') ; 
INSERT INTO `wp_revslider_css` VALUES (19, '.tp-caption.largeblackbg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"300","font-size":"50px","line-height":"70px","font-family":"\\"Open Sans\\"","background-color":"#000","padding":"0px 20px","-webkit-border-radius":"0px","-moz-border-radius":"0px","border-radius":"0px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (20, '.tp-caption.largepinkbg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"300","font-size":"50px","line-height":"70px","font-family":"\\"Open Sans\\"","background-color":"#db4360","padding":"0px 20px","-webkit-border-radius":"0px","-moz-border-radius":"0px","border-radius":"0px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (21, '.tp-caption.largewhitebg', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-weight":"300","font-size":"50px","line-height":"70px","font-family":"\\"Open Sans\\"","background-color":"#fff","padding":"0px 20px","-webkit-border-radius":"0px","-moz-border-radius":"0px","border-radius":"0px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (22, '.tp-caption.largegreenbg', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-weight":"300","font-size":"50px","line-height":"70px","font-family":"\\"Open Sans\\"","background-color":"#67ae73","padding":"0px 20px","-webkit-border-radius":"0px","-moz-border-radius":"0px","border-radius":"0px"}') ; 
INSERT INTO `wp_revslider_css` VALUES (23, '.tp-caption.excerpt', NULL, NULL, '{"font-size":"36px","line-height":"36px","font-weight":"700","font-family":"Arial","color":"#ffffff","text-decoration":"none","background-color":"rgba(0, 0, 0, 1)","text-shadow":"none","margin":"0px","letter-spacing":"-1.5px","padding":"1px 4px 0px 4px","width":"150px","white-space":"normal !important","height":"auto","border-width":"0px","border-color":"rgb(255, 255, 255)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (24, '.tp-caption.large_bold_grey', NULL, NULL, '{"font-size":"60px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(102, 102, 102)","text-decoration":"none","background-color":"transparent","text-shadow":"none","margin":"0px","padding":"1px 4px 0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (25, '.tp-caption.medium_thin_grey', NULL, NULL, '{"font-size":"34px","line-height":"30px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(102, 102, 102)","text-decoration":"none","background-color":"transparent","padding":"1px 4px 0px","text-shadow":"none","margin":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (26, '.tp-caption.small_thin_grey', NULL, NULL, '{"font-size":"18px","line-height":"26px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(117, 117, 117)","text-decoration":"none","background-color":"transparent","padding":"1px 4px 0px","text-shadow":"none","margin":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (27, '.tp-caption.lightgrey_divider', NULL, NULL, '{"text-decoration":"none","background-color":"rgba(235, 235, 235, 1)","width":"370px","height":"3px","background-position":"initial initial","background-repeat":"initial initial","border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (28, '.tp-caption.large_bold_darkblue', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(52, 73, 94)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (29, '.tp-caption.medium_bg_darkblue', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(52, 73, 94)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (30, '.tp-caption.medium_bold_red', NULL, NULL, '{"font-size":"24px","line-height":"30px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(227, 58, 12)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (31, '.tp-caption.medium_light_red', NULL, NULL, '{"font-size":"21px","line-height":"26px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(227, 58, 12)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (32, '.tp-caption.medium_bg_red', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(227, 58, 12)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (33, '.tp-caption.medium_bold_orange', NULL, NULL, '{"font-size":"24px","line-height":"30px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(243, 156, 18)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (34, '.tp-caption.medium_bg_orange', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(243, 156, 18)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (35, '.tp-caption.grassfloor', NULL, NULL, '{"text-decoration":"none","background-color":"rgba(160, 179, 151, 1)","width":"4000px","height":"150px","border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (36, '.tp-caption.large_bold_white', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (37, '.tp-caption.medium_light_white', NULL, NULL, '{"font-size":"30px","line-height":"36px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (38, '.tp-caption.mediumlarge_light_white', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (39, '.tp-caption.mediumlarge_light_white_center', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"#ffffff","text-decoration":"none","background-color":"transparent","padding":"0px 0px 0px 0px","text-align":"center","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (40, '.tp-caption.medium_bg_asbestos', NULL, NULL, '{"font-size":"20px","line-height":"20px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(127, 140, 141)","padding":"10px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (41, '.tp-caption.medium_light_black', NULL, NULL, '{"font-size":"30px","line-height":"36px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (42, '.tp-caption.large_bold_black', NULL, NULL, '{"font-size":"58px","line-height":"60px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"transparent","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (43, '.tp-caption.mediumlarge_light_darkblue', NULL, NULL, '{"font-size":"34px","line-height":"40px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(52, 73, 94)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (44, '.tp-caption.small_light_white', NULL, NULL, '{"font-size":"17px","line-height":"28px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"transparent","padding":"0px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (45, '.tp-caption.roundedimage', NULL, NULL, '{"border-width":"0px","border-color":"rgb(34, 34, 34)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (46, '.tp-caption.large_bg_black', NULL, NULL, '{"font-size":"40px","line-height":"40px","font-weight":"800","font-family":"\\"Open Sans\\"","color":"rgb(255, 255, 255)","text-decoration":"none","background-color":"rgb(0, 0, 0)","padding":"10px 20px 15px","border-width":"0px","border-color":"rgb(255, 214, 88)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (47, '.tp-caption.mediumwhitebg', NULL, NULL, '{"font-size":"30px","line-height":"30px","font-weight":"300","font-family":"\\"Open Sans\\"","color":"rgb(0, 0, 0)","text-decoration":"none","background-color":"rgb(255, 255, 255)","padding":"5px 15px 10px","text-shadow":"none","border-width":"0px","border-color":"rgb(0, 0, 0)","border-style":"none"}') ; 
INSERT INTO `wp_revslider_css` VALUES (48, '.tp-caption.avada_huge_white_text', NULL, NULL, '{"position":"absolute","color":"#ffffff","font-size":"130px","line-height":"45px","font-family":"museoslab500regular"}') ; 
INSERT INTO `wp_revslider_css` VALUES (49, '.tp-caption.avada_huge_black_text', NULL, NULL, '{"position":"absolute","color":"#000000","font-size":"130px","line-height":"45px","font-family":"museoslab500regular"}') ; 
INSERT INTO `wp_revslider_css` VALUES (50, '.tp-caption.avada_big_black_text', NULL, NULL, '{"position":"absolute","color":"#333333","font-size":"42px","line-height":"45px","font-family":"museoslab500regular"}') ; 
INSERT INTO `wp_revslider_css` VALUES (51, '.tp-caption.avada_big_white_text', NULL, NULL, '{"position":"absolute","color":"#fff","font-size":"42px","line-height":"45px","font-family":"museoslab500regular"}') ; 
INSERT INTO `wp_revslider_css` VALUES (52, '.tp-caption.avada_big_black_text_center', NULL, NULL, '{"position":"absolute","color":"#333333","font-size":"38px","line-height":"45px","font-family":"museoslab500regular","text-align":"center"}') ; 
INSERT INTO `wp_revslider_css` VALUES (53, '.tp-caption.avada_med_green_text', NULL, NULL, '{"position":"absolute","color":"#A0CE4E","font-size":"24px","line-height":"24px","font-family":"PTSansRegular, Arial, Helvetica, sans-serif"}') ; 
INSERT INTO `wp_revslider_css` VALUES (54, '.tp-caption.avada_small_gray_text', NULL, NULL, '{"position":"absolute","color":"#747474","font-size":"13px","line-height":"20px","font-family":"PTSansRegular, Arial, Helvetica, sans-serif"}') ; 
INSERT INTO `wp_revslider_css` VALUES (55, '.tp-caption.avada_small_white_text', NULL, NULL, '{"position":"absolute","color":"#fff","font-size":"13px","line-height":"20px","font-family":"PTSansRegular, Arial, Helvetica, sans-serif","text-shadow":"0px 2px 5px rgba(0, 0, 0, 0.5)","font-weight":"700"}') ; 
INSERT INTO `wp_revslider_css` VALUES (56, '.tp-caption.avada_block_black', NULL, NULL, '{"position":"absolute","color":"#A0CE4E","text-shadow":"none","font-size":"22px","line-height":"34px","padding":"0px 10px","padding-top":"1px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#000","font-family":"PTSansRegular, Arial, Helvetica, sans-serif"}') ; 
INSERT INTO `wp_revslider_css` VALUES (57, '.tp-caption.avada_block_green', NULL, NULL, '{"position":"absolute","color":"#000","text-shadow":"none","font-size":"22px","line-height":"34px","padding":"0px 10px","padding-top":"1px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#A0CE4E","font-family":"PTSansRegular, Arial, Helvetica, sans-serif"}') ; 
INSERT INTO `wp_revslider_css` VALUES (58, '.tp-caption.avada_block_white', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-size":"22px","line-height":"34px","padding":"0px 10px","padding-top":"1px","margin":"0px","border-width":"0px","border-style":"none","background-color":"#000","font-family":"PTSansRegular, Arial, Helvetica, sans-serif"}') ; 
INSERT INTO `wp_revslider_css` VALUES (59, '.tp-caption.avada_block_white_trans', NULL, NULL, '{"position":"absolute","color":"#fff","text-shadow":"none","font-size":"22px","line-height":"34px","padding":"0px 10px","padding-top":"1px","margin":"0px","border-width":"0px","border-style":"none","background-color":"rgba(0, 0, 0, 0.6)","font-family":"PTSansRegular, Arial, Helvetica, sans-serif"}') ;
#
# End of data contents of table wp_revslider_css
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_layer_animations`
#

DROP TABLE IF EXISTS `wp_revslider_layer_animations`;


#
# Table structure of table `wp_revslider_layer_animations`
#

CREATE TABLE `wp_revslider_layer_animations` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `handle` text NOT NULL,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_layer_animations (0 records)
#

#
# End of data contents of table wp_revslider_layer_animations
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_settings`
#

DROP TABLE IF EXISTS `wp_revslider_settings`;


#
# Table structure of table `wp_revslider_settings`
#

CREATE TABLE `wp_revslider_settings` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `general` text NOT NULL,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_settings (1 records)
#
 
INSERT INTO `wp_revslider_settings` VALUES (1, 'a:0:{}', '') ;
#
# End of data contents of table wp_revslider_settings
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_sliders`
#

DROP TABLE IF EXISTS `wp_revslider_sliders`;


#
# Table structure of table `wp_revslider_sliders`
#

CREATE TABLE `wp_revslider_sliders` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `title` tinytext NOT NULL,
  `alias` tinytext,
  `params` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_sliders (0 records)
#

#
# End of data contents of table wp_revslider_sliders
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_slides`
#

DROP TABLE IF EXISTS `wp_revslider_slides`;


#
# Table structure of table `wp_revslider_slides`
#

CREATE TABLE `wp_revslider_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `slide_order` int(11) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_slides (0 records)
#

#
# End of data contents of table wp_revslider_slides
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_static_slides`
# --------------------------------------------------------


#
# Delete any existing table `wp_revslider_static_slides`
#

DROP TABLE IF EXISTS `wp_revslider_static_slides`;


#
# Table structure of table `wp_revslider_static_slides`
#

CREATE TABLE `wp_revslider_static_slides` (
  `id` int(9) NOT NULL AUTO_INCREMENT,
  `slider_id` int(9) NOT NULL,
  `params` text NOT NULL,
  `layers` text NOT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 ;

#
# Data contents of table wp_revslider_static_slides (0 records)
#

#
# End of data contents of table wp_revslider_static_slides
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_static_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_term_relationships (1 records)
#
 
INSERT INTO `wp_term_relationships` VALUES (1, 1, 0) ;
#
# End of data contents of table wp_term_relationships
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_static_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------


#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_term_taxonomy (1 records)
#
 
INSERT INTO `wp_term_taxonomy` VALUES (1, 1, 'category', '', 0, 1) ;
#
# End of data contents of table wp_term_taxonomy
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_static_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------


#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_terms (1 records)
#
 
INSERT INTO `wp_terms` VALUES (1, 'Allgemein', 'allgemein', 0) ;
#
# End of data contents of table wp_terms
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_static_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------


#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_usermeta (16 records)
#
 
INSERT INTO `wp_usermeta` VALUES (1, 1, 'nickname', 'duktoradmin') ; 
INSERT INTO `wp_usermeta` VALUES (2, 1, 'first_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (3, 1, 'last_name', '') ; 
INSERT INTO `wp_usermeta` VALUES (4, 1, 'description', '') ; 
INSERT INTO `wp_usermeta` VALUES (5, 1, 'rich_editing', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (6, 1, 'comment_shortcuts', 'false') ; 
INSERT INTO `wp_usermeta` VALUES (7, 1, 'admin_color', 'fresh') ; 
INSERT INTO `wp_usermeta` VALUES (8, 1, 'use_ssl', '0') ; 
INSERT INTO `wp_usermeta` VALUES (9, 1, 'show_admin_bar_front', 'true') ; 
INSERT INTO `wp_usermeta` VALUES (10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}') ; 
INSERT INTO `wp_usermeta` VALUES (11, 1, 'wp_user_level', '10') ; 
INSERT INTO `wp_usermeta` VALUES (12, 1, 'dismissed_wp_pointers', '') ; 
INSERT INTO `wp_usermeta` VALUES (13, 1, 'show_welcome_panel', '1') ; 
INSERT INTO `wp_usermeta` VALUES (14, 1, 'session_tokens', 'a:2:{s:64:"0bf1e41dd075466bdb6bba7fd94dabb2b2f2e4d1383a6b4f1965f4813d24d76f";a:4:{s:10:"expiration";i:1445256611;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:102:"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36";s:5:"login";i:1444047011;}s:64:"2cc43202e059e372cb4e70c5190e8c97c6baee444d1add70932e02c133ce328c";a:4:{s:10:"expiration";i:1444220010;s:2:"ip";s:9:"127.0.0.1";s:2:"ua";s:102:"Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 Safari/537.36";s:5:"login";i:1444047210;}}') ; 
INSERT INTO `wp_usermeta` VALUES (15, 1, 'wp_dashboard_quick_press_last_post_id', '3') ; 
INSERT INTO `wp_usermeta` VALUES (16, 1, 'avada_pre_386_notice', '1') ;
#
# End of data contents of table wp_usermeta
# --------------------------------------------------------

# WordPress : http://duktor-wordpress MySQL database backup
#
# Generated: Monday 5. October 2015 13:47 UTC
# Hostname: localhost
# Database: `duktor-wp`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_commentmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_comments`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_layerslider`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_links`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_options`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_postmeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_posts`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_css`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_layer_animations`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_settings`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_sliders`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_revslider_static_slides`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_relationships`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_term_taxonomy`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_terms`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_usermeta`
# --------------------------------------------------------
# --------------------------------------------------------
# Table: `wp_users`
# --------------------------------------------------------


#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ;

#
# Data contents of table wp_users (1 records)
#
 
INSERT INTO `wp_users` VALUES (1, 'duktoradmin', '$P$Bxx1YypLtRLQvdv7LFqNhDqpbrWzjG1', 'duktoradmin', 'briandamage@web.de', '', '2015-10-05 12:08:36', '', 0, 'duktoradmin') ;
#
# End of data contents of table wp_users
# --------------------------------------------------------

