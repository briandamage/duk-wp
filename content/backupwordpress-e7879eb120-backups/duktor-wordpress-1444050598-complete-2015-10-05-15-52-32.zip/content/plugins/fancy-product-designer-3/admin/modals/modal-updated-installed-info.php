<div class="fpd-modal-wrapper fpd-modal-visible" id="fpd-modal-updated-installed-info">
	<div class="fpd-modal-dialog">
		<a href="#" class="fpd-close-modal">&times;</a>
		<div class="fpd-modal-content">
			<iframe src="<?php echo $info_url; ?>" frameborder="0"></iframe>
		</div>
	</div>
</div>